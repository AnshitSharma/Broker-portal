import { Injectable, inject } from '@angular/core';
import { Router, CanActivateFn, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { AuthService } from '../services/auth.service';

// Modern Angular uses functional guards instead of class-based guards
export const AuthGuard: CanActivateFn = (
  route: ActivatedRouteSnapshot,
  state: RouterStateSnapshot
) => {
  const router = inject(Router);
  const authService = inject(AuthService);

  // Check if the user is logged in
  if (authService.isAuthenticated()) {
    // Authorized, so return true
    return true;
  }

  // Not logged in, so redirect to login page with return url
  router.navigate(['/login'], { queryParams: { returnUrl: state.url }});
  return false;
};