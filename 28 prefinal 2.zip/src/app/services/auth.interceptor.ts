import { HttpInterceptorFn } from '@angular/common/http';
import { inject } from '@angular/core';
import { Router } from '@angular/router';
import { catchError, throwError } from 'rxjs';
import { AuthService } from './auth.service';

export const authInterceptor: HttpInterceptorFn = (req, next) => {
  const authService = inject(AuthService);
  const router = inject(Router);
  
  // Skip interceptor for login and register requests
  if (req.url.includes('/api/auth/login') || req.url.includes('/api/auth/register')) {
    return next(req);
  }
  
  // Get the auth token from the service
  const token = authService.getToken();

  console.log(`Interceptor - URL: ${req.url}, Token: ${token ? 'exists' : 'missing'}`);

  // Clone the request and add the authorization header if token exists
  if (token) {
    const authReq = req.clone({
      setHeaders: {
        Authorization: `Bearer ${token}`
      }
    });
    console.log('Adding authorization header to request');
    return next(authReq).pipe(
      catchError(error => {
        console.error('Request error in interceptor:', error);
        if (error.status === 401) {
          // If the request returns a 401 Unauthorized error, the token has expired
          // or is invalid. Log the user out and redirect to login.
          console.log('401 Unauthorized error detected, logging out');
          authService.logout();
          router.navigate(['/login']);
        }
        return throwError(() => error);
      })
    );
  }

  // If no token, just pass the request through
  return next(req).pipe(
    catchError(error => {
      console.error('Request error in interceptor (no token):', error);
      if (error.status === 401) {
        // No token but protected resource, redirect to login
        console.log('401 Unauthorized error detected with no token, redirecting to login');
        router.navigate(['/login']);
      }
      return throwError(() => error);
    })
  );
};