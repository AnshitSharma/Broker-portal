import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../services/auth.service';

@Component({
  selector: 'app-password-change-page',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './password-change.component.html',
  styleUrls: ['./password-change.component.css']
})
export class PasswordChangePageComponent implements OnInit {
  passwordChangeForm!: FormGroup;
  isLoading: boolean = false;
  errorMessage: string = '';
  successMessage: string = '';
  
  constructor(
    private fb: FormBuilder,
    private authService: AuthService,
    private router: Router
  ) {}
  
  ngOnInit(): void {
    this.initForm();
  }
  
  private initForm(): void {
    this.passwordChangeForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]],
      currentPassword: ['', [Validators.required, Validators.minLength(6)]],
      newPassword: ['', [Validators.required, Validators.minLength(6)]]
    });
    
    // If user is logged in, pre-fill the email field
    const currentUser = this.authService.getCurrentUser();
    if (currentUser && currentUser.email) {
      this.passwordChangeForm.get('email')?.setValue(currentUser.email);
    }
  }
  
  onSubmit(): void {
    if (this.passwordChangeForm.invalid) {
      this.passwordChangeForm.markAllAsTouched();
      return;
    }
    
    this.isLoading = true;
    this.errorMessage = '';
    this.successMessage = '';
    
    const { email, currentPassword, newPassword } = this.passwordChangeForm.value;
    
    this.authService.changePassword(email, currentPassword, newPassword)
      .subscribe({
        next: (response) => {
          this.isLoading = false;
          this.successMessage = 'Password has been changed successfully!';
          
          // Redirect to login page after 3 seconds
          setTimeout(() => {
            this.router.navigate(['/login'], { 
              queryParams: { passwordChanged: 'true' } 
            });
          }, 3000);
        },
        error: (error) => {
          this.isLoading = false;
          this.errorMessage = error.message || 'Error while changing password. Please try again.';
        }
      });
  }
  
  goBack(): void {
    this.router.navigate(['/login']);
  }
  
  // Helper methods for form validation
  get emailControl() { return this.passwordChangeForm.get('email'); }
  get currentPasswordControl() { return this.passwordChangeForm.get('currentPassword'); }
  get newPasswordControl() { return this.passwordChangeForm.get('newPassword'); }
  
  hasError(controlName: string, errorName: string): boolean {
    const control = this.passwordChangeForm.get(controlName);
    return !!control && control.touched && control.hasError(errorName);
  }
}