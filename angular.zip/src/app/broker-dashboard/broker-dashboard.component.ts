import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { Router, NavigationEnd } from '@angular/router';
import { filter } from 'rxjs/operators';

interface ClientQuote {
  id: string;
  clientName: string;
  businessName: string;
  quoteDate: Date;
  premium: number;
  status: 'pending' | 'approved' | 'declined' | 'bound';
  coverageType: string;
}

interface RecentActivity {
  id: number;
  type: 'quote' | 'policy' | 'claim' | 'message';
  description: string;
  time: Date;
  clientName: string;
  icon: string;
}

interface Task {
  id: number;
  title: string;
  dueDate: Date;
  priority: 'high' | 'medium' | 'low';
  completed: boolean;
}

interface PieSegment {
  path: string;
  color: string;
}

interface QuoteNote {
  id: number;
  quoteId: string;
  author: string;
  date: Date;
  content: string;
}

interface ClientDetails {
  email: string;
  phone: string;
}

@Component({
  selector: 'app-broker-dashboard',
  standalone: true,
  imports: [CommonModule, RouterModule, FormsModule],
  templateUrl: './broker-dashboard.component.html',
  styleUrls: ['./broker-dashboard.component.css']
})
export class BrokerDashboardComponent implements OnInit {
  // Expose Math object to be used in template
  Math = Math;
  
  // UI State
  darkModeEnabled: boolean = false;
  sidebarCollapsed: boolean = false;
  currentRoute: string = '/dashboard';
  selectedQuote: ClientQuote | null = null;
  quoteToDelete: ClientQuote | null = null;
  
  // Pagination
  currentPage: number = 1;
  itemsPerPage: number = 10;
  totalPages: number = 1;
  
  // Broker details
  brokerName: string = 'John Broker';
  brokerRole: string = 'Senior Insurance Broker';
  
  // Dashboard stats
  pendingQuotes: number = 12;
  activeClients: number = 84;
  conversionRate: number = 68;
  quarterlyCommission: number = 24650;
  
  // Monthly targets
  targetNewClients: number = 15;
  actualNewClients: number = 11;
  targetRenewals: number = 25;
  actualRenewals: number = 22;
  targetRevenue: number = 35000;
  actualRevenue: number = 24650;
  
  // Filter and search states
  quoteStatusFilter: string = 'all';
  quoteSearchQuery: string = '';
  
  // Charts data
  performanceMonths: string[] = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'];
  performanceData: number[] = [18500, 22400, 19800, 26700, 22300, 24650];
  
  // Line of business data
  lineOfBusinessData: any[] = [
    { name: 'Bodily Injury and Property Damage', value: 35, color: '#CC7952' },
    { name: 'Products and Completed Operations', value: 25, color: '#4A6BD6' },
    { name: 'Advertising Injury', value: 15, color: '#42C0C0' },
    { name: 'Reputational Harm', value: 15, color: '#87D987' },
    { name: 'Independent Contractors', value: 10, color: '#87BD52' }
  ];
  
  // Pie chart segments
  pieSegments: PieSegment[] = [];
  
  // Recent quotes - expanded with more data
  allQuotes: ClientQuote[] = [
    { 
      id: 'Q-39485', 
      clientName: 'Robert Johnson', 
      businessName: 'Johnson Consulting LLC', 
      quoteDate: new Date(2025, 3, 2), 
      premium: 2850, 
      status: 'pending',
      coverageType: 'Bodily Injury and Property Damage'
    },
    { 
      id: 'Q-39471', 
      clientName: 'Sarah Williams', 
      businessName: 'Artisan Bakery', 
      quoteDate: new Date(2025, 3, 3), 
      premium: 3200, 
      status: 'approved',
      coverageType: 'Products and Completed Operations'
    },
    { 
      id: 'Q-39465', 
      clientName: 'Michael Chen', 
      businessName: 'Chen Technology Solutions', 
      quoteDate: new Date(2025, 3, 4), 
      premium: 5100, 
      status: 'bound',
      coverageType: 'Advertising Injury'
    },
    { 
      id: 'Q-39458', 
      clientName: 'Alicia Rodriguez', 
      businessName: 'AR Interior Design', 
      quoteDate: new Date(2025, 3, 5), 
      premium: 1950, 
      status: 'declined',
      coverageType: 'Reputational Harm'
    },
    { 
      id: 'Q-39442', 
      clientName: 'David Smith', 
      businessName: 'Smith Construction Inc.', 
      quoteDate: new Date(2025, 3, 6), 
      premium: 8750, 
      status: 'approved',
      coverageType: 'Independent Contractors'
    },
    { 
      id: 'Q-39441', 
      clientName: 'Jennifer Lee', 
      businessName: 'Lee Medical Supplies', 
      quoteDate: new Date(2025, 3, 1), 
      premium: 4250, 
      status: 'pending',
      coverageType: 'Bodily Injury and Property Damage'
    },
    { 
      id: 'Q-39440', 
      clientName: 'William Brown', 
      businessName: 'Brown & Associates', 
      quoteDate: new Date(2025, 2, 29), 
      premium: 3120, 
      status: 'approved',
      coverageType: 'Advertising Injury'
    },
    { 
      id: 'Q-39439', 
      clientName: 'Emily Martinez', 
      businessName: 'Martinez Floral Design', 
      quoteDate: new Date(2025, 2, 28), 
      premium: 1875, 
      status: 'bound',
      coverageType: 'Products and Completed Operations'
    },
    { 
      id: 'Q-39438', 
      clientName: 'George Wilson', 
      businessName: 'Wilson Plumbing', 
      quoteDate: new Date(2025, 2, 27), 
      premium: 2950, 
      status: 'pending',
      coverageType: 'Independent Contractors'
    },
    { 
      id: 'Q-39437', 
      clientName: 'Patricia Davis', 
      businessName: 'Davis Legal Services', 
      quoteDate: new Date(2025, 2, 26), 
      premium: 5450, 
      status: 'approved',
      coverageType: 'Reputational Harm'
    },
    { 
      id: 'Q-39436', 
      clientName: 'Jessica Thomas', 
      businessName: 'Thomas Catering', 
      quoteDate: new Date(2025, 2, 25), 
      premium: 2150, 
      status: 'declined',
      coverageType: 'Products and Completed Operations'
    },
    { 
      id: 'Q-39435', 
      clientName: 'Mark Anderson', 
      businessName: 'Anderson Landscaping', 
      quoteDate: new Date(2025, 2, 24), 
      premium: 3400, 
      status: 'bound',
      coverageType: 'Bodily Injury and Property Damage'
    },
    { 
      id: 'Q-39434', 
      clientName: 'Susan Moore', 
      businessName: 'Moore Marketing Agency', 
      quoteDate: new Date(2025, 2, 23), 
      premium: 4950, 
      status: 'pending',
      coverageType: 'Advertising Injury'
    },
    { 
      id: 'Q-39433', 
      clientName: 'Kevin Taylor', 
      businessName: 'Taylor Auto Repair', 
      quoteDate: new Date(2025, 2, 22), 
      premium: 6750, 
      status: 'approved',
      coverageType: 'Independent Contractors'
    },
    { 
      id: 'Q-39432', 
      clientName: 'Elizabeth Clark', 
      businessName: 'Clark Dental Office', 
      quoteDate: new Date(2025, 2, 21), 
      premium: 7200, 
      status: 'pending',
      coverageType: 'Bodily Injury and Property Damage'
    }
  ];
  
  // Recent activities
  recentActivities: RecentActivity[] = [
    { 
      id: 1, 
      type: 'quote', 
      description: 'New quote created', 
      time: new Date(2025, 3, 7, 14, 32), 
      clientName: 'Robert Johnson',
      icon: 'fa-file-invoice-dollar'
    },
    { 
      id: 2, 
      type: 'policy', 
      description: 'Policy bound', 
      time: new Date(2025, 3, 7, 11, 15), 
      clientName: 'Michael Chen',
      icon: 'fa-file-signature'
    },
    { 
      id: 3, 
      type: 'message', 
      description: 'New message received', 
      time: new Date(2025, 3, 7, 9, 45), 
      clientName: 'Sarah Williams',
      icon: 'fa-envelope'
    },
    { 
      id: 4, 
      type: 'claim', 
      description: 'Claim reported', 
      time: new Date(2025, 3, 6, 16, 22), 
      clientName: 'David Smith',
      icon: 'fa-exclamation-circle'
    },
    { 
      id: 5, 
      type: 'quote', 
      description: 'Quote declined', 
      time: new Date(2025, 3, 6, 13, 10), 
      clientName: 'Alicia Rodriguez',
      icon: 'fa-times-circle'
    }
  ];
  
  // Tasks
  tasks: Task[] = [
    { id: 1, title: 'Follow up with Robert Johnson', dueDate: new Date(2025, 3, 10), priority: 'high', completed: false },
    { id: 2, title: 'Renew Smith Construction policy', dueDate: new Date(2025, 3, 15), priority: 'medium', completed: false },
    { id: 3, title: 'Complete product training', dueDate: new Date(2025, 3, 12), priority: 'low', completed: true },
    { id: 4, title: 'Submit monthly reports', dueDate: new Date(2025, 3, 30), priority: 'high', completed: false },
    { id: 5, title: 'Client review meeting - AR Interior', dueDate: new Date(2025, 3, 18), priority: 'medium', completed: false }
  ];
  
  // Client details mapping for contact information
  clientDetails: {[key: string]: ClientDetails} = {
    'Robert Johnson': { email: 'robert.johnson@johnsonconsulting.com', phone: '(555) 123-4567' },
    'Sarah Williams': { email: 'sarah@artisanbakery.com', phone: '(555) 234-5678' },
    'Michael Chen': { email: 'michael@chentechsolutions.com', phone: '(555) 345-6789' },
    'Alicia Rodriguez': { email: 'alicia@arinteriordesign.com', phone: '(555) 456-7890' },
    'David Smith': { email: 'dsmith@smithconstruction.com', phone: '(555) 567-8901' },
    'Jennifer Lee': { email: 'jennifer@leemedicalsupplies.com', phone: '(555) 678-9012' },
    'William Brown': { email: 'william@brownassociates.com', phone: '(555) 789-0123' },
    'Emily Martinez': { email: 'emily@martinezfloral.com', phone: '(555) 890-1234' },
    'George Wilson': { email: 'george@wilsonplumbing.com', phone: '(555) 901-2345' },
    'Patricia Davis': { email: 'patricia@davislegal.com', phone: '(555) 012-3456' },
    'Jessica Thomas': { email: 'jessica@thomascatering.com', phone: '(555) 123-4567' },
    'Mark Anderson': { email: 'mark@andersonlandscaping.com', phone: '(555) 234-5678' },
    'Susan Moore': { email: 'susan@mooremktg.com', phone: '(555) 345-6789' },
    'Kevin Taylor': { email: 'kevin@taylorauto.com', phone: '(555) 456-7890' },
    'Elizabeth Clark': { email: 'elizabeth@clarkdental.com', phone: '(555) 567-8901' }
  };
  
  // Notes for quotes
  quoteNotes: QuoteNote[] = [
    {
      id: 1,
      quoteId: 'Q-39485',
      author: 'John Broker',
      date: new Date(2025, 3, 2, 14, 30),
      content: 'Client requested a follow-up call to discuss coverage details.'
    },
    {
      id: 2,
      quoteId: 'Q-39485',
      author: 'Maria Underwriter',
      date: new Date(2025, 3, 3, 10, 15),
      content: 'Additional information needed regarding business operations.'
    },
    {
      id: 3,
      quoteId: 'Q-39471',
      author: 'John Broker',
      date: new Date(2025, 3, 3, 16, 45),
      content: 'Client accepted the coverage options. Ready for underwriting approval.'
    },
    {
      id: 4,
      quoteId: 'Q-39465',
      author: 'John Broker',
      date: new Date(2025, 3, 4, 11, 20),
      content: 'Policy bound. All documents delivered to client.'
    },
    {
      id: 5,
      quoteId: 'Q-39458',
      author: 'John Broker',
      date: new Date(2025, 3, 5, 9, 30),
      content: 'Client declined due to budget constraints. Will follow up in 3 months.'
    }
  ];
  
  // Coverage descriptions
  coverageDescriptions: {[key: string]: string} = {
    'Bodily Injury and Property Damage': 'Covers claims for physical injuries to others and damage to their property resulting from your business operations.',
    'Products and Completed Operations': 'Protects against liability arising from products you sell or services you provide after the product is sold or the work is completed.',
    'Advertising Injury': 'Covers liability for damages arising from your advertising, such as copyright infringement, slander, libel, or invasion of privacy.',
    'Reputational Harm': 'Provides coverage for claims alleging damage to someone\'s reputation, such as defamation, slander, or libel.',
    'Independent Contractors': 'Extends liability protection to cover independent contractors working on behalf of your business.'
  };
  
  // User preferences
  notificationsEnabled: boolean = true;
  
  constructor(private router: Router) {
    // Subscribe to router events to track current route
    this.router.events
      .pipe(filter(event => event instanceof NavigationEnd))
      .subscribe((event: any) => {
        this.currentRoute = event.url;
        // Reset to first page when changing routes
        this.currentPage = 1;
      });
  }
  
  ngOnInit(): void {
    // Check if dark mode is saved in localStorage
    const savedDarkMode = localStorage.getItem('darkMode');
    if (savedDarkMode) {
      this.darkModeEnabled = JSON.parse(savedDarkMode);
      document.body.classList.toggle('dark-mode', this.darkModeEnabled);
    }
    
    // Check if sidebar state is saved in localStorage
    const savedSidebarState = localStorage.getItem('sidebarCollapsed');
    if (savedSidebarState) {
      this.sidebarCollapsed = JSON.parse(savedSidebarState);
    }
    
    // Initialize current route
    this.currentRoute = this.router.url;
    
    // Calculate total pages for quotes pagination
    this.totalPages = Math.ceil(this.allQuotes.length / this.itemsPerPage);
  }
  
  // Toggle sidebar collapsed state
  toggleSidebar(): void {
    this.sidebarCollapsed = !this.sidebarCollapsed;
    localStorage.setItem('sidebarCollapsed', JSON.stringify(this.sidebarCollapsed));
  }
  
  // Toggle dark mode
  toggleDarkMode(): void {
    this.darkModeEnabled = !this.darkModeEnabled;
    document.body.classList.toggle('dark-mode', this.darkModeEnabled);
    localStorage.setItem('darkMode', JSON.stringify(this.darkModeEnabled));
  }
  
  // Toggle notifications
  toggleNotifications(): void {
    this.notificationsEnabled = !this.notificationsEnabled;
    // In a real app, you would update user preferences in backend
  }
  
  // Create a new quote
  createNewQuote(): void {
    this.router.navigate(['/insurance']);
  }
  
  // Calculate progress percentage for targets
  getProgressPercentage(actual: number, target: number): number {
    return Math.min(Math.round((actual / target) * 100), 100);
  }
  
  // Get filtered quotes based on search and filter
  getFilteredQuotes(): ClientQuote[] {
    let filteredQuotes = this.allQuotes;
    
    // Apply status filter
    if (this.quoteStatusFilter !== 'all') {
      filteredQuotes = filteredQuotes.filter(quote => quote.status === this.quoteStatusFilter);
    }
    
    // Apply search filter
    if (this.quoteSearchQuery.trim() !== '') {
      const search = this.quoteSearchQuery.toLowerCase();
      filteredQuotes = filteredQuotes.filter(quote => 
        quote.id.toLowerCase().includes(search) ||
        quote.clientName.toLowerCase().includes(search) ||
        quote.businessName.toLowerCase().includes(search) ||
        quote.coverageType.toLowerCase().includes(search)
      );
    }
    
    // Update total pages
    this.totalPages = Math.ceil(filteredQuotes.length / this.itemsPerPage);
    
    // Apply pagination
    const startIndex = (this.currentPage - 1) * this.itemsPerPage;
    const endIndex = startIndex + this.itemsPerPage;
    return filteredQuotes.slice(startIndex, endIndex);
  }
  
  // Get status class for UI styling
  getStatusClass(status: string): string {
    switch(status) {
      case 'pending': return 'status-pending';
      case 'approved': return 'status-approved';
      case 'bound': return 'status-bound';
      case 'declined': return 'status-declined';
      default: return '';
    }
  }
  
  // Get page numbers array for pagination display
  getPageNumbers(): number[] {
    const pages: number[] = [];
    const maxDisplayPages = 5;
    
    if (this.totalPages <= maxDisplayPages) {
      // Display all pages if total pages is less than max display
      for (let i = 1; i <= this.totalPages; i++) {
        pages.push(i);
      }
    } else {
      // Display a subset of pages with current page in middle if possible
      const halfMax = Math.floor(maxDisplayPages / 2);
      
      let startPage = Math.max(this.currentPage - halfMax, 1);
      let endPage = startPage + maxDisplayPages - 1;
      
      if (endPage > this.totalPages) {
        endPage = this.totalPages;
        startPage = Math.max(endPage - maxDisplayPages + 1, 1);
      }
      
      for (let i = startPage; i <= endPage; i++) {
        pages.push(i);
      }
    }
    
    return pages;
  }
  
  // Change page in pagination
  changePage(page: number): void {
    if (page < 1 || page > this.totalPages) {
      return;
    }
    this.currentPage = page;
  }
  
  // View quote details
  viewQuoteDetails(quote: ClientQuote): void {
    this.selectedQuote = quote;
  }
  
  // Close quote details modal
  closeQuoteDetails(event?: MouseEvent): void {
    this.selectedQuote = null;
  }
  
  // Edit quote
  editQuote(quote: ClientQuote): void {
    // In a real app, this would route to an edit page or open an edit modal
    alert(`Editing quote ${quote.id} for ${quote.clientName}`);
  }
  
  // Confirm delete quote
  confirmDeleteQuote(quote: ClientQuote): void {
    this.quoteToDelete = quote;
  }
  
  // Cancel delete quote
  cancelDeleteQuote(event?: MouseEvent): void {
    this.quoteToDelete = null;
  }
  
  // Delete quote
  deleteQuote(): void {
    if (!this.quoteToDelete) return;
    
    // Remove quote from the array
    this.allQuotes = this.allQuotes.filter(q => q.id !== this.quoteToDelete?.id);
    
    // Update total pages
    this.totalPages = Math.ceil(this.allQuotes.length / this.itemsPerPage);
    
    // Adjust current page if needed
    if (this.currentPage > this.totalPages && this.totalPages > 0) {
      this.currentPage = this.totalPages;
    }
    
    // Close the modal
    this.quoteToDelete = null;
  }
  
  // Bind a quote
  bindQuote(quote: ClientQuote): void {
    // Find quote index
    const index = this.allQuotes.findIndex(q => q.id === quote.id);
    if (index !== -1) {
      // Update the status
      this.allQuotes[index].status = 'bound';
      
      // If this is the currently selected quote in the modal, update that too
      if (this.selectedQuote && this.selectedQuote.id === quote.id) {
        this.selectedQuote.status = 'bound';
      }
      
      alert(`Quote ${quote.id} for ${quote.clientName} has been bound successfully.`);
    }
  }
  
  // Approve a quote
  approveQuote(quote: ClientQuote): void {
    // Find quote index
    const index = this.allQuotes.findIndex(q => q.id === quote.id);
    if (index !== -1) {
      // Update the status
      this.allQuotes[index].status = 'approved';
      
      // If this is the currently selected quote in the modal, update that too
      if (this.selectedQuote && this.selectedQuote.id === quote.id) {
        this.selectedQuote.status = 'approved';
      }
      
      alert(`Quote ${quote.id} for ${quote.clientName} has been approved.`);
    }
  }
  
  // Decline a quote
  declineQuote(quote: ClientQuote): void {
    // Find quote index
    const index = this.allQuotes.findIndex(q => q.id === quote.id);
    if (index !== -1) {
      // Update the status
      this.allQuotes[index].status = 'declined';
      
      // If this is the currently selected quote in the modal, update that too
      if (this.selectedQuote && this.selectedQuote.id === quote.id) {
        this.selectedQuote.status = 'declined';
      }
      
      alert(`Quote ${quote.id} for ${quote.clientName} has been declined.`);
    }
  }
  
  // Get client email
  getClientEmail(clientName: string): string {
    return this.clientDetails[clientName]?.email || 'No email available';
  }
  
  // Get client phone
  getClientPhone(clientName: string): string {
    return this.clientDetails[clientName]?.phone || 'No phone available';
  }
  
  // Get notes for a specific quote
  getQuoteNotes(quoteId: string): QuoteNote[] {
    return this.quoteNotes.filter(note => note.quoteId === quoteId);
  }
  
  // Get coverage description
  getCoverageDescription(coverageType: string): string {
    return this.coverageDescriptions[coverageType] || 'No description available';
  }
}