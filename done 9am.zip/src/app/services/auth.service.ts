import { Injectable, PLATFORM_ID, Inject } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Router } from '@angular/router';
import { BehaviorSubject, Observable, throwError } from 'rxjs';
import { catchError, map, tap } from 'rxjs/operators';
import { isPlatformBrowser } from '@angular/common';

// User model
export interface User {
  id: string;
  email: string;
  firstName: string;
  lastName: string;
  username?: string;
  company?: string;
  phoneNumber?: string;
  token?: string;
}

// Login request interface
export interface LoginRequest {
  email: string;
  password: string;
}

// Register request interface
export interface RegisterRequest {
  firstName: string;
  lastName: string;
  username: string;
  email: string;
  company: string;
  phoneNumber: string;
  password: string;
  confirmPassword: string;
}

// Authentication response
interface AuthResponse {
  user: User;
  token: string;
}

// Password change request interface
export interface PasswordChangeRequest {
  email: string;
  currentPassword: string;
  newPassword: string;
}

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private readonly API_URL = 'https://localhost:7124/api/Auth';
  private readonly USERS_API_URL = 'https://localhost:7124/api/Users';
  private readonly USER_KEY = 'current_user';
  private readonly TOKEN_KEY = 'auth_token';
  
  private currentUserSubject = new BehaviorSubject<User | null>(null);
  private isBrowser: boolean;
  
  // Expose an observable of the current user
  currentUser$ = this.currentUserSubject.asObservable();
  
  constructor(
    private http: HttpClient,
    private router: Router,
    @Inject(PLATFORM_ID) private platformId: Object
  ) {
    // Check if we're in a browser environment
    this.isBrowser = isPlatformBrowser(this.platformId);
    
    // Only load from storage if we're in a browser
    if (this.isBrowser) {
      this.loadUserFromStorage();
    }
  }
  
  /**
   * Load user from storage if available
   */
  private loadUserFromStorage(): void {
    if (!this.isBrowser) return;
    
    const userJson = localStorage.getItem(this.USER_KEY);
    const token = localStorage.getItem(this.TOKEN_KEY);
    
    if (userJson) {
      try {
        const user = JSON.parse(userJson);
        if (token) {
          // Make sure the token is included with the user object
          user.token = token;
        }
        this.currentUserSubject.next(user);
      } catch (error) {
        // If there's an error parsing the user, remove it
        localStorage.removeItem(this.USER_KEY);
        localStorage.removeItem(this.TOKEN_KEY);
        this.currentUserSubject.next(null);
      }
    } else if (token) {
      // We have a token but no user, create a minimal user object
      const minimalUser: User = {
        id: 'unknown',
        email: 'unknown',
        firstName: 'User',
        lastName: '',
        token: token
      };
      this.currentUserSubject.next(minimalUser);
    }
  }
  
  /**
   * Login with email and password
   */
  login(email: string, password: string): Observable<User> {
    const loginRequest: LoginRequest = { email, password };
    
    return this.http.post<AuthResponse>(`${this.API_URL}/login`, loginRequest)
      .pipe(
        tap(response => this.handleAuthSuccess(response)),
        map(response => response.user),
        catchError(this.handleError)
      );
      
  }
  
  /**
   * Register a new user
   */
  register(registerData: RegisterRequest): Observable<any> {
    return this.http.post<any>(`${this.API_URL}/register`, registerData)
      .pipe(
        catchError(this.handleError)
      );
  }
  
  /**
   * Change user's password
   */
  changePassword(email: string, currentPassword: string, newPassword: string): Observable<any> {
    const passwordChangeRequest: PasswordChangeRequest = { 
      email, 
      currentPassword, 
      newPassword 
    };
    
    return this.http.post(`${this.USERS_API_URL}/change-password`, passwordChangeRequest)
      .pipe(
        catchError(this.handleError)
      );
  }
  
  /**
   * Handle successful authentication
   */
  private handleAuthSuccess(response: AuthResponse): void {
    if (!this.isBrowser) return;
    
    // Store token in localStorage
    if (response.token) {
      localStorage.setItem(this.TOKEN_KEY, response.token);
      
      // Add token to the user object
      if (response.user) {
        response.user.token = response.token;
      }
    }
    
    // Store user in localStorage
    if (response.user) {
      localStorage.setItem(this.USER_KEY, JSON.stringify(response.user));
      
      // Update the current user subject
      this.currentUserSubject.next(response.user);
    }
  }
  
  /**
   * Log the user out
   */
  logout(): void {
    if (this.isBrowser) {
      // Remove user and token from localStorage
      localStorage.removeItem(this.USER_KEY);
      localStorage.removeItem(this.TOKEN_KEY);
    }
    
    // Clear the current user
    this.currentUserSubject.next(null);
    
    // Redirect to login page
    this.router.navigate(['/login']);

    window.location.reload();
  }
  
  /**
   * Check if the user is authenticated
   */
  isAuthenticated(): boolean {
    if (!this.isBrowser) return false;
    
    const token = localStorage.getItem(this.TOKEN_KEY);
    
    // Also check the current user value
    const isAuthenticated = !!token && !!this.currentUserSubject.value;
    
    // If token exists but currentUser doesn't, reload from storage
    if (token && !this.currentUserSubject.value) {
      this.loadUserFromStorage();
    }
    
    return !!token;
  }
  
  /**
   * Get current user data
   */
  getCurrentUser(): User | null {
    return this.currentUserSubject.value;
  }
  
  /**
   * Get the auth token
   */
  getToken(): string | null {
    if (!this.isBrowser) return null;
    
    return localStorage.getItem(this.TOKEN_KEY);
  }
  
  /**
   * Handle HTTP errors
   */
  private handleError(error: HttpErrorResponse) {
    let errorMessage = 'An unknown error occurred';
    
    if (error.error instanceof ErrorEvent) {
      // Client-side error
      errorMessage = `Error: ${error.error.message}`;
    } else {
      // Server-side error
      if (error.status === 401) {
        errorMessage = 'Invalid credentials. Please try again.';
      } else if (error.status === 400) {
        // Try to extract validation errors
        if (error.error && typeof error.error === 'object') {
          const validationErrors = [];
          for (const key in error.error) {
            if (error.error.hasOwnProperty(key)) {
              validationErrors.push(error.error[key]);
            }
          }
          if (validationErrors.length > 0) {
            errorMessage = validationErrors.join(' ');
          } else {
            errorMessage = 'Invalid data provided. Please check your input.';
          }
        } else if (typeof error.error === 'string') {
          errorMessage = error.error;
        }
      } else if (error.error && typeof error.error === 'string') {
        errorMessage = error.error;
      }
    }
    
    return throwError(() => new Error(errorMessage));
  }
}