import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

interface BusinessCategory {
  code: string;
  name: string;
}

interface CoverageLimit {
  value: string;
  display: string;
}

@Component({
  selector: 'app-final-page',
  standalone: true,
  templateUrl: './final-page.component.html',
  styleUrls: ['./final-page.component.css'],
  imports: [CommonModule, FormsModule]
})
export class FinalPageComponent implements OnInit {
  // Form fields
  isNonProfit: string = '';
  businessDescription: string = '';
  additionalServices: string = '';
  businessYear: string = '';
  executiveOfficers: number | null = null;
  employeeCount: number | null = null;
  
  // New form fields from the image
  hasLiabilityClaims: string = '';
  claimsCount: number | null = null;
  claimsType: string = '';
  hasHazardousOperations: string = '';
  businessCategory: string = '';
  
  // Added fields
  annualRevenue: number | null = null;
  coverageLimit: string = '';
  
  businessCategories: BusinessCategory[] = [
    { code: '2382', name: 'Building Equipment Contractors' },
    { code: '2383', name: 'Building Finishing Contractors' },
    { code: '4231', name: 'Motor Vehicle and Parts Dealers (Wholesale)' },
    { code: '4232', name: 'Furniture and Home Furnishings Wholesalers' },
    { code: '4243', name: 'Apparel and Piece Goods Merchants (Wholesale)' },
    { code: '4451', name: 'Grocery Stores' },
    { code: '4452', name: 'Specialty Food Stores' },
    { code: '4461', name: 'Health and Personal Care Stores' },
    { code: '4481', name: 'Clothing Stores' },
    { code: '4511', name: 'Sporting Goods, Hobby, and Musical Instrument Stores' },
    { code: '4529', name: 'Other General Merchandise Stores' },
    { code: '5121', name: 'Motion Picture and Video Industries' },
    { code: '5312', name: 'Offices of Real Estate Agents and Brokers' },
    { code: '5414', name: 'Specialized Design Services' },
    { code: '5416', name: 'Management, Scientific, and Technical Consulting' },
    { code: '5419', name: 'Other Professional, Scientific, and Technical Services' },
    { code: '5617', name: 'Services to Buildings and Dwellings' },
    { code: '7223', name: 'Special Food Services (Catering, Food Trucks)' },
    { code: '7225', name: 'Restaurants and Other Eating Places' },
    { code: '8121', name: 'Personal Care Services (Salons, Barber Shops)' },
    { code: '8129', name: 'Other Personal Services' }
  ];
  
  // Coverage limit options
  coverageLimits: CoverageLimit[] = [
    { value: '10000', display: '$10,000' },
    { value: '25000', display: '$25,000' },
    { value: '50000', display: '$50,000' },
    { value: '75000', display: '$75,000' },
    { value: '100000', display: '$100,000' },
    { value: '250000', display: '$250,000' },
    { value: '500000', display: '$500,000' },
    { value: '1000000', display: '$1,000,000' }
  ];
  
  // Form state
  showErrors = false;
  currentStep = 3;
  
  // Session storage key
  private readonly STORAGE_KEY = 'insurance_quote_data';
  
  constructor(private router: Router) {}
  
  ngOnInit(): void {
    this.loadSavedData();
  }
  
  /**
   * Loads stored form data if available
   */
  loadSavedData(): void {
    const savedData = sessionStorage.getItem(this.STORAGE_KEY);
    if (savedData) {
      const parsedData = JSON.parse(savedData);
      
      // Populate fields from stored data
      this.isNonProfit = parsedData.isNonProfit || '';
      this.businessDescription = parsedData.businessDescription || '';
      this.additionalServices = parsedData.additionalServices || '';
      this.businessYear = parsedData.businessYear || '';
      this.executiveOfficers = parsedData.executiveOfficers;
      this.employeeCount = parsedData.employeeCount;
      
      // New fields
      this.hasLiabilityClaims = parsedData.hasLiabilityClaims || '';
      this.claimsCount = parsedData.claimsCount;
      this.claimsType = parsedData.claimsType || '';
      this.hasHazardousOperations = parsedData.hasHazardousOperations || '';
      this.businessCategory = parsedData.businessCategory || '';
      
      // Added fields
      this.annualRevenue = parsedData.annualRevenue;
      this.coverageLimit = parsedData.coverageLimit || '';
    }
  }
  
  /**
   * Saves current form data to session storage
   */
  saveFormData(): void {
    const savedData = this.getSavedDataObject();
    const updatedData = {
      ...savedData,
      // Business details
      isNonProfit: this.isNonProfit,
      businessDescription: this.businessDescription,
      additionalServices: this.additionalServices,
      businessYear: this.businessYear,
      executiveOfficers: this.executiveOfficers,
      employeeCount: this.employeeCount,
      // Additional fields
      hasLiabilityClaims: this.hasLiabilityClaims,
      claimsCount: this.claimsCount,
      claimsType: this.claimsType,
      hasHazardousOperations: this.hasHazardousOperations,
      businessCategory: this.businessCategory,
      // Added fields
      annualRevenue: this.annualRevenue,
      coverageLimit: this.coverageLimit
    };
    
    sessionStorage.setItem(this.STORAGE_KEY, JSON.stringify(updatedData));
  }
  
  /**
   * Retrieve the current session storage data as an object
   */
  private getSavedDataObject(): any {
    const savedData = sessionStorage.getItem(this.STORAGE_KEY);
    return savedData ? JSON.parse(savedData) : {};
  }
  
  /**
   * Validates the form before proceeding
   */
  validateForm(): boolean {
    // Required fields validation
    if (!this.businessDescription || !this.businessYear || 
        !this.hasLiabilityClaims || !this.hasHazardousOperations || 
        !this.businessCategory || !this.annualRevenue || !this.coverageLimit) {
      return false;
    }
    
    // Revenue validation
    if (this.annualRevenue <= 0) {
      return false;
    }
    
    // Conditional validation for claims details
    if (this.hasLiabilityClaims === 'Yes' && 
        (!this.claimsCount || this.claimsCount < 1 || !this.claimsType)) {
      return false;
    }
    
    // Business year validation (must be a valid year)
    const yearPattern = /^\d{4}$/;
    if (!yearPattern.test(this.businessYear)) {
      return false;
    }
    
    // Validate year is not in the future
    const currentYear = new Date().getFullYear();
    const year = parseInt(this.businessYear);
    if (year > currentYear) {
      return false;
    }
    
    return true;
  }
  
  /**
   * Check if a step is active
   */
  isStepActive(step: number): boolean {
    return this.currentStep === step;
  }
  
  /**
   * Navigate to the next step
   */
  nextStep(): void {
    this.showErrors = true;
    
    if (this.validateForm()) {
      // Save form data
      this.saveFormData();
      
      // Navigate to next page
      this.router.navigate(['/coverage-details']);
    } else {
      // Scroll to the first error
      const firstError = document.querySelector('.error');
      if (firstError) {
        firstError.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }
    }
  }
  
  /**
   * Navigate back to the previous step
   */
  previousStep(): void {
    // Save data before navigating back
    this.saveFormData();
    this.router.navigate(['/next-page']);
  }
} 