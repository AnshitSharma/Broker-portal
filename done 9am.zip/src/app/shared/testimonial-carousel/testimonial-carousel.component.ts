import { Component, OnInit, OnDestroy, AfterViewInit, Inject, PLATFORM_ID } from '@angular/core';
import { CommonModule, isPlatformBrowser } from '@angular/common';

@Component({
  selector: 'app-testimonial-carousel',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './testimonial-carousel.component.html',
  styleUrls: ['./testimonial-carousel.component.css']
})
export class TestimonialCarouselComponent implements OnInit, AfterViewInit, OnDestroy {
  
  currentIndex = 0;
  slideWidth = 100; // 100%
  intervalId: any = null;
  
  // Touch event handling
  touchStartX = 0;
  touchEndX = 0;
  
  // Flag to check if code is running in browser
  private isBrowser: boolean;
  
  constructor(@Inject(PLATFORM_ID) platformId: Object) {
    this.isBrowser = isPlatformBrowser(platformId);
  }

  ngOnInit(): void {
    // Initialize component
  }
  
  ngAfterViewInit(): void {
    if (!this.isBrowser) return;
    
    this.initializeCarousel();
    this.startAutoAdvance();
    this.addEventListeners();
  }
  
  ngOnDestroy(): void {
    if (!this.isBrowser) return;
    
    // Clean up
    if (this.intervalId) {
      clearInterval(this.intervalId);
    }
  }
  
  private addEventListeners(): void {
    if (!this.isBrowser) return;
    
    // Add event listeners for hover events
    const carousel = document.querySelector('.insurance-carousel');
    if (carousel) {
      carousel.addEventListener('mouseenter', this.pauseCarousel.bind(this));
      carousel.addEventListener('mouseleave', this.resumeCarousel.bind(this));
      
      // Add touch event listeners properly
      carousel.addEventListener('touchstart', (e: Event) => {
        const touchEvent = e as unknown as TouchEvent;
        this.handleTouchStart(touchEvent);
      }, { passive: true });
      
      carousel.addEventListener('touchend', (e: Event) => {
        const touchEvent = e as unknown as TouchEvent;
        this.handleTouchEnd(touchEvent);
      }, { passive: true });
    }
    
    // Add click handlers for controls
    const prevButton = document.querySelector('.insurance-carousel-button-prev');
    const nextButton = document.querySelector('.insurance-carousel-button-next');
    
    if (prevButton) {
      prevButton.addEventListener('click', this.previousSlide.bind(this));
    }
    
    if (nextButton) {
      nextButton.addEventListener('click', this.nextSlide.bind(this));
    }
    
    // Add click handlers for indicators
    const indicators = document.querySelectorAll('.insurance-carousel-indicator');
    indicators.forEach(indicator => {
      indicator.addEventListener('click', (event: Event) => {
        const target = event.target as HTMLElement;
        const index = target.getAttribute('data-index');
        if (index) {
          this.goToSlide(parseInt(index));
        }
      });
    });
    
    // Add click handlers for avatar navigation
    const avatars = document.querySelectorAll('.insurance-carousel-avatar-item');
    avatars.forEach(avatar => {
      avatar.addEventListener('click', (event: Event) => {
        const target = event.target as HTMLElement;
        const index = target.getAttribute('data-index');
        if (index) {
          this.goToSlide(parseInt(index));
        }
      });
    });
  }
  
  initializeCarousel(): void {
    if (!this.isBrowser) return;
    this.updateCarousel();
  }
  
  previousSlide(): void {
    if (!this.isBrowser) return;
    
    const slides = document.querySelectorAll('.insurance-carousel-slide');
    this.currentIndex = (this.currentIndex === 0) ? slides.length - 1 : this.currentIndex - 1;
    this.updateCarousel();
  }
  
  nextSlide(): void {
    if (!this.isBrowser) return;
    
    const slides = document.querySelectorAll('.insurance-carousel-slide');
    this.currentIndex = (this.currentIndex === slides.length - 1) ? 0 : this.currentIndex + 1;
    this.updateCarousel();
  }
  
  goToSlide(index: number): void {
    if (!this.isBrowser) return;
    
    this.currentIndex = index;
    this.updateCarousel();
  }
  
  updateCarousel(): void {
    if (!this.isBrowser) return;
    
    const track = document.querySelector('.insurance-carousel-track');
    const slides = document.querySelectorAll('.insurance-carousel-slide');
    const indicators = document.querySelectorAll('.insurance-carousel-indicator');
    const avatars = document.querySelectorAll('.insurance-carousel-avatar-item');
    
    if (track) {
      (track as HTMLElement).style.transform = `translateX(-${this.currentIndex * this.slideWidth}%)`;
    }
    
    // Update active slide
    slides.forEach((slide, index) => {
      if (index === this.currentIndex) {
        slide.classList.add('active');
      } else {
        slide.classList.remove('active');
      }
    });
    
    // Update indicators
    indicators.forEach((indicator, index) => {
      if (index === this.currentIndex) {
        indicator.classList.add('active');
      } else {
        indicator.classList.remove('active');
      }
    });
    
    // Update avatars
    avatars.forEach((avatar, index) => {
      if (index === this.currentIndex) {
        avatar.classList.add('active');
      } else {
        avatar.classList.remove('active');
      }
    });
  }
  
  startAutoAdvance(): void {
    if (!this.isBrowser) return;
    
    this.intervalId = setInterval(() => {
      this.nextSlide();
    }, 5000);
  }
  
  pauseCarousel(): void {
    if (!this.isBrowser) return;
    
    if (this.intervalId) {
      clearInterval(this.intervalId);
      this.intervalId = null;
    }
  }
  
  resumeCarousel(): void {
    if (!this.isBrowser) return;
    
    if (!this.intervalId) {
      this.startAutoAdvance();
    }
  }
  
  // Touch event handling methods
  handleTouchStart(e: TouchEvent): void {
    if (!this.isBrowser) return;
    
    if (e.changedTouches && e.changedTouches.length > 0) {
      this.touchStartX = e.changedTouches[0].screenX;
    }
  }
  
  handleTouchEnd(e: TouchEvent): void {
    if (!this.isBrowser) return;
    
    if (e.changedTouches && e.changedTouches.length > 0) {
      this.touchEndX = e.changedTouches[0].screenX;
      this.handleSwipe();
    }
  }
  
  handleSwipe(): void {
    if (!this.isBrowser) return;
    
    const swipeThreshold = 50;
    
    if (this.touchEndX < this.touchStartX - swipeThreshold) {
      // Swipe left
      this.nextSlide();
    }
    
    if (this.touchEndX > this.touchStartX + swipeThreshold) {
      // Swipe right
      this.previousSlide();
    }
  }
}