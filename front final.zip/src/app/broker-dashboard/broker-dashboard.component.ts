import { Component, OnInit, HostListener, Renderer2, ElementRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { Router, NavigationEnd } from '@angular/router';
import { filter } from 'rxjs/operators';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { catchError, finalize, forkJoin, of } from 'rxjs';

interface ClientQuote {
  id: string;
  clientName: string;
  businessName: string;
  quoteDate: Date;
  premium: number;
  status: 'pending' | 'approved' | 'declined' | 'bound';
  coverageType: string;
}

interface ApiQuote {
  quoteId?: string | number;
  clientId?: number;
  businessName?: string;
  ownerFirstName?: string;
  ownerLastName?: string;
  status?: string;
  createdDate?: string;
  annualPremium?: number;
  monthlyPremium?: number;
  coverageList?: string;
  selectedCoverages?: Array<{
    name: string;
    description: string;
    isBaseCoverage: boolean;
    factorValue: number;
  }>;
}

interface ApiClient {
  clientId: number;
  clientName: string;
  businessName: string;
  email: string;
  phone: string;
  status: string;
  activePolicies: number;
}

interface RecentActivity {
  id: number;
  type: 'quote' | 'policy' | 'claim' | 'message';
  description: string;
  time: Date;
  clientName: string;
  icon: string;
}

interface Task {
  id: number;
  title: string;
  dueDate: Date;
  priority: 'high' | 'medium' | 'low';
  completed: boolean;
}

interface PieSegment {
  path: string;
  color: string;
}

interface QuoteNote {
  id: number;
  quoteId: string;
  author: string;
  date: Date;
  content: string;
}

interface ClientDetails {
  email: string;
  phone: string;
}

@Component({
  selector: 'app-broker-dashboard',
  standalone: true,
  imports: [CommonModule, RouterModule, FormsModule],
  templateUrl: './broker-dashboard.component.html',
  styleUrls: ['./broker-dashboard.component.css']
})
export class BrokerDashboardComponent implements OnInit {
  // Expose Math object to be used in template
  Math = Math;
  
  // API endpoints
  private apiBaseUrl = 'http://localhost:5075/api'; // Update with your actual API base URL
  private readonly AUTH_TOKEN_KEY = 'auth_token'; // Key for storing JWT token
  
  // Authentication state
  isAuthenticated: boolean = true; // Set to true for now, should be determined by auth service
  
  // UI State
  darkModeEnabled: boolean = false;
  sidebarCollapsed: boolean = false;
  mobileMenuOpen: boolean = false;
  currentRoute: string = '/dashboard';
  selectedQuote: ClientQuote | null = null;
  quoteToDelete: ClientQuote | null = null;
  statusToUpdate: string = '';
  
  // API and UI state
  isLoading: boolean = false;
  apiError: boolean = false;
  
  // Response messaging
  responseMessage: string = '';
  isSuccess: boolean = true;
  
  // View modes
  isViewMode: boolean = false;
  isEditMode: boolean = false;
  
  // Screen size detection
  isMobileView: boolean = false;
  
  // Pagination
  currentPage: number = 1;
  itemsPerPage: number = 10;
  totalPages: number = 1;
  
  // Broker details
  brokerName: string = 'John Broker';
  brokerRole: string = 'Insurance Specialist';
  
  // Dashboard stats
  pendingQuotes: number = 12;
  activeClients: number = 84;
  conversionRate: number = 68;
  quarterlyCommission: number = 24650;
  
  // Monthly targets
  targetNewClients: number = 15;
  actualNewClients: number = 11;
  targetRevenue: number = 35000;
  actualRevenue: number = 24650;
  
  // Filter and search states
  quoteStatusFilter: string = 'all';
  quoteSearchQuery: string = '';
  
  // Charts data
  performanceMonths: string[] = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'];
  performanceData: number[] = [18500, 22400, 19800, 26700, 22300, 24650];
  
  // Line of business data
  lineOfBusinessData: any[] = [
    { name: 'Bodily Injury and Property Damage', value: 35, color: '#CC7952' },
    { name: 'Products and Completed Operations', value: 25, color: '#4A6BD6' },
    { name: 'Advertising Injury', value: 15, color: '#42C0C0' },
    { name: 'Reputational Harm', value: 15, color: '#87D987' },
    { name: 'Independent Contractors', value: 10, color: '#87BD52' }
  ];
  
  // Pie chart segments
  pieSegments: PieSegment[] = [];
  
  // Recent activities
  recentActivities: RecentActivity[] = [
    { 
      id: 1, 
      type: 'quote', 
      description: 'New quote created', 
      time: new Date(2025, 3, 7, 14, 32), 
      clientName: 'Robert Johnson',
      icon: 'fa-file-invoice-dollar'
    },
    { 
      id: 2, 
      type: 'policy', 
      description: 'Policy bound', 
      time: new Date(2025, 3, 7, 11, 15), 
      clientName: 'Michael Chen',
      icon: 'fa-file-signature'
    },
    { 
      id: 3, 
      type: 'message', 
      description: 'New message received', 
      time: new Date(2025, 3, 7, 9, 45), 
      clientName: 'Sarah Williams',
      icon: 'fa-envelope'
    },
    { 
      id: 4, 
      type: 'claim', 
      description: 'Claim reported', 
      time: new Date(2025, 3, 6, 16, 22), 
      clientName: 'David Smith',
      icon: 'fa-exclamation-circle'
    },
    { 
      id: 5, 
      type: 'quote', 
      description: 'Quote declined', 
      time: new Date(2025, 3, 6, 13, 10), 
      clientName: 'Alicia Rodriguez',
      icon: 'fa-times-circle'
    }
  ];
  
  // Tasks
  tasks: Task[] = [
    { id: 1, title: 'Follow up with Robert Johnson', dueDate: new Date(2025, 3, 10), priority: 'high', completed: false },
    { id: 2, title: 'Renew Smith Construction policy', dueDate: new Date(2025, 3, 15), priority: 'medium', completed: false },
    { id: 3, title: 'Complete product training', dueDate: new Date(2025, 3, 12), priority: 'low', completed: true },
    { id: 4, title: 'Submit monthly reports', dueDate: new Date(2025, 3, 30), priority: 'high', completed: false },
    { id: 5, title: 'Client review meeting - AR Interior', dueDate: new Date(2025, 3, 18), priority: 'medium', completed: false }
  ];
  
  // Client details mapping for contact information
  clientDetails: {[key: string]: ClientDetails} = {
    'Robert Johnson': { email: 'robert.johnson@johnsonconsulting.com', phone: '(555) 123-4567' },
    'Sarah Williams': { email: 'sarah@artisanbakery.com', phone: '(555) 234-5678' },
    'Michael Chen': { email: 'michael@chentechsolutions.com', phone: '(555) 345-6789' },
    'Alicia Rodriguez': { email: 'alicia@arinteriordesign.com', phone: '(555) 456-7890' },
    'David Smith': { email: 'dsmith@smithconstruction.com', phone: '(555) 567-8901' },
    'Jennifer Lee': { email: 'jennifer@leemedicalsupplies.com', phone: '(555) 678-9012' },
    'William Brown': { email: 'william@brownassociates.com', phone: '(555) 789-0123' },
    'Emily Martinez': { email: 'emily@martinezfloral.com', phone: '(555) 890-1234' },
    'George Wilson': { email: 'george@wilsonplumbing.com', phone: '(555) 901-2345' },
    'Patricia Davis': { email: 'patricia@davislegal.com', phone: '(555) 012-3456' },
    'Jessica Thomas': { email: 'jessica@thomascatering.com', phone: '(555) 123-4567' },
    'Mark Anderson': { email: 'mark@andersonlandscaping.com', phone: '(555) 234-5678' },
    'Susan Moore': { email: 'susan@mooremktg.com', phone: '(555) 345-6789' },
    'Kevin Taylor': { email: 'kevin@taylorauto.com', phone: '(555) 456-7890' },
    'Elizabeth Clark': { email: 'elizabeth@clarkdental.com', phone: '(555) 567-8901' },
    'John Smith': { email: 'john.smith@acmeconsulting.com', phone: '(555) 123-4567' }
  };
  
  // Notes for quotes
  quoteNotes: QuoteNote[] = [
    {
      id: 1,
      quoteId: 'Q-39485',
      author: 'John Broker',
      date: new Date(2025, 3, 2, 14, 30),
      content: 'Client requested a follow-up call to discuss coverage details.'
    },
    {
      id: 2,
      quoteId: 'Q-39485',
      author: 'Maria Underwriter',
      date: new Date(2025, 3, 3, 10, 15),
      content: 'Additional information needed regarding business operations.'
    },
    {
      id: 3,
      quoteId: 'Q-39471',
      author: 'John Broker',
      date: new Date(2025, 3, 3, 16, 45),
      content: 'Client accepted the coverage options. Ready for underwriting approval.'
    },
    {
      id: 4,
      quoteId: 'Q-39465',
      author: 'John Broker',
      date: new Date(2025, 3, 4, 11, 20),
      content: 'Policy bound. All documents delivered to client.'
    },
    {
      id: 5,
      quoteId: 'Q-39458',
      author: 'John Broker',
      date: new Date(2025, 3, 5, 9, 30),
      content: 'Client declined due to budget constraints. Will follow up in 3 months.'
    },
    {
      id: 6,
      quoteId: '22',
      author: 'John Broker',
      date: new Date(2025, 3, 2, 14, 30),
      content: 'Client requested a follow-up call to discuss coverage details.'
    }
  ];
  
  // Coverage descriptions
  coverageDescriptions: {[key: string]: string} = {
    'Bodily Injury and Property Damage': 'Covers claims for physical injuries to others and damage to their property resulting from your business operations.',
    'Products and Completed Operations': 'Protects against liability arising from products you sell or services you provide after the product is sold or the work is completed.',
    'Advertising Injury': 'Covers liability for damages arising from your advertising, such as copyright infringement, slander, libel, or invasion of privacy.',
    'Legal Defense Cost': 'Covers legal defense costs for covered claims.',
    'Reputational Harm': 'Provides coverage for claims alleging damage to someone\'s reputation, such as defamation, slander, or libel.',
    'Independent Contractors': 'Extends liability protection to cover independent contractors working on behalf of your business.'
  };
  
  // User preferences
  notificationsEnabled: boolean = true;
  
  // Recent quotes - expanded with more data
  allQuotes: ClientQuote[] = [
    { 
      id: 'Q-39485', 
      clientName: 'Robert Johnson', 
      businessName: 'Johnson Consulting LLC', 
      quoteDate: new Date(2025, 3, 2), 
      premium: 2850, 
      status: 'pending',
      coverageType: 'Bodily Injury and Property Damage'
    },
    { 
      id: 'Q-39471', 
      clientName: 'Sarah Williams', 
      businessName: 'Artisan Bakery', 
      quoteDate: new Date(2025, 3, 3), 
      premium: 3200, 
      status: 'approved',
      coverageType: 'Products and Completed Operations'
    },
    { 
      id: 'Q-39465', 
      clientName: 'Michael Chen', 
      businessName: 'Chen Technology Solutions', 
      quoteDate: new Date(2025, 3, 4), 
      premium: 5100, 
      status: 'bound',
      coverageType: 'Advertising Injury'
    },
    { 
      id: 'Q-39458', 
      clientName: 'Alicia Rodriguez', 
      businessName: 'AR Interior Design', 
      quoteDate: new Date(2025, 3, 5), 
      premium: 1950, 
      status: 'declined',
      coverageType: 'Reputational Harm'
    },
    { 
      id: 'Q-39442', 
      clientName: 'David Smith', 
      businessName: 'Smith Construction Inc.', 
      quoteDate: new Date(2025, 3, 6), 
      premium: 8750, 
      status: 'approved',
      coverageType: 'Independent Contractors'
    },
    { 
      id: 'Q-39441', 
      clientName: 'Jennifer Lee', 
      businessName: 'Lee Medical Supplies', 
      quoteDate: new Date(2025, 3, 1), 
      premium: 4250, 
      status: 'pending',
      coverageType: 'Bodily Injury and Property Damage'
    },
    { 
      id: 'Q-39440', 
      clientName: 'William Brown', 
      businessName: 'Brown & Associates', 
      quoteDate: new Date(2025, 2, 29), 
      premium: 3120, 
      status: 'approved',
      coverageType: 'Advertising Injury'
    },
    { 
      id: 'Q-39439', 
      clientName: 'Emily Martinez', 
      businessName: 'Martinez Floral Design', 
      quoteDate: new Date(2025, 2, 28), 
      premium: 1875, 
      status: 'bound',
      coverageType: 'Products and Completed Operations'
    },
    { 
      id: 'Q-39438', 
      clientName: 'George Wilson', 
      businessName: 'Wilson Plumbing', 
      quoteDate: new Date(2025, 2, 27), 
      premium: 2950, 
      status: 'pending',
      coverageType: 'Independent Contractors'
    },
    { 
      id: 'Q-39437', 
      clientName: 'Patricia Davis', 
      businessName: 'Davis Legal Services', 
      quoteDate: new Date(2025, 2, 26), 
      premium: 5450, 
      status: 'approved',
      coverageType: 'Reputational Harm'
    },
    { 
      id: 'Q-39436', 
      clientName: 'Jessica Thomas', 
      businessName: 'Thomas Catering', 
      quoteDate: new Date(2025, 2, 25), 
      premium: 2150, 
      status: 'declined',
      coverageType: 'Products and Completed Operations'
    },
    { 
      id: 'Q-39435', 
      clientName: 'Mark Anderson', 
      businessName: 'Anderson Landscaping', 
      quoteDate: new Date(2025, 2, 24), 
      premium: 3400, 
      status: 'bound',
      coverageType: 'Bodily Injury and Property Damage'
    },
    { 
      id: 'Q-39434', 
      clientName: 'Susan Moore', 
      businessName: 'Moore Marketing Agency', 
      quoteDate: new Date(2025, 2, 23), 
      premium: 4950, 
      status: 'pending',
      coverageType: 'Advertising Injury'
    },
    { 
      id: 'Q-39433', 
      clientName: 'Kevin Taylor', 
      businessName: 'Taylor Auto Repair', 
      quoteDate: new Date(2025, 2, 22), 
      premium: 6750, 
      status: 'approved',
      coverageType: 'Independent Contractors'
    },
    { 
      id: 'Q-39432', 
      clientName: 'Elizabeth Clark', 
      businessName: 'Clark Dental Office', 
      quoteDate: new Date(2025, 2, 21), 
      premium: 7200, 
      status: 'pending',
      coverageType: 'Bodily Injury and Property Damage'
    }
  ];

  // Clients data - will be updated from API
  clients: ApiClient[] = [];
  
  constructor(
    private router: Router, 
    private http: HttpClient,
    private renderer: Renderer2,
    private elementRef: ElementRef
  ) {
    // Subscribe to router events to track current route
    this.router.events
      .pipe(filter(event => event instanceof NavigationEnd))
      .subscribe((event: any) => {
        this.currentRoute = event.url;
        // Reset to first page when changing routes
        this.currentPage = 1;
        // Close mobile menu when navigating
        this.mobileMenuOpen = false;
        // Reset any selected quotes or panels
        this.closeQuotePanel();
        
        // Load quotes if on quotes page
        if (this.currentRoute === '/quotes') {
          this.loadQuotes();
        } else if (this.currentRoute === '/dashboard') {
          this.loadDashboardData();
        }
      });
      
    // Check initial screen size
    this.checkScreenSize();
  }
  
  // Host listener to detect screen size changes
  @HostListener('window:resize', ['$event'])
  onResize() {
    this.checkScreenSize();
  }
  
  // Check if the screen is mobile size
  checkScreenSize() {
    this.isMobileView = window.innerWidth < 992;
    // Auto-collapse sidebar on mobile
    if (this.isMobileView && !this.mobileMenuOpen) {
      this.sidebarCollapsed = true;
    }
  }
  
  ngOnInit(): void {
    // Check authentication status
    this.checkAuthentication();
    
    // Check if dark mode is saved in localStorage
    const savedDarkMode = localStorage.getItem('darkMode');
    if (savedDarkMode) {
      this.darkModeEnabled = JSON.parse(savedDarkMode);
      document.body.classList.toggle('dark-mode', this.darkModeEnabled);
    }
    
    // Check if sidebar state is saved in localStorage
    const savedSidebarState = localStorage.getItem('sidebarCollapsed');
    if (savedSidebarState) {
      this.sidebarCollapsed = JSON.parse(savedSidebarState);
    }
    
    // Initialize current route
    this.currentRoute = this.router.url;
    
    // Calculate total pages for quotes pagination
    this.totalPages = Math.ceil(this.allQuotes.length / this.itemsPerPage);
    
    // Check screen size on init
    this.checkScreenSize();
    
    // Load data based on current route
    if (this.currentRoute === '/quotes') {
      this.loadQuotes();
    } else if (this.currentRoute === '/dashboard') {
      this.loadDashboardData();
    }
  }
  
  /**
   * Check if user is authenticated
   */
  checkAuthentication(): void {
    const token = localStorage.getItem(this.AUTH_TOKEN_KEY);
    this.isAuthenticated = !!token;
    
    // If not authenticated and on a protected route, redirect to login
    if (!this.isAuthenticated && this.currentRoute !== '/login') {
      // Store current location to redirect back after login
      sessionStorage.setItem('redirectUrl', this.currentRoute);
      
      // Show a message that we're redirecting (can be enhanced with a toast notification)
      console.log('Authentication required. Redirecting to login...');
      
      // Don't automatically redirect yet - just warn user
      // Uncomment the next line to enable automatic redirect
      // this.router.navigate(['/login']);
    }
  }

  /**
   * Load dashboard data (combines quotes and clients data)
   */
  loadDashboardData(): void {
    this.isLoading = true;
    this.apiError = false;

    // Use forkJoin to make multiple API calls in parallel
    forkJoin({
      quotes: this.http.get<any[]>(`${this.apiBaseUrl}/Quote/insurance-quotes`).pipe(
        catchError(error => {
          console.error('Error loading quotes:', error);
          // Use fallback data
          return of([]);
        })
      ),
      clients: this.http.get<any[]>(`${this.apiBaseUrl}/Clients`).pipe(
        catchError(error => {
          console.error('Error loading clients:', error);
          // Use fallback data
          return of([]);
        })
      )
    }).pipe(
      finalize(() => {
        this.isLoading = false;

        // Calculate dashboard metrics regardless of API success
        this.calculateDashboardMetrics();
      })
    ).subscribe(results => {
      // Process quotes data if API returned successfully
      if (Array.isArray(results.quotes) && results.quotes.length > 0) {
        this.processQuotesArray(results.quotes);
      }
      
      // Process clients data if API returned successfully  
      if (Array.isArray(results.clients) && results.clients.length > 0) {
        this.clients = results.clients;
        this.updateClientDetails();
      }
    });
  }

  /**
   * Update client details from API data
   */
  updateClientDetails(): void {
    // Update clientDetails map for lookup
    this.clients.forEach(client => {
      this.clientDetails[client.clientName] = {
        email: client.email || 'No email available',
        phone: client.phone || 'No phone available'
      };
    });
  }

  /**
   * Calculate dashboard metrics from quotes and clients data
   */
  calculateDashboardMetrics(): void {
    // Count pending quotes
    this.pendingQuotes = this.allQuotes.filter(q => q.status === 'pending').length;
    
    // Count active clients
    if (this.clients.length > 0) {
      this.activeClients = this.clients.filter(c => c.status === 'Active').length;
    } else {
      // Use fallback data if no clients loaded
      this.activeClients = 84; 
    }
    
    // Calculate conversion rate
    if (this.clients.length > 0) {
      const activeClients = this.clients.filter(c => c.status === 'Active').length;
      const prospectClients = this.clients.filter(c => c.status === 'Prospect').length;
      const totalRelevantClients = activeClients + prospectClients;
      
      if (totalRelevantClients > 0) {
        this.conversionRate = Math.round((activeClients / totalRelevantClients) * 100);
      }
    } else {
      // Use fallback data
      this.conversionRate = 68;
    }
    
    // Calculate commission and revenue
    this.calculateCommissionAndRevenue();
    
    // Update actual new clients (clients with 'Prospect' status)
    if (this.clients.length > 0) {
      this.actualNewClients = this.clients.filter(c => c.status === 'Prospect').length;
    } else {
      // Use fallback data
      this.actualNewClients = 11;
    }
  }

  /**
   * Calculate commission and revenue from quotes
   */
  calculateCommissionAndRevenue(): void {
    let monthlyCommission = 0;
    const currentMonth = new Date().getMonth();
    const currentYear = new Date().getFullYear();
    
    // Sum up monthly premiums for quotes created in current month
    this.allQuotes.forEach(quote => {
      const quoteDate = new Date(quote.quoteDate);
      if (quoteDate.getMonth() === currentMonth && quoteDate.getFullYear() === currentYear) {
        // Calculate commission as 10% of monthly premium
        const monthlyPremium = quote.premium / 12;
        monthlyCommission += monthlyPremium * 0.1;
      }
    });
    
    // Round to whole number
    monthlyCommission = Math.round(monthlyCommission);
    
    // Update dashboard metrics
    this.actualRevenue = monthlyCommission;
    this.quarterlyCommission = monthlyCommission * 3;
    
    // Update performance chart (last value is current month's commission)
    this.performanceData[this.performanceData.length - 1] = monthlyCommission;
  }
  
  /**
   * Get auth token for API requests
   */
  getAuthHeaders(): HttpHeaders {
    const token = localStorage.getItem(this.AUTH_TOKEN_KEY);
    return new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token || ''}`
    });
  }
  
  /**
   * Handle authentication errors from API responses
   */
  handleAuthError(error: any): void {
    if (error.status === 401) {
      // Unauthorized - token expired or invalid
      this.responseMessage = 'Your session has expired. Please log in again.';
      this.isSuccess = false;
      
      // Clear token
      localStorage.removeItem(this.AUTH_TOKEN_KEY);
      
      // Store current location
      sessionStorage.setItem('redirectUrl', this.currentRoute);
      
      // Redirect to login page after a short delay
      setTimeout(() => this.router.navigate(['/login']), 2000);
    }
  }
  
  // Load quotes from API with JWT authentication
  loadQuotes(): void {
    this.isLoading = true;
    this.apiError = false;
    
    // If not authenticated, show message and return
    if (!this.isAuthenticated) {
      this.responseMessage = 'Authentication required. Please log in to view quotes.';
      this.isSuccess = false;
      this.isLoading = false;
      return;
    }
    
    // Define API endpoint
    const quotesUrl = `${this.apiBaseUrl}/Quote/insurance-quotes`;
    
    // Set HTTP headers with authorization
    const httpOptions = {
      headers: this.getAuthHeaders()
    };
    
    // Make GET request with JWT token
    this.http.get<any>(quotesUrl, httpOptions)
      .pipe(
        catchError(error => {
          console.error('Error loading quotes', error);
          
          // Handle authentication errors
          if (error.status === 401) {
            this.handleAuthError(error);
          } else {
            this.responseMessage = `Error loading quotes: ${error.message || 'Unknown error'}. Using cached data.`;
            this.isSuccess = false;
          }
          
          // Return empty array to continue with cached data
          return of([]);
        }),
        finalize(() => {
          this.isLoading = false;
        })
      )
      .subscribe(response => {
        // Process API response if received
        if (Array.isArray(response) && response.length > 0) {
          this.processQuotesArray(response);
        }
          
        // Update total pages
        this.totalPages = Math.ceil(this.allQuotes.length / this.itemsPerPage);
          
        // Set success message
        this.responseMessage = 'Quotes loaded successfully.';
        this.isSuccess = true;
          
        // Reset after 3 seconds
        setTimeout(() => {
          this.responseMessage = '';
        }, 3000);
      });
  }
  
  // Process array of quotes from API
  processQuotesArray(quotesArray: any[]): void {
    // If response array is valid and not empty
    if (Array.isArray(quotesArray) && quotesArray.length > 0) {
      // Temp array to hold processed quotes
      const processedQuotes: ClientQuote[] = [];
      
      quotesArray.forEach(apiQuote => {
        const processedQuote = this.mapApiQuoteToClientQuote(apiQuote);
        if (processedQuote) {
          processedQuotes.push(processedQuote);
        }
      });
      
      // If we have processed quotes, replace the existing ones
      if (processedQuotes.length > 0) {
        this.allQuotes = processedQuotes;
      }
    }
  }
  
  // Map API quote object to ClientQuote interface
  mapApiQuoteToClientQuote(apiQuote: any): ClientQuote | null {
    if (!apiQuote) return null;
    
    // Extract the main coverage type from selectedCoverages if available
    let coverageType = 'General Liability';
    if (apiQuote.selectedCoverages && apiQuote.selectedCoverages.length > 0) {
      coverageType = apiQuote.selectedCoverages[0].name;
    } else if (apiQuote.coverageType) {
      coverageType = apiQuote.coverageType;
    }
    
    // Handle different API response formats
    let quoteId = 'Q-000000';
    if (apiQuote.quoteId) {
      quoteId = typeof apiQuote.quoteId === 'string' ? 
      apiQuote.quoteId : 
      `Q-${apiQuote.quoteId.toString().padStart(5, '0')}`;
  } else if (apiQuote.id) {
    quoteId = typeof apiQuote.id === 'string' ? 
      apiQuote.id : 
      `Q-${apiQuote.id.toString().padStart(5, '0')}`;
  } else if (apiQuote.quoteNumber) {
    quoteId = apiQuote.quoteNumber;
  }
  
  // Get client name from either firstName/lastName or clientName
  let clientName = 'Unknown Client';
  if (apiQuote.clientName) {
    clientName = apiQuote.clientName;
  } else if (apiQuote.ownerFirstName && apiQuote.ownerLastName) {
    clientName = `${apiQuote.ownerFirstName} ${apiQuote.ownerLastName}`;
  }
  
  // Get premium from annualPremium or monthlyPremium*12
  let premium = 0;
  if (typeof apiQuote.annualPremium === 'number') {
    premium = apiQuote.annualPremium;
  } else if (typeof apiQuote.premium === 'number') {
    premium = apiQuote.premium;
  } else if (typeof apiQuote.monthlyPremium === 'number') {
    premium = apiQuote.monthlyPremium * 12;
  }
  
  return {
    id: quoteId,
    clientName: clientName,
    businessName: apiQuote.businessName || 'Unknown Business',
    quoteDate: apiQuote.createdDate ? new Date(apiQuote.createdDate) : new Date(),
    premium: premium,
    status: (apiQuote.status || 'pending').toLowerCase() as any,
    coverageType: coverageType
  };
}

// Toggle sidebar collapsed state
toggleSidebar(): void {
  this.sidebarCollapsed = !this.sidebarCollapsed;
  localStorage.setItem('sidebarCollapsed', JSON.stringify(this.sidebarCollapsed));
  
  // On mobile, also control the mobile menu state
  if (this.isMobileView) {
    this.mobileMenuOpen = !this.sidebarCollapsed;
  }
}

// Toggle mobile menu specifically
toggleMobileMenu(): void {
  this.mobileMenuOpen = !this.mobileMenuOpen;
  // When opening mobile menu, make sure sidebar isn't collapsed
  if (this.mobileMenuOpen) {
    this.sidebarCollapsed = false;
  }
}

// Close mobile menu
closeMobileMenu(): void {
  this.mobileMenuOpen = false;
}

// Toggle dark mode
toggleDarkMode(): void {
  this.darkModeEnabled = !this.darkModeEnabled;
  document.body.classList.toggle('dark-mode', this.darkModeEnabled);
  localStorage.setItem('darkMode', JSON.stringify(this.darkModeEnabled));
}

// Toggle notifications
toggleNotifications(): void {
  this.notificationsEnabled = !this.notificationsEnabled;
  // In a real app, you would update user preferences in backend
}

// Create a new quote
createNewQuote(): void {
  this.router.navigate(['/insurance']);
  // Close mobile menu when navigating
  this.mobileMenuOpen = false;
}

// Calculate progress percentage for targets
getProgressPercentage(actual: number, target: number): number {
  return Math.min(Math.round((actual / target) * 100), 100);
}

// Get filtered quotes based on search and filter
getFilteredQuotes(): ClientQuote[] {
  let filteredQuotes = this.allQuotes;
  
  // Apply status filter
  if (this.quoteStatusFilter !== 'all') {
    filteredQuotes = filteredQuotes.filter(quote => quote.status === this.quoteStatusFilter);
  }
  
  // Apply search filter
  if (this.quoteSearchQuery.trim() !== '') {
    const search = this.quoteSearchQuery.toLowerCase();
    filteredQuotes = filteredQuotes.filter(quote => 
      quote.id.toLowerCase().includes(search) ||
      quote.clientName.toLowerCase().includes(search) ||
      quote.businessName.toLowerCase().includes(search) ||
      quote.coverageType.toLowerCase().includes(search)
    );
  }
  
  // Update total pages
  this.totalPages = Math.ceil(filteredQuotes.length / this.itemsPerPage);
  
  // Apply pagination
  const startIndex = (this.currentPage - 1) * this.itemsPerPage;
  const endIndex = startIndex + this.itemsPerPage;
  return filteredQuotes.slice(startIndex, endIndex);
}

// Get status class for UI styling
getStatusClass(status: string): string {
  switch(status) {
    case 'pending': return 'status-pending';
    case 'approved': return 'status-approved';
    case 'bound': return 'status-bound';
    case 'declined': return 'status-declined';
    default: return '';
  }
}

// Get page numbers array for pagination display
getPageNumbers(): number[] {
  const pages: number[] = [];
  const maxDisplayPages = 5;
  
  if (this.totalPages <= maxDisplayPages) {
    // Display all pages if total pages is less than max display
    for (let i = 1; i <= this.totalPages; i++) {
      pages.push(i);
    }
  } else {
    // Display a subset of pages with current page in middle if possible
    const halfMax = Math.floor(maxDisplayPages / 2);
    
    let startPage = Math.max(this.currentPage - halfMax, 1);
    let endPage = startPage + maxDisplayPages - 1;
    
    if (endPage > this.totalPages) {
      endPage = this.totalPages;
      startPage = Math.max(endPage - maxDisplayPages + 1, 1);
    }
    
    for (let i = startPage; i <= endPage; i++) {
      pages.push(i);
    }
  }
  
  return pages;
}

// Change page in pagination
changePage(page: number): void {
  if (page < 1 || page > this.totalPages) {
    return;
  }
  this.currentPage = page;
}

// View quote details - modified to check if quote is bound
viewQuoteDetails(quote: ClientQuote): void {
  // If quote is bound, do not allow viewing details
  if (quote.status === 'bound') {
    return;
  }
  
  // Close any open panels first
  this.closeQuotePanel();
  
  // Set the selected quote and view mode
  this.selectedQuote = quote;
  this.isViewMode = true;
  this.isEditMode = false;
}

// Close quote panel
closeQuotePanel(): void {
  this.selectedQuote = null;
  this.isViewMode = false;
  this.isEditMode = false;
}

// Switch to edit mode
switchToEditMode(): void {
  if (this.selectedQuote && this.selectedQuote.status !== 'bound') {
    this.isViewMode = false;
    this.isEditMode = true;
    this.statusToUpdate = this.selectedQuote.status;
  }
}

// Edit quote - modified to check if quote is bound
editQuote(quote: ClientQuote): void {
  // If quote is bound, do not allow editing
  if (quote.status === 'bound') {
    return;
  }
  
  // Close any open panels first
  this.closeQuotePanel();
  
  // Set the selected quote and edit mode
  this.selectedQuote = quote;
  this.statusToUpdate = quote.status;
  this.isViewMode = false;
  this.isEditMode = true;
}

// Cancel edit
cancelEdit(): void {
  // Return to view mode if we were viewing a quote
  if (this.selectedQuote) {
    this.isViewMode = true;
    this.isEditMode = false;
  } else {
    this.closeQuotePanel();
  }
}

// Save quote changes
saveQuoteChanges(): void {
  if (!this.selectedQuote) return;
  
  this.updateQuoteStatus(this.selectedQuote, this.statusToUpdate);
  
  // Switch back to view mode after saving
  this.isEditMode = false;
  this.isViewMode = true;
}

// Confirm delete quote - modified to check if quote is bound
confirmDeleteQuote(quote: ClientQuote): void {
  // If quote is bound, do not allow deletion
  if (quote.status === 'bound') {
    return;
  }
  
  // Close any other panels first
  this.closeQuotePanel();
  
  // Set quote to delete
  this.quoteToDelete = quote;
}

// Cancel delete quote
cancelDeleteQuote(): void {
  this.quoteToDelete = null;
}

// Delete quote using API with JWT authentication
deleteQuote(): void {
  if (!this.quoteToDelete) return;
  
  // Check if authenticated
  if (!this.isAuthenticated) {
    this.responseMessage = 'Authentication required. Please log in to delete quotes.';
    this.isSuccess = false;
    
    // Store current location
    sessionStorage.setItem('redirectUrl', this.currentRoute);
    
    // Don't automatically redirect - just warn user
    return;
  }
  
  this.isLoading = true;
  
  // Get the ID in the correct format
  let quoteId = this.quoteToDelete.id;
  // If ID starts with Q-, remove it to get the numeric ID
  if (quoteId.startsWith('Q-')) {
    quoteId = quoteId.substring(2);
  }
  
  // Define API endpoint
  const deleteUrl = `${this.apiBaseUrl}/QuoteListItem/${quoteId}`;
  
  // Set HTTP headers with authorization
  const httpOptions = {
    headers: this.getAuthHeaders()
  };
  
  // Make delete request with JWT token
  this.http.delete(deleteUrl, httpOptions)
    .pipe(
      catchError(error => {
        console.error('Error deleting quote', error);
        
        // Handle authentication errors
        if (error.status === 401) {
          this.handleAuthError(error);
        } else {
          this.responseMessage = `Error deleting quote: ${error.message || error.statusText || 'Unknown error'}`;
          this.isSuccess = false;
        }
        
        return of(null);
      }),
      finalize(() => {
        this.isLoading = false;
      })
    )
    .subscribe(response => {
      // Check if response exists and there was no error
      if (response !== null || !this.apiError) {
        console.log('Quote deleted successfully', response);
        
        // Remove quote from the array
        this.allQuotes = this.allQuotes.filter(q => q.id !== this.quoteToDelete?.id);
        
        // Update total pages
        this.totalPages = Math.ceil(this.allQuotes.length / this.itemsPerPage);
        
        // Adjust current page if needed
        if (this.currentPage > this.totalPages && this.totalPages > 0) {
          this.currentPage = this.totalPages;
        }
        
        // Set success message
        this.responseMessage = `Quote ${this.quoteToDelete?.id} deleted successfully.`;
        this.isSuccess = true;
        
        // Reset after 3 seconds
        setTimeout(() => {
          this.responseMessage = '';
        }, 3000);
        
        // Close the panel
        this.quoteToDelete = null;
      }
    });
}

// Update quote status using API with JWT authentication
updateQuoteStatus(quote: ClientQuote, newStatus: string): void {
  // Check if authenticated
  if (!this.isAuthenticated) {
    this.responseMessage = 'Authentication required. Please log in to update quote status.';
    this.isSuccess = false;
    
    // Store current location
    sessionStorage.setItem('redirectUrl', this.currentRoute);
    
    // Don't automatically redirect - just warn user
    return;
  }
  
  this.isLoading = true;
  
  // Get the ID in the correct format
  let quoteId = quote.id;
  // If ID starts with Q-, remove it to get the numeric ID
  if (quoteId.startsWith('Q-')) {
    quoteId = quoteId.substring(2);
  }
  
  // Define API endpoint
  const updateUrl = `${this.apiBaseUrl}/QuoteListItem/${quoteId}/status`;
  
  // Set HTTP headers with authorization
  const httpOptions = {
    headers: this.getAuthHeaders()
  };
  
  // Prepare request body
  const requestBody = {
    status: newStatus
  };
  
  // Make PUT request with JWT token
  this.http.put(updateUrl, requestBody, httpOptions)
    .pipe(
      catchError(error => {
        console.error('Error updating quote status', error);
        
        // Handle authentication errors
        if (error.status === 401) {
          this.handleAuthError(error);
        } else {
          this.responseMessage = `Error updating quote status: ${error.message || error.statusText || 'Unknown error'}`;
          this.isSuccess = false;
        }
        
        return of(null);
      }),
      finalize(() => {
        this.isLoading = false;
      })
    )
    .subscribe(response => {
      // Check if response exists and there was no error
      if (response !== null || !this.apiError) {
        console.log(`Quote status updated successfully to ${newStatus}`, response);
        
        // Find quote index
        const index = this.allQuotes.findIndex(q => q.id === quote.id);
        if (index !== -1) {
          // Update the status
          this.allQuotes[index].status = newStatus as any;
          
          // If this is the currently selected quote, update that too
          if (this.selectedQuote && this.selectedQuote.id === quote.id) {
            this.selectedQuote.status = newStatus as any;
          }
          
          // Set success message
          this.responseMessage = `Quote ${quote.id} status updated to ${newStatus}.`;
          this.isSuccess = true;
          
          // Reset after 3 seconds
          setTimeout(() => {
            this.responseMessage = '';
          }, 3000);
        }
      }
    });
}

// Update specific actions for quote status
bindQuote(quote: ClientQuote): void {
  this.updateQuoteStatus(quote, 'bound');
}

approveQuote(quote: ClientQuote): void {
  this.updateQuoteStatus(quote, 'approved');
}

declineQuote(quote: ClientQuote): void {
  this.updateQuoteStatus(quote, 'declined');
}

// Get client email
getClientEmail(clientName: string): string {
  return this.clientDetails[clientName]?.email || 'No email available';
}

// Get client phone
getClientPhone(clientName: string): string {
  return this.clientDetails[clientName]?.phone || 'No phone available';
}

// Get notes for a specific quote
getQuoteNotes(quoteId: string): QuoteNote[] {
  return this.quoteNotes.filter(note => note.quoteId === quoteId);
}

// Get coverage description
getCoverageDescription(coverageType: string): string {
  return this.coverageDescriptions[coverageType] || 'No description available';
}

/**
 * Logout function - clears auth token and redirects to login
 */
logout(): void {
  // Clear authentication token
  localStorage.removeItem(this.AUTH_TOKEN_KEY);
  
  // Reset authentication state
  this.isAuthenticated = false;
  
  // Show message
  this.responseMessage = 'You have been logged out.';
  this.isSuccess = true;
  
  // Redirect to login page
  setTimeout(() => {
    this.router.navigate(['/login']);
  }, 1000);
}
}