import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class StorageService {
  
  constructor() { }
  
  /**
   * Store an item in session storage
   * @param key The key to store the data under
   * @param value The value to store
   */
  setItem(key: string, value: any): void {
    try {
      const serializedValue = JSON.stringify(value);
      sessionStorage.setItem(key, serializedValue);
    } catch (error) {
      console.error('Error storing data in session storage:', error);
    }
  }
  
  /**
   * Retrieve an item from session storage
   * @param key The key to retrieve
   * @returns The stored value or null if not found
   */
  getItem(key: string): any {
    try {
      const serializedValue = sessionStorage.getItem(key);
      if (serializedValue === null) {
        return null;
      }
      return JSON.parse(serializedValue);
    } catch (error) {
      console.error('Error retrieving data from session storage:', error);
      return null;
    }
  }
  
  /**
   * Remove an item from session storage
   * @param key The key to remove
   */
  removeItem(key: string): void {
    try {
      sessionStorage.removeItem(key);
    } catch (error) {
      console.error('Error removing data from session storage:', error);
    }
  }
  
  /**
   * Clear all data from session storage
   */
  clear(): void {
    try {
      sessionStorage.clear();
    } catch (error) {
      console.error('Error clearing session storage:', error);
    }
  }
}