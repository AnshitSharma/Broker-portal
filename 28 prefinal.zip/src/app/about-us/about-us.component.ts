import { Component, OnInit, ElementRef, HostListener } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { CountUpDirective } from '../shared/directives/count-up.directive';


@Component({
  selector: 'app-about-us',
  standalone: true,
  imports: [CommonModule,CountUpDirective],
  templateUrl: './about-us.component.html',
  styleUrls: ['./about-us.component.css']
})
export class AboutUsComponent implements OnInit {
  // Properties for stats counter animation
  statsVisible = false;
  
  // Properties for testimonial slider
  testimonials = [
    {
      quote: "CoverWise transformed our approach to business insurance. Their broker portal made finding the right coverage effortless, and their team was there every step of the way.",
      author: "Jonathan Peterson",
      company: "CEO, Peterson Manufacturing"
    },
    {
      quote: "After struggling with complicated insurance processes for years, switching to CoverWise was like a breath of fresh air. Their digital platform is intuitive and their expertise is unmatched.",
      author: "Maria Rodriguez",
      company: "Founder, Rodriguez Consulting"
    },
    {
      quote: "The CoverWise team understands the unique challenges of small businesses. They created a custom insurance package that perfectly fits our needs and budget constraints.",
      author: "David Thompson",
      company: "Owner, Thompson Hardware"
    }
  ];
  currentTestimonialIndex = 0;

  constructor(private elementRef: ElementRef, private router: Router) {}

  ngOnInit(): void {
    // Initialize animations
    this.initAnimations();
    
    // Start testimonial slider
    this.startTestimonialSlider();
  }

  // Initialize animations for elements
  private initAnimations(): void {
    // Add animation delay to stagger animations
    const fadeElements = this.elementRef.nativeElement.querySelectorAll('.animate-fade-in');
    fadeElements.forEach((element: HTMLElement, index: number) => {
      element.style.animationDelay = `${index * 0.2}s`;
    });
  }

  // Testimonial slider functionality
  private startTestimonialSlider(): void {
    setInterval(() => {
      this.currentTestimonialIndex = (this.currentTestimonialIndex + 1) % this.testimonials.length;
    }, 5000); // Change testimonial every 5 seconds
  }

  // Method to schedule a consultation
  scheduleConsultation(): void {
    // In a real application, this could open a modal or navigate to a contact form
    this.router.navigate(['/contact'], { queryParams: { type: 'consultation' } });
  }

  // Animate number counting for stats section
  @HostListener('window:scroll', ['$event'])
  checkScroll(): void {
    if (this.statsVisible) return;
    
    const statsSection = this.elementRef.nativeElement.querySelector('.stats-section');
    if (!statsSection) return;
    
    const rect = statsSection.getBoundingClientRect();
    const windowHeight = window.innerHeight || document.documentElement.clientHeight;
    
    // If stats section is in viewport
    if (rect.top <= windowHeight * 0.75 && rect.bottom >= 0) {
      this.statsVisible = true;
      this.animateStatNumbers();
    }
  }

  // Animate the stat numbers counting up
  private animateStatNumbers(): void {
    const statElements = this.elementRef.nativeElement.querySelectorAll('.stat-number');
    
    statElements.forEach((element: HTMLElement) => {
      const targetValue = parseInt(element.getAttribute('data-value') || '0', 10);
      this.countUp(element, 0, targetValue, 2000); // 2 seconds duration
    });
  }

  // Count up animation for numbers
  private countUp(element: HTMLElement, current: number, target: number, duration: number): void {
    const stepTime = 16; // approximately 60fps
    const steps = duration / stepTime;
    const increment = (target - current) / steps;
    let currentStep = 0;
    
    const timer = setInterval(() => {
      currentStep++;
      current += increment;
      element.textContent = Math.round(current).toString();
      
      if (currentStep >= steps) {
        element.textContent = target.toString();
        clearInterval(timer);
      }
    }, stepTime);
  }
}