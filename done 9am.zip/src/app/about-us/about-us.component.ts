import { Component, OnInit, ElementRef, ViewChild, AfterViewInit, HostListener } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';

interface TeamMember {
  name: string;
  title: string;
  bio: string;
  initials: string;
  color: string;
}

interface Location {
  city: string;
  address: string;
  phone: string;
  email: string;
}

@Component({
  selector: 'app-about-us',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './about-us.component.html',
  styleUrls: ['./about-us.component.css']
})
export class AboutUsComponent implements OnInit, AfterViewInit {
  // Team members data
  teamMembers: TeamMember[] = [
    {
      name: 'Roma Sharma',
      title: 'Founder & CEO',
      bio: 'With over 20 years in insurance, Roma Sharma founded CoverWise to make quality liability coverage accessible to businesses of all sizes.',
      initials: 'SJ',
      color: '#010D2D'
    },
    
  ];

  // Office locations
  locations: Location[] = [
    {
      city: 'Chicago',
      address: '123 Insurance Plaza, Suite 400, Chicago, IL 60601',
      phone: '(312) 555-7890',
      email: 'chicago@CoverWise.com'
    },
    {
      city: 'New York',
      address: '456 Broker Street, 20th Floor, New York, NY 10017',
      phone: '(212) 555-8901',
      email: 'newyork@CoverWise.com'
    },
    {
      city: 'Los Angeles',
      address: '789 Coverage Blvd, Los Angeles, CA 90024',
      phone: '(213) 555-9012',
      email: 'la@CoverWise.com'
    }
  ];

  // Reference to stats section for intersection observer
  @ViewChild('statsSection') statsSection!: ElementRef;
  
  // Animated stats values
  animatedStats = {
    years: 0,
    businesses: 0,
    experts: 0,
    satisfaction: 0
  };

  // Target values for stats
  finalStats = {
    years: 15,
    businesses: 5000,
    experts: 45,
    satisfaction: 98
  };
  
  // Track if stats have been animated
  private statsAnimated = false;
  private observer: IntersectionObserver | null = null;

  constructor(private router: Router, private el: ElementRef) {}

  ngOnInit(): void {
    // Initialize any data or state
  }

  ngAfterViewInit(): void {
    // Set up intersection observer for stats section
    this.setupStatsObserver();
    
    // Check if stats section is already visible on initial load
    setTimeout(() => {
      this.checkStatsVisibility();
    }, 500);
  }

  // Set up intersection observer for stats animation
  setupStatsObserver(): void {
    const options = {
      root: null, // viewport
      rootMargin: '0px',
      threshold: 0.5 // 50% of element must be visible
    };

    this.observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting && !this.statsAnimated) {
          this.animateStats();
          this.statsAnimated = true;
        }
      });
    }, options);

    if (this.statsSection) {
      this.observer.observe(this.statsSection.nativeElement);
    }
  }

  // Also check scroll position for compatibility
  @HostListener('window:scroll', ['$event'])
  checkStatsVisibility(): void {
    if (!this.statsAnimated && this.statsSection && this.isElementInViewport(this.statsSection.nativeElement)) {
      this.animateStats();
      this.statsAnimated = true;
    }
  }

  // Helper method to check if element is in viewport
  isElementInViewport(el: Element): boolean {
    const rect = el.getBoundingClientRect();
    return (
      rect.top <= (window.innerHeight || document.documentElement.clientHeight) * 0.8 &&
      rect.bottom >= 0
    );
  }

  // Animate stats with incremental counting
  animateStats(): void {
    const duration = 2000; // milliseconds
    const frameDuration = 1000 / 60; // 60fps
    const totalFrames = Math.round(duration / frameDuration);
    
    let frame = 0;
    
    const countUp = () => {
      const progress = frame / totalFrames; // 0-1
      const easedProgress = this.easeOutQuad(progress);
      
      if (frame < totalFrames) {
        // Update stats with current progress
        this.animatedStats = {
          years: Math.floor(easedProgress * this.finalStats.years),
          businesses: Math.floor(easedProgress * this.finalStats.businesses),
          experts: Math.floor(easedProgress * this.finalStats.experts),
          satisfaction: Math.floor(easedProgress * this.finalStats.satisfaction)
        };
        
        frame++;
        requestAnimationFrame(countUp);
      } else {
        // Ensure final values are exact
        this.animatedStats = { ...this.finalStats };
      }
    };
    
    countUp();
  }
  
  // Easing function for smoother animation
  easeOutQuad(t: number): number {
    return t * (2 - t);
  }

  // Navigation methods
  scrollToContact(): void {
    const contactSection = document.getElementById('locations');
    this.router.navigate(['/contact-us']);
    if (contactSection) {
      contactSection.scrollIntoView({ behavior: 'smooth' });
    }
  }

  navigateToQuote(): void {
    this.router.navigate(['/new-quote']);
  }

  ngOnDestroy(): void {
    // Clean up the observer when component is destroyed
    if (this.observer) {
      this.observer.disconnect();
    }
  }
}