import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { HttpClient, HttpHeaders, HttpClientModule } from '@angular/common/http';

@Component({
  selector: 'app-contact-us',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, HttpClientModule],
  templateUrl: './contact-us.component.html',
  styleUrls: ['./contact-us.component.css']
})
export class ContactUsComponent {
  contactForm: FormGroup;
  submitted = false;
  isSubmitting = false;
  submitResult = '';
  showResult = false;
  
  // Replace this with your actual Web3Forms access key
  private accessKey = '6d3f73ab-cda7-4c56-80b7-9a7efe042c52';
  
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.contactForm = this.formBuilder.group({
      name: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      phone: [''],
      subject: ['', Validators.required],
      message: ['', Validators.required]
    });
  }
  
  onSubmit() {
    this.submitted = true;
    
    if (this.contactForm.invalid) {
      return;
    }
    
    this.isSubmitting = true;
    this.submitResult = 'Please wait...';
    this.showResult = true;
    
    // Prepare the payload for Web3Forms
    const formData = {
      access_key: this.accessKey,
      subject: `New Contact Form Submission: ${this.contactForm.value.subject}`,
      name: this.contactForm.value.name,
      email: this.contactForm.value.email,
      phone: this.contactForm.value.phone || 'Not provided',
      message: this.contactForm.value.message,
      botcheck: ''
    };
    
    // Send to Web3Forms API
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    
    this.http.post('https://api.web3forms.com/submit', formData, { headers })
      .subscribe({
        next: (response: any) => {
          this.submitResult = response.message;
          this.contactForm.reset();
          this.submitted = false;
          
          // Hide result message after 3 seconds
          setTimeout(() => {
            this.showResult = false;
          }, 3000);
        },
        error: (error) => {
          console.error('Error submitting form:', error);
          this.submitResult = 'Something went wrong! Please try again later.';
        },
        complete: () => {
          this.isSubmitting = false;
        }
      });
  }
}