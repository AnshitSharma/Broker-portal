import { Component, OnInit, HostListener } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { Router, NavigationEnd } from '@angular/router';
import { filter } from 'rxjs/operators';
import { HttpClientModule } from '@angular/common/http';
import { ClientService, ApiClient, ApiResponse } from '../services/client.service';

// Keep these interfaces for backward compatibility
interface ClientNote {
  id: number;
  clientId: number;
  author: string;
  date: Date;
  content: string;
}

interface ClientActivity {
  id: number;
  clientId: number;
  type: 'quote' | 'policy' | 'contact' | 'note' | 'document';
  description: string;
  details?: string;
  time: Date;
}

interface ClientQuote {
  id: string;
  clientId: number;
  clientName: string;
  businessName: string;
  quoteDate: Date;
  premium: number;
  status: 'pending' | 'approved' | 'declined' | 'bound';
  coverageType: string;
}

interface Policy {
  id: string;
  clientId: number;
  originalQuoteId: string;
  clientName: string;
  businessName: string;
  effectiveDate: Date;
  expirationDate: Date;
  premium: number;
  coverageType: string;
  status: 'active' | 'expired' | 'cancelled' | 'pending-renewal';
}

// Interface for client form data
interface ClientFormData {
  clientId: number | null;
  clientName: string;
  businessName: string;
  email: string;
  phone: string;
  status: string;
  activePolicies: number;
}

@Component({
  selector: 'app-clients',
  standalone: true,
  imports: [CommonModule, RouterModule, FormsModule, HttpClientModule],
  templateUrl: './clients.component.html',
  styleUrls: ['./clients.component.css'],
  providers: [ClientService]
})
export class ClientsComponent implements OnInit {
  // UI State
  darkModeEnabled: boolean = false;
  sidebarCollapsed: boolean = false;
  mobileMenuOpen: boolean = false;
  currentRoute: string = '/clients';
  selectedClient: ApiClient | null = null;
  activeTab: string = 'info';
  
  // API state
  loading: boolean = false;
  apiError: boolean = false;
  
  // Screen size detection
  isMobileView: boolean = false;
  
  // Pagination
  currentPage: number = 1;
  itemsPerPage: number = 10;
  totalPages: number = 1;
  
  // Broker details
  brokerName: string = 'John Broker';
  brokerRole: string = 'Senior Insurance Broker';
  
  // Filter and search states
  clientSearchQuery: string = '';
  clientStatusFilter: string = 'all';
  clientSortBy: string = 'name-asc';
  
  // User preferences
  notificationsEnabled: boolean = true;
  
  // Client form state
  showClientForm: boolean = false;
  editingClient: boolean = false;
  
  // Notification modal state
  showNotification: boolean = false;
  notificationTitle: string = '';
  notificationMessage: string = '';
  notificationSuccess: boolean = true;
  
  // Client form data object
  clientFormData: ClientFormData = {
    clientId: null,
    clientName: '',
    businessName: '',
    email: '',
    phone: '',
    status: 'Active',
    activePolicies: 0
  };
  
  // New note for client
  newNote: string = '';
  
  // Client stats
  totalClients: number = 0;
  activeClients: number = 0;
  newClients: number = 0;
  uniqueBusinesses: number = 0;
  
  // Client data
  allClients: ApiClient[] = [];
  
  // Client notes
  clientNotes: ClientNote[] = [
    {
      id: 1,
      clientId: 10,
      author: 'John Broker',
      date: new Date(2025, 2, 10, 14, 30),
      content: 'Discussed expansion plans for the business. Client may need to increase coverage limits in the next 6 months.'
    },
    {
      id: 2,
      clientId: 10,
      author: 'Maria Underwriter',
      date: new Date(2025, 2, 15, 11, 45),
      content: 'Client provided updated employee count and revenue figures for policy renewal.'
    },
    {
      id: 3,
      clientId: 9,
      author: 'John Broker',
      date: new Date(2025, 1, 28, 10, 15),
      content: 'Client is considering adding cyber liability coverage due to recent data breach concerns in the industry.'
    },
    {
      id: 4,
      clientId: 11,
      author: 'John Broker',
      date: new Date(2025, 2, 5, 16, 20),
      content: 'Client won a major contract and will need additional coverage for new projects.'
    },
    {
      id: 5,
      clientId: 12,
      author: 'Lisa Claims',
      date: new Date(2025, 3, 1, 9, 30),
      content: 'Client reported a minor property damage incident but decided not to file a claim after discussing deductible.'
    }
  ];
  
  // Client activity
  clientActivity: ClientActivity[] = [
    {
      id: 1,
      clientId: 10,
      type: 'quote',
      description: 'New quote created',
      details: 'General Liability coverage - $2,850 premium',
      time: new Date(2025, 3, 7, 14, 32)
    },
    {
      id: 2,
      clientId: 10,
      type: 'policy',
      description: 'Policy renewed',
      details: 'Professional Liability policy renewed with premium increase of 5%',
      time: new Date(2025, 2, 15, 11, 10)
    },
    {
      id: 3,
      clientId: 10,
      type: 'contact',
      description: 'Phone call with client',
      details: 'Discussed upcoming renewal and potential coverage changes',
      time: new Date(2025, 2, 8, 10, 45)
    },
    {
      id: 4,
      clientId: 9,
      type: 'note',
      description: 'Note added',
      details: 'Updated business information in CRM',
      time: new Date(2025, 1, 20, 15, 30)
    },
    {
      id: 5,
      clientId: 12,
      type: 'quote',
      description: 'Quote approved',
      details: 'Client approved Cyber Liability quote',
      time: new Date(2025, 3, 4, 9, 15)
    }
  ];
  
  // Policies data
  policies: Policy[] = [
    { 
      id: 'POL-2025-01254', 
      clientId: 9,
      originalQuoteId: 'Q-39465',
      clientName: 'Michael Chen', 
      businessName: 'Chen Technology Solutions', 
      effectiveDate: new Date(2025, 3, 10), 
      expirationDate: new Date(2026, 3, 10),
      premium: 5100, 
      coverageType: 'Advertising Injury',
      status: 'active'
    },
    { 
      id: 'POL-2025-01247', 
      clientId: 10,
      originalQuoteId: 'Q-39439',
      clientName: 'Sarah Williams', 
      businessName: 'Artisan Bakery', 
      effectiveDate: new Date(2025, 3, 5), 
      expirationDate: new Date(2026, 3, 5),
      premium: 1875, 
      coverageType: 'Products and Completed Operations',
      status: 'active'
    }
  ];
  
  // Quotes data
  quotes: ClientQuote[] = [
    { 
      id: 'Q-39485', 
      clientId: 10,
      clientName: 'Sarah Williams', 
      businessName: 'Artisan Bakery', 
      quoteDate: new Date(2025, 3, 2), 
      premium: 2850, 
      status: 'pending',
      coverageType: 'Cyber Liability'
    },
    { 
      id: 'Q-39471', 
      clientId: 11,
      clientName: 'John Smith', 
      businessName: 'Tech Solutions LLC', 
      quoteDate: new Date(2025, 3, 3), 
      premium: 3200, 
      status: 'approved',
      coverageType: 'Workers Compensation'
    }
  ];
  
  // For displaying filtered clients
  filteredClients: ApiClient[] = [];
  
  // Authentication state
  isAuthenticated: boolean = false;
  private readonly AUTH_TOKEN_KEY = 'auth_token';
  
  constructor(
    private router: Router,
    private clientService: ClientService
  ) {
    // Subscribe to router events to track current route
    this.router.events
      .pipe(filter(event => event instanceof NavigationEnd))
      .subscribe((event: any) => {
        this.currentRoute = event.url;
        // Reset to first page when changing routes
        this.currentPage = 1;
        // Close mobile menu when navigating
        this.mobileMenuOpen = false;
      });
      
    // Check initial screen size
    this.checkScreenSize();
  }
  
  // Host listener to detect screen size changes
  @HostListener('window:resize', ['$event'])
  onResize() {
    this.checkScreenSize();
  }
  
  // Check if the screen is mobile size
  checkScreenSize() {
    this.isMobileView = window.innerWidth < 992;
    // Auto-collapse sidebar on mobile
    if (this.isMobileView && !this.mobileMenuOpen) {
      this.sidebarCollapsed = true;
    }
  }
  
  ngOnInit(): void {
    // Check if dark mode is saved in localStorage
    const savedDarkMode = localStorage.getItem('darkMode');
    if (savedDarkMode) {
      this.darkModeEnabled = JSON.parse(savedDarkMode);
      document.body.classList.toggle('dark-mode', this.darkModeEnabled);
    }
    
    // Check if sidebar state is saved in localStorage
    const savedSidebarState = localStorage.getItem('sidebarCollapsed');
    if (savedSidebarState) {
      this.sidebarCollapsed = JSON.parse(savedSidebarState);
    }
    
    // Initialize current route
    this.currentRoute = this.router.url;
    
    // Check authentication
    this.checkAuthentication();
    
    // Load clients from API
    this.loadClients();
  }

  /**
   * Check if user is authenticated
   */
  checkAuthentication(): void {
    const token = localStorage.getItem(this.AUTH_TOKEN_KEY);
    this.isAuthenticated = !!token;
    
    // If not authenticated, redirect to login
    if (!this.isAuthenticated) {
      // Store current location to redirect back after login
      sessionStorage.setItem('redirectUrl', '/clients');
      
      // Show notification before redirecting
      this.showNotificationModal(false, 'Authentication Required', 'Please login to view clients.');
      
      // Uncomment the following line to enable automatic redirect to login
      // setTimeout(() => this.router.navigate(['/login']), 2000);
    }
  }
  
  /**
   * Load clients from the API
   */
  loadClients(): void {
    this.loading = true;
    this.apiError = false;
    
    this.clientService.getClients().subscribe({
      next: (clients) => {
        this.allClients = clients;
        
        // Calculate client stats
        this.calculateClientStats();
        
        // Apply filters and populate filtered clients
        this.filterClients();
        
        this.loading = false;
      },
      error: (error) => {
        console.error('Error loading clients:', error);
        this.apiError = true;
        this.loading = false;
        
        if (error && error.status === 401) {
          // Unauthorized - token expired or invalid
          localStorage.removeItem(this.AUTH_TOKEN_KEY);
          sessionStorage.setItem('redirectUrl', '/clients');
          this.showNotificationModal(false, 'Session Expired', 'Your session has expired. Please log in again.');
          setTimeout(() => this.router.navigate(['/login']), 2000);
        } else {
          // Other API errors - will use fallback data
          this.showNotificationModal(false, 'Connection Error', 'Could not connect to the server. Using local data instead.');
        }
      }
    });
    
    // Load client stats from service
    this.clientService.getClientStats().subscribe({
      next: (stats) => {
        this.totalClients = stats.totalClients;
        this.activeClients = stats.activeClients;
        this.newClients = stats.newClientsThisMonth;
        this.uniqueBusinesses = stats.businesses;
      },
      error: (error) => {
        console.error('Error loading client stats:', error);
        // On error, stats will be calculated from local data in calculateClientStats method
      }
    });
  }
  
  // Calculate client statistics
  calculateClientStats(): void {
    this.totalClients = this.allClients.length;
    this.activeClients = this.allClients.filter(client => client.status === 'Active').length;
    
    // Calculate new clients (added in the last 30 days)
    this.newClients = Math.floor(Math.random() * 5) + 1; // Simplified for demo
    
    // Calculate unique businesses
    const uniqueBusinessNames = new Set(
      this.allClients
        .filter(client => client.businessName && client.businessName.trim() !== '')
        .map(client => client.businessName)
    );
    this.uniqueBusinesses = uniqueBusinessNames.size;
  }
  
  // Toggle sidebar collapsed state
  toggleSidebar(): void {
    this.sidebarCollapsed = !this.sidebarCollapsed;
    localStorage.setItem('sidebarCollapsed', JSON.stringify(this.sidebarCollapsed));
    
    // On mobile, also control the mobile menu state
    if (this.isMobileView) {
      this.mobileMenuOpen = !this.sidebarCollapsed;
    }
  }
  
  // Toggle mobile menu specifically
  toggleMobileMenu(): void {
    this.mobileMenuOpen = !this.mobileMenuOpen;
    // When opening mobile menu, make sure sidebar isn't collapsed
    if (this.mobileMenuOpen) {
      this.sidebarCollapsed = false;
    }
  }
  
  // Close mobile menu
  closeMobileMenu(): void {
    this.mobileMenuOpen = false;
  }
  
  // Toggle dark mode
  toggleDarkMode(): void {
    this.darkModeEnabled = !this.darkModeEnabled;
    document.body.classList.toggle('dark-mode', this.darkModeEnabled);
    localStorage.setItem('darkMode', JSON.stringify(this.darkModeEnabled));
  }
  
  // Toggle notifications
  toggleNotifications(): void {
    this.router.navigate(['/dashboard']);
    this.notificationsEnabled = !this.notificationsEnabled;
    // In a real app, you would update user preferences in backend
  }
  
  // Filter clients based on search criteria and filters
  filterClients(): void {
    let filtered = [...this.allClients];
    
    // Apply status filter
    if (this.clientStatusFilter !== 'all') {
      filtered = filtered.filter(client => client.status === this.clientStatusFilter);
    }
    
    // Apply search filter
    if (this.clientSearchQuery.trim() !== '') {
      const search = this.clientSearchQuery.toLowerCase();
      filtered = filtered.filter(client => 
        client.clientName.toLowerCase().includes(search) ||
        client.email.toLowerCase().includes(search) ||
        client.phone.toLowerCase().includes(search) ||
        (client.businessName && client.businessName.toLowerCase().includes(search))
      );
    }
    
    // Apply sorting
    switch(this.clientSortBy) {
      case 'name-asc':
        filtered.sort((a, b) => a.clientName.localeCompare(b.clientName));
        break;
      case 'name-desc':
        filtered.sort((a, b) => b.clientName.localeCompare(a.clientName));
        break;
      case 'date-desc':
        // Sort by clientId as proxy for date (higher id = newer)
        filtered.sort((a, b) => b.clientId - a.clientId);
        break;
      case 'date-asc':
        // Sort by clientId as proxy for date (lower id = older)
        filtered.sort((a, b) => a.clientId - b.clientId);
        break;
    }
    
    // Update filtered clients
    this.filteredClients = filtered;
    
    // Update total pages
    this.totalPages = Math.ceil(this.filteredClients.length / this.itemsPerPage);
    
    // Reset to first page if current page is now invalid
    if (this.currentPage > this.totalPages && this.totalPages > 0) {
      this.currentPage = 1;
    }
  }
  
  // Get paginated clients for current page
  getPaginatedClients(): ApiClient[] {
    const startIndex = (this.currentPage - 1) * this.itemsPerPage;
    const endIndex = startIndex + this.itemsPerPage;
    return this.filteredClients.slice(startIndex, endIndex);
  }
  
  // Get page numbers array for pagination display
  getPageNumbers(): number[] {
    const pages: number[] = [];
    const maxDisplayPages = 5;
    
    if (this.totalPages <= maxDisplayPages) {
      // Display all pages if total pages is less than max display
      for (let i = 1; i <= this.totalPages; i++) {
        pages.push(i);
      }
    } else {
      // Display a subset of pages with current page in middle if possible
      const halfMax = Math.floor(maxDisplayPages / 2);
      
      let startPage = Math.max(this.currentPage - halfMax, 1);
      let endPage = startPage + maxDisplayPages - 1;
      
      if (endPage > this.totalPages) {
        endPage = this.totalPages;
        startPage = Math.max(endPage - maxDisplayPages + 1, 1);
      }
      
      for (let i = startPage; i <= endPage; i++) {
        pages.push(i);
      }
    }
    
    return pages;
  }
  
  // Change page in pagination
  changePage(page: number): void {
    if (page < 1 || page > this.totalPages) {
      return;
    }
    this.currentPage = page;
  }
  
  // Get client initials for avatar
  getClientInitials(name: string): string {
    if (!name) return '??';
    
    const parts = name.split(' ');
    if (parts.length === 1) return parts[0].charAt(0).toUpperCase();
    
    return (parts[0].charAt(0) + parts[parts.length - 1].charAt(0)).toUpperCase();
  }
  
  // View client details
  viewClientDetails(client: ApiClient): void {
    this.selectedClient = client;
    this.activeTab = 'info';
  }
  
  // Close client details modal
  closeClientDetails(event?: MouseEvent): void {
    // Only close if event is undefined (direct close) or if target is the modal backdrop
    if (!event || (event.target as HTMLElement).classList.contains('modal-overlay')) {
      this.selectedClient = null;
    }
  }
  
  // Add new client
  addNewClient(): void {
    this.editingClient = false;
    this.resetClientForm();
    this.showClientForm = true;
  }
  
  // Edit client
  editClient(client: ApiClient): void {
    this.editingClient = true;
    this.populateClientForm(client);
    this.showClientForm = true;
    
    // Close client details modal if it's open
    this.selectedClient = null;
  }
  
  // Cancel client form
  cancelClientForm(event?: MouseEvent): void {
    // Only close if event is undefined (direct close) or if target is the modal backdrop
    if (!event || (event.target as HTMLElement).classList.contains('modal-overlay')) {
      this.showClientForm = false;
    }
  }
  
  // Show notification modal
  showNotificationModal(success: boolean, title: string, message: string): void {
    this.notificationSuccess = success;
    this.notificationTitle = title;
    this.notificationMessage = message;
    this.showNotification = true;
    
    // Auto-close notification after 3 seconds
    setTimeout(() => {
      this.showNotification = false;
    }, 3000);
  }
  
  // Close notification modal
  closeNotification(): void {
    this.showNotification = false;
  }
  
  // Save client (add new or update existing)
  saveClient(): void {
    // Validate required fields
    if (!this.validateClientForm()) {
      this.showNotificationModal(false, 'Validation Error', 'Please fill in all required fields correctly.');
      return;
    }

    // Create client object from form
    const client: ApiClient = {
      clientId: this.editingClient ? this.clientFormData.clientId! : 0, // API will ignore 0 for new clients
      clientName: this.clientFormData.clientName,
      businessName: this.clientFormData.businessName,
      email: this.clientFormData.email,
      phone: this.clientFormData.phone,
      status: this.clientFormData.status,
      activePolicies: this.clientFormData.activePolicies
    };
    
    if (this.editingClient) {
      // Update existing client in API
      this.clientService.updateClient(client).subscribe({
        next: (response: ApiResponse) => {
          if (response.success) {
            // Update client in local list
            const index = this.allClients.findIndex(c => c.clientId === client.clientId);
            if (index !== -1) {
              this.allClients[index] = response.data || client;
            }
            
            // Re-apply filters
            this.filterClients();
            
            // Close form
            this.showClientForm = false;
            
            // Show success notification
            this.showNotificationModal(true, 'Success', response.message || 'Client updated successfully');
            
           // Add activity
           this.addClientActivity(client.clientId, 'Client updated', 'Client information was updated');
          } else {
            // Show error notification
            this.showNotificationModal(false, 'Update Failed', response.message || 'Failed to update client');
          }
        },
        error: (error) => {
          console.error('Error updating client:', error);
          
          if (error && error.status === 401) {
            // Unauthorized - token expired or invalid
            localStorage.removeItem(this.AUTH_TOKEN_KEY);
            sessionStorage.setItem('redirectUrl', '/clients');
            this.showNotificationModal(false, 'Session Expired', 'Your session has expired. Please log in again.');
            setTimeout(() => this.router.navigate(['/login']), 2000);
          } else {
            // Show general error notification
            this.showNotificationModal(false, 'Error', 'Failed to update client. Please try again.');
          }
        }
      });
    } else {
      // Add new client to API
      this.clientService.addClient(client).subscribe({
        next: (response: ApiResponse) => {
          if (response.success) {
            // Add client to local list (use response data which should have new ID)
            if (response.data) {
              this.allClients.push(response.data);
            } else {
              // If no data returned, add the client with a fake ID
              // In real app, you'd want to reload from the API instead
              const newClient = {...client, clientId: Math.max(...this.allClients.map(c => c.clientId)) + 1};
              this.allClients.push(newClient);
            }
            
            // Update stats
            this.calculateClientStats();
            
            // Re-apply filters
            this.filterClients();
            
            // Close form
            this.showClientForm = false;
            
            // Show success notification
            this.showNotificationModal(true, 'Success', response.message || 'Client added successfully');
          } else {
            // Show error notification
            this.showNotificationModal(false, 'Create Failed', response.message || 'Failed to add client');
          }
        },
        error: (error) => {
          console.error('Error adding client:', error);
          
          if (error && error.status === 401) {
            // Unauthorized - token expired or invalid
            localStorage.removeItem(this.AUTH_TOKEN_KEY);
            sessionStorage.setItem('redirectUrl', '/clients');
            this.showNotificationModal(false, 'Session Expired', 'Your session has expired. Please log in again.');
            setTimeout(() => this.router.navigate(['/login']), 2000);
          } else {
            // Show general error notification
            this.showNotificationModal(false, 'Error', 'Failed to add client. Please try again.');
          }
        }
      });
    }
  }
  
  // Validate the client form
  validateClientForm(): boolean {
    // Check required fields
    if (!this.clientFormData.clientName || 
        !this.clientFormData.email || 
        !this.clientFormData.phone) {
      return false;
    }
    
    // Basic email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(this.clientFormData.email)) {
      return false;
    }
    
    return true;
  }
  
  // Reset client form
  resetClientForm(): void {
    this.clientFormData = {
      clientId: null,
      clientName: '',
      businessName: '',
      email: '',
      phone: '',
      status: 'Active',
      activePolicies: 0
    };
  }
  
  // Populate client form with existing client data
  populateClientForm(client: ApiClient): void {
    this.clientFormData = {
      clientId: client.clientId,
      clientName: client.clientName,
      businessName: client.businessName || '',
      email: client.email,
      phone: client.phone,
      status: client.status,
      activePolicies: client.activePolicies
    };
  }
  
  // Set active tab in client details
  setActiveTab(tab: string): void {
    this.activeTab = tab;
  }
  
  // Create quote for client
  createQuoteForClient(client: ApiClient): void {
    this.router.navigate(['/new-quote']);
    // Verify authentication
    if (!this.isAuthenticated) {
      this.showNotificationModal(false, 'Authentication Required', 'Please login to create a quote.');
      return;
    }
    
    // Close modals
    this.selectedClient = null;
    this.showClientForm = false;
    
    // In a real app, this would route to the quote creation page
    // and pre-fill client information
    this.router.navigate(['/quotes/new'], { 
      queryParams: { clientId: client.clientId }
    });
  }
  
  // Email client
  emailClient(client: ApiClient): void {
    // In a real app, this would open an email composition interface
    window.open(`mailto:${client.email}`);
  }
  
  // Export client list
  exportClientList(): void {
    // Verify authentication
    if (!this.isAuthenticated) {
      this.showNotificationModal(false, 'Authentication Required', 'Please login to export clients.');
      return;
    }
    
    // In a real app, this would generate a CSV or Excel file
    this.showNotificationModal(true, 'Export', 'Client list exported successfully.');
  }
  
  // Add a note for the selected client
  addNote(): void {
    if (!this.selectedClient || !this.newNote.trim()) {
      return;
    }
    
    // Verify authentication
    if (!this.isAuthenticated) {
      this.showNotificationModal(false, 'Authentication Required', 'Please login to add notes.');
      return;
    }
    
    const note: ClientNote = {
      id: this.clientNotes.length + 1,
      clientId: this.selectedClient.clientId,
      author: this.brokerName,
      date: new Date(),
      content: this.newNote.trim()
    };
    
    this.clientNotes.push(note);
    
    // Add activity entry for the note
    this.addClientActivity(this.selectedClient.clientId, 'Note added', 
      note.content.length > 50 ? note.content.substring(0, 50) + '...' : note.content);
    
    // Clear the note input
    this.newNote = '';
    
    // Show notification
    this.showNotificationModal(true, 'Note Added', 'Note has been added successfully.');
  }
  
  // Add activity for a client
  addClientActivity(clientId: number, description: string, details?: string): void {
    const activity: ClientActivity = {
      id: this.clientActivity.length + 1,
      clientId: clientId,
      type: 'note',
      description: description,
      details: details,
      time: new Date()
    };
    
    this.clientActivity.push(activity);
  }
  
  // Get notes for a specific client
  getClientNotes(clientId: number): ClientNote[] {
    return this.clientNotes.filter(note => note.clientId === clientId);
  }
  
  // Get activities for a specific client
  getClientActivity(clientId: number): ClientActivity[] {
    return this.clientActivity
      .filter(activity => activity.clientId === clientId)
      .sort((a, b) => b.time.getTime() - a.time.getTime()); // Most recent first
  }
  
  // Get policies for a specific client
  getClientPolicies(clientId: number): Policy[] {
    return this.policies.filter(policy => policy.clientId === clientId);
  }
  
  // Get quotes for a specific client
  getClientQuotes(clientId: number): ClientQuote[] {
    return this.quotes.filter(quote => quote.clientId === clientId);
  }
  
  // Get status class for styling
  getStatusClass(status: string): string {
    switch(status) {
      case 'Active': return 'status-active';
      case 'Inactive': return 'status-inactive';
      case 'Prospect': return 'status-prospect';
      default: return '';
    }
  }
  
  // Get quote status class for styling
  getQuoteStatusClass(status: string): string {
    switch(status) {
      case 'pending': return 'status-pending';
      case 'approved': return 'status-approved';
      case 'bound': return 'status-bound';
      case 'declined': return 'status-declined';
      default: return '';
    }
  }
  
  // Get activity icon based on type
  getActivityIcon(type: string): string {
    switch(type) {
      case 'quote': return 'fa-file-invoice-dollar';
      case 'policy': return 'fa-file-contract';
      case 'contact': return 'fa-phone-alt';
      case 'note': return 'fa-sticky-note';
      case 'document': return 'fa-file-alt';
      default: return 'fa-circle';
    }
  }
  
  // Handle session logout
  logout(): void {
    localStorage.removeItem(this.AUTH_TOKEN_KEY);
    this.isAuthenticated = false;
    this.router.navigate(['/login']);
  }
}