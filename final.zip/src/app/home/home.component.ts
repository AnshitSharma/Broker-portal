import { Component, OnInit, OnDestroy, ViewChild, ElementRef, Renderer2, AfterViewInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { FormsModule } from '@angular/forms';


interface FaqItem {
  question: string;
  answer: string;
  iconType: 'shield' | 'alert' | 'package' | 'scale' | 'calendar' | 'building' | 'file';
}

interface ServiceItem {
  title: string;
  description: string;
  icon: string;
}

interface FeatureItem {
  title: string;
  description: string;
  icon: string;
}

interface TestimonialItem {
  quote: string;
  author: string;
  position: string;
  initials: string;
}

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit, OnDestroy, AfterViewInit {
  
  // Hero section variables
  activeSlide = 0;
  private slideshowInterval: number | null = null;
  
  // Track which FAQ item is open
  openIndex: number | null = null;
  
  // Services data
  services: ServiceItem[] = [
    {
      title: "Bodily Injury Protection",
      description: "Coverage for claims of bodily injury suffered by non-employees on your premises.",
      icon: "fa-heartbeat"
    },
    {
      title: "Property Damage Coverage",
      description: "Protection against claims for damage to others' property resulting from your operations.",
      icon: "fa-building-damage"
    },
    {
      title: "Products Liability",
      description: "Coverage for damages caused by your products after they leave your possession.",
      icon: "fa-box-open"
    },
    {
      title: "Damage to Rental Premises",
      description: "Protection for liability arising from damage to property you rent or lease.",
      icon: "fa-home"
    },
    {
      title: "Advertising Injury",
      description: "Protection against claims of libel, slander, false arrest, and invasion of privacy.",
      icon: "fa-ad"
    },
    {
      title: "Legal Defense Costs",
      description: "Coverage for attorney fees and court costs associated with a covered claim.",
      icon: "fa-gavel"
    }

  ];

  // Features data
  features: FeatureItem[] = [
    {
      title: "Comprehensive Protection",
      description: "Coverage designed for all aspects of business liability, from premises to operations.",
      icon: "fa-shield-alt"
    },
    {
      title: "Tailored Solutions",
      description: "Custom policies that address the unique risks of your specific industry.",
      icon: "fa-sitemap"
    },
    {
      title: "Fast Claims Process",
      description: "Streamlined claims handling that gets you back to business quickly.",
      icon: "fa-bolt"
    }
  ];
  
  // FAQ data with icons
  faqItems: FaqItem[] = [
    {
      question: "Why Is General Liability Needed?",
      answer: "General liability insurance protects your business from financial loss if you're held responsible for property damage, bodily injuries, or advertising injury claims. It covers legal defense costs and settlements, protecting your business assets from potentially devastating lawsuits.",
      iconType: 'shield'
    },
    {
      question: "What Does a General Liability Policy Not Cover?",
      answer: "General liability typically doesn't cover employee injuries (covered by workers' compensation), professional errors (covered by professional liability), damage to your own property (covered by commercial property insurance), or intentional acts of wrongdoing. It also doesn't cover data breaches, vehicle accidents, or employee disputes.",
      iconType: 'alert'
    },
    {
      question: "Can I Bundle General Liability With Other Types of Insurance?",
      answer: "Yes, many insurance providers offer Business Owner's Policies (BOPs) that bundle general liability with property insurance and sometimes other coverages at a discounted rate. This is often more cost-effective than purchasing separate policies and provides more comprehensive protection.",
      iconType: 'package'
    },
    {
      question: "Is General Liability Business Insurance Required by Law?",
      answer: "While not universally required by federal law, some states and municipalities may require certain businesses to carry general liability insurance. Additionally, many client contracts, commercial leases, and loan agreements require proof of general liability coverage.",
      iconType: 'scale'
    },
    {
      question: "What Types of Events Can General Liability Insurance Help Pay For?",
      answer: "General liability insurance typically covers bodily injury claims (customer slips and falls), property damage claims (employee damages client property), reputational harm (slander or libel claims), advertising injury (copyright infringement), and legal defense costs regardless of fault.",
      iconType: 'calendar'
    },
    {
      question: "Do You Need Business Liability Insurance for an LLC?",
      answer: "Yes, while an LLC structure helps protect your personal assets from business liabilities, it doesn't protect your business assets from lawsuits. General liability insurance provides that additional layer of protection for your business investments and is recommended even for LLCs.",
      iconType: 'building'
    },
    {
      question: "What Information Do I Need To Get a General Liability Quote?",
      answer: "To get a quote, you'll typically need: basic business information (name, address, structure), details about your operations, number of employees, annual revenue, claims history, and specifics about your industry and services provided. More detailed information helps ensure accurate coverage and pricing.",
      iconType: 'file'
    }
  ];

  // Testimonials data
  testimonials: TestimonialItem[] = [
    {
      quote: "Their general liability coverage has been instrumental to our business growth. When we faced a claim, their response was swift and professional.",
      author: "Michael Chen",
      position: "CEO of Pacific Construction",
      initials: "MC"
    },
    {
      quote: "As a small business owner, I was concerned about liability risks. Their team helped me understand my coverage needs and provided an affordable solution.",
      author: "Sarah Johnson",
      position: "Owner, Bright Ideas Marketing",
      initials: "SJ"
    },
    {
      quote: "After comparing multiple options, I found their general liability coverage offered the best protection for my retail stores. The claims process was seamless.",
      author: "David Rodriguez",
      position: "Retail Chain Manager",
      initials: "DR"
    }
  ];

  activeTestimonial = 0;

  constructor(
    private router: Router,
    private renderer: Renderer2
  ) {}
  
  ngOnInit(): void {
    this.startSlideshow();
  }
  
  ngAfterViewInit(): void {
    // Add animations after view is initialized
    setTimeout(() => {
      this.addDecorativeAnimations();
    }, 100);
  }
  
  ngOnDestroy(): void {
    // Clear interval when component is destroyed
    if (this.slideshowInterval) {
      window.clearInterval(this.slideshowInterval);
      this.slideshowInterval = null;
    }
  }
  
  // Method for quote request form submission
  requestQuote(): void {
    console.log('Quote requested');
    this.router.navigate(['/insurance']);
  }
  
  // Method to navigate to different sections
  scrollToSection(sectionId: string): void {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  }

  /**
   * Toggle the open/closed state of an FAQ item
   */
  toggleItem(index: number): void {
    if (this.openIndex === index) {
      // If clicking already open item, close it
      this.openIndex = null;
    } else {
      // Open the clicked item
      this.openIndex = index;
    }
  }

  /**
   * Change testimonial
   */
  changeTestimonial(index: number): void {
    this.activeTestimonial = index;
  }

  /**
   * Navigate to next testimonial
   */
  nextTestimonial(): void {
    this.activeTestimonial = (this.activeTestimonial + 1) % this.testimonials.length;
  }

  /**
   * Navigate to previous testimonial
   */
  prevTestimonial(): void {
    this.activeTestimonial = (this.activeTestimonial - 1 + this.testimonials.length) % this.testimonials.length;
  }
  
  /**
   * Start automatic slideshow for hero section
   */
  private startSlideshow(): void {
    this.slideshowInterval = window.setInterval(() => {
      this.activeSlide = (this.activeSlide + 1) % 5;
      this.updateDots();
    }, 5000);
  }
  
  /**
   * Update the dot indicators in the hero section
   */
  private updateDots(): void {
    const dots = document.querySelectorAll('.homepage-hero-section-dot');
    if (dots && dots.length) {
      dots.forEach((dot, index) => {
        if (index === this.activeSlide) {
          dot.classList.add('active');
        } else {
          dot.classList.remove('active');
        }
      });
    }
  }
  
  /**
   * Change to a specific slide in the hero section
   */
  goToSlide(index: number): void {
    this.activeSlide = index;
    this.updateDots();
    
    // Reset the interval to prevent quick transitions
    if (this.slideshowInterval) {
      window.clearInterval(this.slideshowInterval);
      this.startSlideshow();
    }
  }
  
  /**
   * Add subtle animations to decorative elements in the hero section
   */
  private addDecorativeAnimations(): void {
    // Add floating animation stylesheet
    this.addFloatingKeyframes();
    
    // Add animations to hero section decorative elements
    const shield = document.querySelector('.homepage-hero-section-shield');
    const envelope = document.querySelector('.homepage-hero-section-envelope');
    const playButton = document.querySelector('.homepage-hero-section-play-button');
    
    if (shield) {
      this.addFloatingAnimation(shield as HTMLElement);
    }
    
    if (envelope) {
      this.addFloatingAnimation(envelope as HTMLElement, 1);
    }
    
    if (playButton) {
      this.addFloatingAnimation(playButton as HTMLElement, 2);
    }
  }
  
  /**
   * Add the floating keyframes to the document
   */
  private addFloatingKeyframes(): void {
    if (!document.getElementById('floating-keyframes')) {
      const styleEl = this.renderer.createElement('style');
      this.renderer.setAttribute(styleEl, 'id', 'floating-keyframes');
      const text = this.renderer.createText(`
        @keyframes floating {
          0% { transform: translateY(0px); }
          50% { transform: translateY(-10px); }
          100% { transform: translateY(0px); }
        }
      `);
      this.renderer.appendChild(styleEl, text);
      this.renderer.appendChild(document.head, styleEl);
    }
  }
  
  /**
   * Add floating animation to an element
   */
  private addFloatingAnimation(element: HTMLElement, delayFactor: number = 0): void {
    // Simple CSS-based animation using the renderer
    this.renderer.setStyle(element, 'animation', 'floating 3s ease-in-out infinite');
    this.renderer.setStyle(element, 'animation-delay', `${delayFactor * 0.5}s`);
  }
}