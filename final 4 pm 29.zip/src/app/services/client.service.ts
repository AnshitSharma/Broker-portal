import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { catchError, map } from 'rxjs/operators';

// Client model interfaces
export interface ApiClient {
  clientId: number;
  clientName: string;
  businessName?: string;
  email: string;
  phone: string;
  status: string;
  activePolicies: number;
}

export interface ApiResponse {
  success: boolean;
  message: string;
  data?: ApiClient;
}

export interface ClientDashboardStats {
  totalClients: number;
  activeClients: number;
  newClientsThisMonth: number;
  businesses: number;
}

@Injectable({
  providedIn: 'root'
})
export class ClientService {
  private readonly API_URL = 'http://localhost:5075/api/Clients';
  private readonly AUTH_TOKEN_KEY = 'auth_token';
  
  // Sample data for fallback if API is unavailable
  private fallbackClients: ApiClient[] = [
    {
      clientId: 9,
      clientName: 'Michael Chen',
      businessName: 'Chen Technology Solutions',
      email: 'michael.chen@example.com',
      phone: '(212) 555-3876',
      status: 'Active',
      activePolicies: 1
    },
    {
      clientId: 10,
      clientName: 'Sarah Williams',
      businessName: 'Artisan Bakery',
      email: 'sarah.williams@example.com',
      phone: '(212) 555-9821',
      status: 'Active',
      activePolicies: 1
    },
    {
      clientId: 11,
      clientName: 'John Smith',
      businessName: 'Tech Solutions LLC',
      email: 'john.smith@example.com',
      phone: '(212) 555-7654',
      status: 'Prospect',
      activePolicies: 0
    },
    {
      clientId: 12,
      clientName: 'Laura Peterson',
      businessName: 'Peterson Dental Care',
      email: 'laura.peterson@example.com',
      phone: '(212) 555-4321',
      status: 'Active',
      activePolicies: 1
    }
  ];

  constructor(private http: HttpClient) { }

  /**
   * Get the authentication headers for API requests
   */
  private getAuthHeaders(): HttpHeaders {
    const token = localStorage.getItem(this.AUTH_TOKEN_KEY);
    return new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token || ''}`
    });
  }

  /**
   * Get all clients from the API
   */
  getClients(): Observable<ApiClient[]> {
    const httpOptions = {
      headers: this.getAuthHeaders()
    };

    return this.http.get<ApiClient[]>(this.API_URL, httpOptions)
      .pipe(
        map(response => {
          // Process and transform the response if needed
          return response;
        }),
        catchError(error => {
          console.error('Error fetching clients:', error);
          // Return fallback data on error
          return of(this.fallbackClients);
        })
      );
  }

  /**
   * Get client dashboard statistics
   */
  getClientStats(): Observable<ClientDashboardStats> {
    const httpOptions = {
      headers: this.getAuthHeaders()
    };

    return this.http.get<ClientDashboardStats>(`${this.API_URL}/dashboard-stats`, httpOptions)
      .pipe(
        catchError(error => {
          console.error('Error fetching client stats:', error);
          // Return calculated stats from fallback data
          return of({
            totalClients: this.fallbackClients.length,
            activeClients: this.fallbackClients.filter(c => c.status === 'Active').length,
            newClientsThisMonth: Math.floor(Math.random() * 3) + 1, // Random number for fallback
            businesses: this.fallbackClients.filter(c => c.businessName && c.businessName.trim() !== '').length
          });
        })
      );
  }

  /**
   * Get a client by ID
   */
  getClientById(id: number): Observable<ApiClient | null> {
    const httpOptions = {
      headers: this.getAuthHeaders()
    };

    return this.http.get<ApiClient>(`${this.API_URL}/${id}`, httpOptions)
      .pipe(
        catchError(error => {
          console.error(`Error fetching client with ID ${id}:`, error);
          // Return client from fallback data if available
          const fallbackClient = this.fallbackClients.find(client => client.clientId === id);
          return of(fallbackClient || null);
        })
      );
  }

  /**
   * Add a new client
   */
  addClient(client: ApiClient): Observable<ApiResponse> {
    const httpOptions = {
      headers: this.getAuthHeaders()
    };

    // Create client DTO from the client object
    const clientDto = {
      firstName: client.clientName.split(' ')[0],
      lastName: client.clientName.split(' ').slice(1).join(' '),
      businessName: client.businessName || '',
      email: client.email,
      phone: client.phone,
      status: client.status,
      activePolicies: client.activePolicies
    };

    return this.http.post<ApiResponse>(this.API_URL, clientDto, httpOptions)
      .pipe(
        catchError(error => {
          console.error('Error adding client:', error);
          return of({
            success: false,
            message: error.error?.message || 'Failed to add client. Please try again.'
          });
        })
      );
  }

  /**
   * Update an existing client
   */
  updateClient(client: ApiClient): Observable<ApiResponse> {
    const httpOptions = {
      headers: this.getAuthHeaders()
    };

    // Create update client DTO
    const updateClientDto = {
      firstName: client.clientName.split(' ')[0],
      lastName: client.clientName.split(' ').slice(1).join(' '),
      businessName: client.businessName || '',
      email: client.email,
      phone: client.phone,
      status: client.status,
      activePolicies: client.activePolicies
    };

    return this.http.put<ApiResponse>(`${this.API_URL}/${client.clientId}`, updateClientDto, httpOptions)
      .pipe(
        catchError(error => {
          console.error(`Error updating client with ID ${client.clientId}:`, error);
          return of({
            success: false,
            message: error.error?.message || 'Failed to update client. Please try again.'
          });
        })
      );
  }

  /**
   * Delete a client
   */
  deleteClient(id: number): Observable<ApiResponse> {
    const httpOptions = {
      headers: this.getAuthHeaders()
    };

    return this.http.delete<ApiResponse>(`${this.API_URL}/${id}`, httpOptions)
      .pipe(
        catchError(error => {
          console.error(`Error deleting client with ID ${id}:`, error);
          return of({
            success: false,
            message: error.error?.message || 'Failed to delete client. Please try again.'
          });
        })
      );
  }
}