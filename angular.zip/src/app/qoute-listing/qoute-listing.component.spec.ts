import { ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { QuoteListingComponent } from './qoute-listing.component';
import { FormsModule } from '@angular/forms';

describe('QuoteListingComponent', () => {
  let component: QuoteListingComponent;
  let fixture: ComponentFixture<QuoteListingComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [
        RouterTestingModule,
        FormsModule,
        QuoteListingComponent
      ]
    }).compileComponents();

    fixture = TestBed.createComponent(QuoteListingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should load quotes on init', () => {
    expect(component.quotes.length).toBeGreaterThan(0);
  });

  it('should filter quotes by coverage', () => {
    // Set a specific coverage filter
    component.selectCoverage('2 Cr');
    // Check if filtered quotes match the selected coverage
    expect(component.filteredQuotes.every(quote => quote.coverageLimit === '2 Cr')).toBeTrue();
  });

  it('should sort quotes by premium', () => {
    component.changeSortBy('premium');
    const sortedPremiums = component.filteredQuotes.map(quote => quote.premium);
    // Check if the array is sorted in ascending order
    expect(sortedPremiums).toEqual([...sortedPremiums].sort((a, b) => a - b));
  });

  it('should calculate savings correctly', () => {
    const premium = 1000;
    const expectedSavings = '180'; // 18% of 1000
    expect(component.calculateSavings(premium)).toBe(expectedSavings);
  });
});