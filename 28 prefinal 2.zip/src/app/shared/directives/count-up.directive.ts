import { Directive, ElementRef, Input, OnInit } from '@angular/core';

@Directive({
  selector: '[countUp]',
  standalone: true
})
export class CountUpDirective implements OnInit {
  @Input() countUp: number = 0;
  @Input() duration: number = 2000;
  @Input() decimals: number = 0;

  private startTime: number | null = null;
  private currentValue: number = 0;
  private prefix: string = '';
  private suffix: string = '';

  constructor(private el: ElementRef) {}

  ngOnInit(): void {
    // Store initial content as prefix/suffix if it contains the target number
    const initialText = this.el.nativeElement.textContent;
    
    if (initialText) {
      const parts = initialText.split(this.countUp.toString());
      if (parts.length > 1) {
        this.prefix = parts[0];
        this.suffix = parts.slice(1).join(this.countUp.toString());
      }
    }

    // Start the animation when the component is initialized
    requestAnimationFrame(this.animateCount.bind(this));
  }

  private animateCount(timestamp: number): void {
    if (!this.startTime) {
      this.startTime = timestamp;
    }

    const elapsed = timestamp - this.startTime;
    const progress = Math.min(elapsed / this.duration, 1);
    
    // Use easeOutExpo for smoother counting animation
    const easeOutExpo = progress === 1 ? 1 : 1 - Math.pow(2, -10 * progress);
    this.currentValue = easeOutExpo * this.countUp;

    // Update the element text with formatted number
    this.updateText();

    // Continue animation if not complete
    if (progress < 1) {
      requestAnimationFrame(this.animateCount.bind(this));
    } else {
      // Ensure final value is exactly the target value
      this.currentValue = this.countUp;
      this.updateText();
    }
  }

  private updateText(): void {
    // Format number with proper decimals
    let formattedNumber: string;
    
    if (this.decimals > 0) {
      formattedNumber = this.currentValue.toFixed(this.decimals);
    } else {
      formattedNumber = Math.round(this.currentValue).toString();
    }

    // Apply prefix and suffix
    this.el.nativeElement.textContent = `${this.prefix}${formattedNumber}${this.suffix}`;
  }
}