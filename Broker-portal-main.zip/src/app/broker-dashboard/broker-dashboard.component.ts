import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';

interface ClientQuote {
  id: string;
  clientName: string;
  businessName: string;
  quoteDate: Date;
  premium: number;
  status: 'pending' | 'approved' | 'declined' | 'bound';
  coverageType: string;
}

interface RecentActivity {
  id: number;
  type: 'quote' | 'policy' | 'claim' | 'message';
  description: string;
  time: Date;
  clientName: string;
  icon: string;
}

interface Task {
  id: number;
  title: string;
  dueDate: Date;
  priority: 'high' | 'medium' | 'low';
  completed: boolean;
}

interface PieSegment {
  path: string;
  color: string;
}

@Component({
  selector: 'app-broker-dashboard',
  standalone: true,
  imports: [CommonModule, RouterModule, FormsModule],
  templateUrl: './broker-dashboard.component.html',
  styleUrls: ['./broker-dashboard.component.css']
})
export class BrokerDashboardComponent implements OnInit {
  // Expose Math object to be used in template
  Math = Math;
  
  // Broker details
  brokerName: string = 'John Broker';
  brokerRole: string = 'Senior Insurance Broker';
  
  // Dashboard stats
  pendingQuotes: number = 12;
  activeClients: number = 84;
  conversionRate: number = 68;
  quarterlyCommission: number = 24650;
  
  // Monthly targets
  targetNewClients: number = 15;
  actualNewClients: number = 11;
  targetRenewals: number = 25;
  actualRenewals: number = 22;
  targetRevenue: number = 35000;
  actualRevenue: number = 24650;
  
  // Filter and search states
  quoteFilter: string = 'all';
  searchQuery: string = '';
  
  // Charts data
  performanceMonths: string[] = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'];
  performanceData: number[] = [18500, 22400, 19800, 26700, 22300, 24650];
  
  conversionData: any[] = [
    { label: 'Quotes', value: 142 },
    { label: 'Policies', value: 97 }
  ];
  
  lineOfBusinessData: any[] = [
    { name: 'General Liability', value: 38 },
    { name: 'Professional Liability', value: 22 },
    { name: 'Workers\' Comp', value: 18 },
    { name: 'Business Owner\'s', value: 12 },
    { name: 'Commercial Auto', value: 10 }
  ];
  
  // Pie chart segments - will be calculated in ngOnInit
  pieSegments: PieSegment[] = [];
  
  // Colors for pie chart segments
  pieChartColors: string[] = [
    '#CC7952', // General Liability - brown/orange
    '#4A6BD6', // Professional Liability - blue
    '#42C0C0', // Workers' Comp - teal
    '#87D987', // Business Owner's - green
    '#87BD52'  // Commercial Auto - light green
  ];
  
  // Recent quotes
  recentQuotes: ClientQuote[] = [
    { 
      id: 'Q-39485', 
      clientName: 'Robert Johnson', 
      businessName: 'Johnson Consulting LLC', 
      quoteDate: new Date(2025, 3, 2), 
      premium: 2850, 
      status: 'pending',
      coverageType: 'General Liability'
    },
    { 
      id: 'Q-39471', 
      clientName: 'Sarah Williams', 
      businessName: 'Artisan Bakery', 
      quoteDate: new Date(2025, 3, 3), 
      premium: 3200, 
      status: 'approved',
      coverageType: 'Business Owner\'s Policy'
    },
    { 
      id: 'Q-39465', 
      clientName: 'Michael Chen', 
      businessName: 'Chen Technology Solutions', 
      quoteDate: new Date(2025, 3, 4), 
      premium: 5100, 
      status: 'bound',
      coverageType: 'Professional Liability'
    },
    { 
      id: 'Q-39458', 
      clientName: 'Alicia Rodriguez', 
      businessName: 'AR Interior Design', 
      quoteDate: new Date(2025, 3, 5), 
      premium: 1950, 
      status: 'declined',
      coverageType: 'General Liability'
    },
    { 
      id: 'Q-39442', 
      clientName: 'David Smith', 
      businessName: 'Smith Construction Inc.', 
      quoteDate: new Date(2025, 3, 6), 
      premium: 8750, 
      status: 'approved',
      coverageType: 'Workers\' Comp'
    }
  ];
  
  // Recent activities
  recentActivities: RecentActivity[] = [
    { 
      id: 1, 
      type: 'quote', 
      description: 'New quote created', 
      time: new Date(2025, 3, 7, 14, 32), 
      clientName: 'Robert Johnson',
      icon: 'fa-file-invoice-dollar'
    },
    { 
      id: 2, 
      type: 'policy', 
      description: 'Policy bound', 
      time: new Date(2025, 3, 7, 11, 15), 
      clientName: 'Michael Chen',
      icon: 'fa-file-signature'
    },
    { 
      id: 3, 
      type: 'message', 
      description: 'New message received', 
      time: new Date(2025, 3, 7, 9, 45), 
      clientName: 'Sarah Williams',
      icon: 'fa-envelope'
    },
    { 
      id: 4, 
      type: 'claim', 
      description: 'Claim reported', 
      time: new Date(2025, 3, 6, 16, 22), 
      clientName: 'David Smith',
      icon: 'fa-exclamation-circle'
    },
    { 
      id: 5, 
      type: 'quote', 
      description: 'Quote declined', 
      time: new Date(2025, 3, 6, 13, 10), 
      clientName: 'Alicia Rodriguez',
      icon: 'fa-times-circle'
    }
  ];
  
  // Tasks
  tasks: Task[] = [
    { id: 1, title: 'Follow up with Robert Johnson', dueDate: new Date(2025, 3, 10), priority: 'high', completed: false },
    { id: 2, title: 'Renew Smith Construction policy', dueDate: new Date(2025, 3, 15), priority: 'medium', completed: false },
    { id: 3, title: 'Complete product training', dueDate: new Date(2025, 3, 12), priority: 'low', completed: true },
    { id: 4, title: 'Submit monthly reports', dueDate: new Date(2025, 3, 30), priority: 'high', completed: false },
    { id: 5, title: 'Client review meeting - AR Interior', dueDate: new Date(2025, 3, 18), priority: 'medium', completed: false }
  ];
  
  // User preferences
  notificationsEnabled: boolean = true;
  darkModeEnabled: boolean = false;
  
  constructor(private router: Router) {}
  
  ngOnInit(): void {
    // Initialize dashboard - could fetch real data from a service
    this.generatePieSegments();
  }
  
  // Calculate and generate pie chart segments
  generatePieSegments(): void {
    const total = this.lineOfBusinessData.reduce((sum, item) => sum + item.value, 0);
    let startAngle = 0;
    
    this.pieSegments = this.lineOfBusinessData.map((item, index) => {
      const percentage = item.value / total;
      const angle = percentage * Math.PI * 2;
      const endAngle = startAngle + angle;
      
      // Create the segment path
      const path = this.createPieSegment(50, 50, 50, startAngle, endAngle);
      const color = this.pieChartColors[index % this.pieChartColors.length];
      
      // Update start angle for next segment
      startAngle = endAngle;
      
      return { path, color };
    });
  }
  
  // Create SVG path for a pie segment
  createPieSegment(cx: number, cy: number, r: number, startAngle: number, endAngle: number): string {
    // Calculate points
    const x1 = cx + r * Math.cos(startAngle);
    const y1 = cy + r * Math.sin(startAngle);
    const x2 = cx + r * Math.cos(endAngle);
    const y2 = cy + r * Math.sin(endAngle);
    
    // Determine if the arc should be drawn the long way around
    const largeArcFlag = endAngle - startAngle > Math.PI ? 1 : 0;
    
    // Create the path string
    return `M ${cx} ${cy} L ${x1} ${y1} A ${r} ${r} 0 ${largeArcFlag} 1 ${x2} ${y2} Z`;
  }
  
  // Get color for a segment based on its value (for legend)
  getSegmentColor(value: number): string {
    const index = this.lineOfBusinessData.findIndex(item => item.value === value);
    return this.pieChartColors[index % this.pieChartColors.length];
  }
  
  // Filter quotes
  getFilteredQuotes(): ClientQuote[] {
    let filteredQuotes = this.recentQuotes;
    
    // Apply status filter
    if (this.quoteFilter !== 'all') {
      filteredQuotes = filteredQuotes.filter(quote => quote.status === this.quoteFilter);
    }
    
    // Apply search query
    if (this.searchQuery.trim()) {
      const query = this.searchQuery.toLowerCase();
      filteredQuotes = filteredQuotes.filter(quote => 
        quote.clientName.toLowerCase().includes(query) || 
        quote.businessName.toLowerCase().includes(query) ||
        quote.id.toLowerCase().includes(query)
      );
    }
    
    return filteredQuotes;
  }
  
  // Toggle task completion
  toggleTaskCompletion(task: Task): void {
    task.completed = !task.completed;
    // In a real app, you would update this in a service or API
  }
  
  // Calculate quote status class for styling
  getStatusClass(status: string): string {
    switch(status) {
      case 'approved': return 'status-approved';
      case 'pending': return 'status-pending';
      case 'declined': return 'status-declined';
      case 'bound': return 'status-bound';
      default: return '';
    }
  }
  
  // Calculate progress percentage for targets
  getProgressPercentage(actual: number, target: number): number {
    return Math.min(Math.round((actual / target) * 100), 100);
  }
  
  // Navigate to create a new quote
  createNewQuote(): void {
    this.router.navigate(['/insurance']);
  }
  
  // Toggle dark mode
  toggleDarkMode(): void {
    this.darkModeEnabled = !this.darkModeEnabled;
    document.body.classList.toggle('dark-mode', this.darkModeEnabled);
  }
  
  // Toggle notifications
  toggleNotifications(): void {
    this.notificationsEnabled = !this.notificationsEnabled;
    // In a real app, you would update user preferences
  }
}