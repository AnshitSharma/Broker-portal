import { ComponentFixture, TestBed } from '@angular/core/testing';
import { Router } from '@angular/router';
import { NavbarComponent } from './navbar.component';
import { By } from '@angular/platform-browser';

describe('NavbarComponent', () => {
  let component: NavbarComponent;
  let fixture: ComponentFixture<NavbarComponent>;
  let mockRouter: any;
  let documentBodySpy: jasmine.SpyObj<CSSStyleDeclaration>;

  beforeEach(async () => {
    // Create a mock router
    mockRouter = {
      navigate: jasmine.createSpy('navigate')
    };

    // Create a spy for document.body.style
    documentBodySpy = jasmine.createSpyObj('CSSStyleDeclaration', [], {
      overflow: ''
    });
    Object.defineProperty(document.body, 'style', { value: documentBodySpy });

    await TestBed.configureTestingModule({
      imports: [NavbarComponent],
      providers: [
        { provide: Router, useValue: mockRouter }
      ]
    }).compileComponents();

    // Mock localStorage
    spyOn(localStorage, 'getItem').and.returnValue(null);
    spyOn(localStorage, 'setItem').and.callThrough();

    fixture = TestBed.createComponent(NavbarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should initialize with isLoggedIn set to false', () => {
    expect(component.isLoggedIn).toBeFalse();
  });

  it('should initialize with mobileMenuOpen set to false', () => {
    expect(component.mobileMenuOpen).toBeFalse();
  });

  it('should toggle mobile menu when toggleMobileMenu is called', () => {
    expect(component.mobileMenuOpen).toBeFalse();
    component.toggleMobileMenu();
    expect(component.mobileMenuOpen).toBeTrue();
    component.toggleMobileMenu();
    expect(component.mobileMenuOpen).toBeFalse();
  });

  it('should close mobile menu when closeMobileMenu is called', () => {
    component.mobileMenuOpen = true;
    component.closeMobileMenu();
    expect(component.mobileMenuOpen).toBeFalse();
  });

  it('should toggle auth state and navigate to home if logged out', () => {
    expect(component.isLoggedIn).toBeFalse();
    component.toggleAuth();
    expect(component.isLoggedIn).toBeTrue();
    expect(localStorage.setItem).toHaveBeenCalledWith('isLoggedIn', 'true');
    
    component.toggleAuth();
    expect(component.isLoggedIn).toBeFalse();
    expect(mockRouter.navigate).toHaveBeenCalledWith(['/home']);
  });

  it('should set isScrolled to true when window is scrolled more than 50px', () => {
    // Mock window scroll
    spyOnProperty(document.documentElement, 'scrollTop').and.returnValue(60);
    
    component.onWindowScroll();
    expect(component.isScrolled).toBeTrue();
    
    // Reset scroll position
    spyOnProperty(document.documentElement, 'scrollTop').and.returnValue(30);
    
    component.onWindowScroll();
    expect(component.isScrolled).toBeFalse();
  });

  it('should close mobile menu when a nav link is clicked', () => {
    spyOn(component, 'closeMobileMenu').and.callThrough();
    
    component.mobileMenuOpen = true;
    fixture.detectChanges();
    
    const navLink = fixture.debugElement.query(By.css('.navbar-custom__nav-link'));
    navLink.triggerEventHandler('click', null);
    
    expect(component.closeMobileMenu).toHaveBeenCalled();
  });
});