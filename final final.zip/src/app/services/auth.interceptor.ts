import { HttpInterceptorFn } from '@angular/common/http';
import { inject } from '@angular/core';
import { Router } from '@angular/router';
import { catchError, throwError } from 'rxjs';
import { AuthService } from './auth.service';

export const authInterceptor: HttpInterceptorFn = (req, next) => {
  const authService = inject(AuthService);
  const router = inject(Router);
  
  // Skip interceptor for login and register requests
  if (req.url.includes('/api/Auth/login') || req.url.includes('/api/Auth/register')) {
    return next(req);
  }
  
  // Get the auth token from the service
  const token = authService.getToken();

  // Clone the request and add the authorization header if token exists
  if (token) {
    const authReq = req.clone({
      setHeaders: {
        Authorization: `Bearer ${token}`
      }
    });
    
    return next(authReq).pipe(
      catchError(error => {
        if (error.status === 401) {
          // If the request returns a 401 Unauthorized error, the token has expired
          // or is invalid. Log the user out and redirect to login.
          authService.logout();
          router.navigate(['/login']);
        }
        return throwError(() => error);
      })
    );
  }

  // If no token, just pass the request through
  return next(req).pipe(
    catchError(error => {
      if (error.status === 401) {
        // No token but protected resource, redirect to login
        router.navigate(['/login']);
      }
      return throwError(() => error);
    })
  );
};