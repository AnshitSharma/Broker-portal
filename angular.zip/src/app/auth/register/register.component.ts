import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { AuthService, LoginRequest } from '../../services/auth.service';
import { RegisterRequest } from '../../services/auth.service';

interface RegisterData {
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  company: string;
  password: string;
  confirmPassword: string;
  agreeToTerms: boolean;
}

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule, HttpClientModule],
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  registerData: RegisterData = {
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    company: '',
    password: '',
    confirmPassword: '',
    agreeToTerms: false
  };

  loading: boolean = false;
  submitted: boolean = false;
  showPassword: boolean = false;
  errorMessage: string = '';

  // For password strength meter (optional feature)
  passwordStrength: number = 0;

  constructor(private router: Router, private authService: AuthService) { }

  ngOnInit(): void {
    // Initialize background effects
    this.initializeBackground();
  }

  togglePasswordVisibility(): void {
    this.showPassword = !this.showPassword;
  }

  isValidEmail(): boolean {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(this.registerData.email);
  }

  isPasswordValid(): boolean {
    // Password must be at least 8 characters with 1 uppercase, 1 lowercase, and 1 number
    const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[a-zA-Z\d@$!%*?&]{8,}$/;
    return passwordRegex.test(this.registerData.password);
  }

  doPasswordsMatch(): boolean {
    return this.registerData.password === this.registerData.confirmPassword;
  }

  // Optional: Calculate password strength for visual indicator
  updatePasswordStrength(): void {
    let strength = 0;
    const password = this.registerData.password;
    
    if (password.length >= 8) strength += 25;
    if (/[A-Z]/.test(password)) strength += 25;
    if (/[a-z]/.test(password)) strength += 25;
    if (/\d/.test(password)) strength += 25;
    
    this.passwordStrength = strength;
  }

  onSubmit(): void {
    this.submitted = true;
    
    // Validate the form
    if (!this.registerData.firstName || 
        !this.registerData.lastName || 
        !this.registerData.email || 
        !this.registerData.phone || 
        !this.registerData.password ||
        !this.registerData.confirmPassword ||
        !this.registerData.agreeToTerms ||
        !this.isValidEmail() ||
        !this.isPasswordValid() ||
        !this.doPasswordsMatch()) {
      return;
    }

    this.loading = true;
    this.errorMessage = '';

    // Prepare registration request
    const registerRequest: RegisterRequest = {
      firstName: this.registerData.firstName,
      lastName: this.registerData.lastName,
      email: this.registerData.email,
      phoneNumber: this.registerData.phone, // Note: API expects 'phoneNumber' field
      company: this.registerData.company,
      password: this.registerData.password,
      confirmPassword: this.registerData.confirmPassword
    };

    // Call API service
    this.authService.register(registerRequest).subscribe({
      next: (response) => {
        console.log('Registration successful', response);
        
        // Redirect to login with success message
        this.router.navigate(['/login'], { 
          state: { 
            message: 'Registration successful! Please log in to continue.' 
          } 
        });
      },
      error: (error) => {
        this.errorMessage = typeof error === 'string' ? error : 'Registration failed. Please try again.';
        this.loading = false;
        console.error('Registration error:', error);
      },
      complete: () => {
        this.loading = false;
      }
    });
  }

  // Initialize background effects
  private initializeBackground(): void {
    // This would normally create animated particles using a library like particles.js
    // For now, we'll use CSS effects only to keep things simple
    console.log('Background animation initialized');
  }
}