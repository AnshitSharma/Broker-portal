import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { Observable, of, throwError } from 'rxjs';
import { catchError, map, tap } from 'rxjs/operators';

// API Client interface
export interface ApiClient {
  clientId: number;
  clientName: string;
  businessName?: string;
  email: string;
  phone: string;
  status: string;
  activePolicies: number;
}

// API Response interface
export interface ApiResponse {
  success: boolean;
  message: string;
  data?: any;
}

// Client Stats interface
export interface ClientStats {
  totalClients: number;
  activeClients: number;
  newClientsThisMonth: number;
  businesses: number;
}

@Injectable({
  providedIn: 'root'
})
export class ClientService {
  // API URLs - replace with your actual API endpoints
  private apiUrl = 'https://api.example.com';
  private clientsUrl = `${this.apiUrl}/clients`;
  private clientStatsUrl = `${this.apiUrl}/clients/stats`;
  
  // Header keys
  private readonly AUTH_TOKEN_KEY = 'auth_token';
  
  // Mock data for when API is not available
  private mockClients: ApiClient[] = [
    {
      clientId: 10,
      clientName: 'Sarah Williams',
      businessName: 'Artisan Bakery',
      email: 'sarah.williams@example.com',
      phone: '(555) 123-4567',
      status: 'Active',
      activePolicies: 2
    },
    {
      clientId: 9,
      clientName: 'Michael Chen',
      businessName: 'Chen Technology Solutions',
      email: 'michael.chen@example.com',
      phone: '(555) 987-6543',
      status: 'Active',
      activePolicies: 1
    },
    {
      clientId: 11,
      clientName: 'John Smith',
      businessName: 'Tech Solutions LLC',
      email: 'john.smith@example.com',
      phone: '(555) 456-7890',
      status: 'Prospect',
      activePolicies: 0
    },
    {
      clientId: 12,
      clientName: 'Emily Johnson',
      businessName: 'Johnson Consulting Group',
      email: 'emily.johnson@example.com',
      phone: '(555) 234-5678',
      status: 'Active',
      activePolicies: 3
    },
    {
      clientId: 13,
      clientName: 'David Rodriguez',
      businessName: 'Rodriguez Auto Repair',
      email: 'david.rodriguez@example.com',
      phone: '(555) 876-5432',
      status: 'Inactive',
      activePolicies: 0
    }
  ];
  
  // Mock client stats
  private mockClientStats: ClientStats = {
    totalClients: 5,
    activeClients: 3,
    newClientsThisMonth: 2,
    businesses: 5
  };
  
  constructor(private http: HttpClient) { }
  
  /**
   * Get HTTP headers with authorization token
   */
  private getAuthHeaders(): HttpHeaders {
    const token = localStorage.getItem(this.AUTH_TOKEN_KEY);
    return new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token || ''}`
    });
  }
  
  /**
   * Get all clients from the API
   */
  getClients(): Observable<ApiClient[]> {
    const headers = this.getAuthHeaders();
    
    return this.http.get<ApiClient[]>(this.clientsUrl, { headers })
      .pipe(
        catchError(error => {
          console.error('Error fetching clients from API:', error);
          // Return mock data on error
          return of(this.mockClients);
        })
      );
  }
  
  /**
   * Get client statistics from the API
   */
  getClientStats(): Observable<ClientStats> {
    const headers = this.getAuthHeaders();
    
    return this.http.get<ClientStats>(this.clientStatsUrl, { headers })
      .pipe(
        catchError(error => {
          console.error('Error fetching client stats from API:', error);
          // Return mock data on error
          return of(this.mockClientStats);
        })
      );
  }
  
  /**
   * Add a new client to the API
   */
  addClient(client: ApiClient): Observable<ApiResponse> {
    const headers = this.getAuthHeaders();
    
    return this.http.post<ApiResponse>(this.clientsUrl, client, { headers })
      .pipe(
        catchError(error => {
          // If we're in development mode, simulate a successful response
          if (error instanceof HttpErrorResponse && error.status === 0) {
            console.warn('Development mode: Simulating successful add client response');
            
            // Create a simulated API response
            const response: ApiResponse = {
              success: true,
              message: 'Client added successfully',
              data: {
                ...client,
                clientId: Math.max(...this.mockClients.map(c => c.clientId)) + 1
              }
            };
            
            // Add to mock data
            this.mockClients.push(response.data);
            
            return of(response);
          }
          
          return throwError(() => error);
        })
      );
  }
  
  /**
   * Update an existing client in the API
   */
  updateClient(client: ApiClient): Observable<ApiResponse> {
    const headers = this.getAuthHeaders();
    const url = `${this.clientsUrl}/${client.clientId}`;
    
    return this.http.put<ApiResponse>(url, client, { headers })
      .pipe(
        tap(response => {
          // Log the successful response for debugging
          console.log('Update client response:', response);
        }),
        catchError(error => {
          if (error instanceof HttpErrorResponse) {
            // If we're getting a CORS error or network error (status 0)
            if (error.status === 0) {
              console.warn('Development mode: Simulating successful update client response');
              
              // Find and update the client in mock data
              const index = this.mockClients.findIndex(c => c.clientId === client.clientId);
              if (index !== -1) {
                this.mockClients[index] = { ...client };
              }
              
              // Return a successful response
              return of({
                success: true,
                message: 'Client updated successfully',
                data: client
              });
            }
            
            // If we received a 200 status but it was caught as an error (parsing error, etc.)
            if (error.status === 200) {
              console.warn('Received 200 status but caught as error, treating as success');
              return of({
                success: true,
                message: 'Client updated successfully',
                data: client
              });
            }
          }
          
          // Log the error for debugging
          console.error('Error updating client:', error);
          
          // Propagate the error
          return throwError(() => error);
        })
      );
  }
  
  /**
   * Delete a client from the API
   */
  deleteClient(clientId: number): Observable<ApiResponse> {
    const headers = this.getAuthHeaders();
    const url = `${this.clientsUrl}/${clientId}`;
    
    return this.http.delete<ApiResponse>(url, { headers })
      .pipe(
        catchError(error => {
          // If we're in development mode, simulate a successful response
          if (error instanceof HttpErrorResponse && error.status === 0) {
            console.warn('Development mode: Simulating successful delete client response');
            
            // Remove from mock data
            this.mockClients = this.mockClients.filter(c => c.clientId !== clientId);
            
            return of({
              success: true,
              message: 'Client deleted successfully'
            });
          }
          
          return throwError(() => error);
        })
      );
  }
}