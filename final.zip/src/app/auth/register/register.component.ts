import { Component } from '@angular/core';
import { Router, NavigationExtras } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { AuthService, RegisterRequest } from '../../services/auth.service';

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule],
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent {
  registerData: RegisterRequest = {
    firstName: '',
    lastName: '',
    username: '',
    email: '',
    company: '',
    phoneNumber: '',
    password: '',
    confirmPassword: ''
  };
  
  agreeToTerms: boolean = false;
  loading: boolean = false;
  submitted: boolean = false;
  showPassword: boolean = false;
  errorMessage: string = '';
  
  constructor(
    private router: Router, 
    private authService: AuthService
  ) { }
  
  togglePasswordVisibility(): void {
    this.showPassword = !this.showPassword;
  }
  
  isValidEmail(): boolean {
    const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    return emailRegex.test(this.registerData.email);
  }
  
  isValidPassword(): boolean {
    // Password must be at least 8 characters and include at least one number, one uppercase, and one lowercase letter
    const passwordRegex = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}$/;
    return passwordRegex.test(this.registerData.password);
  }
  
  doPasswordsMatch(): boolean {
    return this.registerData.password === this.registerData.confirmPassword;
  }
  
  validateForm(): boolean {
    if (!this.registerData.firstName ||
        !this.registerData.lastName ||
        !this.registerData.username ||
        !this.registerData.email ||
        !this.registerData.password ||
        !this.registerData.confirmPassword ||
        !this.agreeToTerms) {
      return false;
    }
    
    if (!this.isValidEmail()) {
      return false;
    }
    
    if (!this.isValidPassword()) {
      return false;
    }
    
    if (!this.doPasswordsMatch()) {
      return false;
    }
    
    return true;
  }
  
  onSubmit(): void {
    this.submitted = true;
    
    if (!this.validateForm()) {
      return;
    }
    
    this.loading = true;
    this.errorMessage = '';
    
    // Call API service
    this.authService.register(this.registerData).subscribe({
      next: () => {
        // Navigate to login page with success message
        const navigationExtras: NavigationExtras = {
          state: {
            message: 'Account created successfully! Please sign in.'
          }
        };
        this.router.navigate(['/login'], navigationExtras);
      },
      error: (error) => {
        this.errorMessage = error.message || 'Registration failed. Please try again.';
        this.loading = false;
      },
      complete: () => {
        this.loading = false;
      }
    });
  }
}