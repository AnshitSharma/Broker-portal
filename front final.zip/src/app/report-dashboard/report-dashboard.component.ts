import { Component, OnInit, HostListener } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { Router, NavigationEnd } from '@angular/router';
import { filter } from 'rxjs/operators';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { catchError, finalize, forkJoin, of } from 'rxjs';

// Define interfaces for API responses
interface ApiClient {
  clientId: number;
  clientName: string;
  businessName: string;
  email: string;
  phone: string;
  status: string;
  activePolicies: number;
}

interface ApiQuote {
  quoteId: number;
  businessName: string;
  ownerFirstName: string;
  ownerLastName: string;
  email: string;
  phone: string;
  businessStructure: string;
  industryClass: string;
  annualRevenue: number;
  businessAddress: string;
  zipCode: string;
  hasMultipleLocations: boolean;
  isNonProfit: boolean;
  businessDescription: string;
  hasAdditionalServices: boolean;
  hasClaimsHistory: boolean;
  claimCount: number;
  isHazardous: boolean;
  yearsInBusiness: number;
  employeeCount: number;
  executiveOfficerCount: number;
  coverageLimit: number;
  annualPremium: number;
  monthlyPremium: number;
  createdDate: string;
  status: string;
  selectedCoverages: ApiCoverage[];
  clientId?: number;
}

interface ApiCoverage {
  name: string;
  description: string;
  isBaseCoverage: boolean;
  factorValue: number;
}

// Interfaces for UI components
interface PieSegment {
  path: string;
  color: string;
}

interface CoverageDistribution {
  name: string;
  value: number;
  color: string;
}

interface TopClient {
  name: string;
  businessName: string;
  activePolicies: number;
  premium: number;
  lastActivity: Date;
}

@Component({
  selector: 'app-report-dashboard',
  standalone: true,
  imports: [CommonModule, RouterModule, FormsModule],
  templateUrl: './report-dashboard.component.html',
  styleUrls: ['./report-dashboard.component.css']
})
export class ReportDashboardComponent implements OnInit {
  // Expose Math object to template
  Math = Math;
  
  // API endpoint
  private apiBaseUrl = 'http://localhost:5075/api';
  private readonly AUTH_TOKEN_KEY = 'auth_token';
  
  // UI State
  darkModeEnabled: boolean = false;
  sidebarCollapsed: boolean = false;
  mobileMenuOpen: boolean = false;
  currentRoute: string = '/reports';
  
  // Broker details
  brokerName: string = 'John Broker';
  brokerRole: string = 'Insurance Specialist';
  
  // Loading state
  isLoading: boolean = false;
  apiError: boolean = false;
  
  // Response messaging
  responseMessage: string = '';
  isSuccess: boolean = true;
  
  // Authentication state
  isAuthenticated: boolean = true;
  
  // Screen size detection
  isMobileView: boolean = false;
  
  // Date range selector
  selectedDateRange: string = '30';
  startDate: string = '';
  endDate: string = '';
  
  // Chart type toggles
  chartTypes: {[key: string]: string} = {
    premium: 'bar',
    quotes: 'bar',
    conversion: 'line'
  };
  
  // Performance metrics
  totalPremium: number = 0;
  premiumTrend: number = 0;
  totalQuotes: number = 0;
  quotesTrend: number = 0;
  totalBoundPolicies: number = 0;
  boundPoliciesTrend: number = 0;
  conversionRate: number = 0;
  conversionTrend: number = 0;
  
  // Chart data
  monthLabels: string[] = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'];
  lastSixMonths: string[] = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'];
  premiumData: number[] = [];
  quotesData: number[] = [];
  policiesData: number[] = [];
  conversionRateData: number[] = [];
  
  // API data
  clients: ApiClient[] = [];
  quotes: ApiQuote[] = [];
  
  // Coverage distribution data
  coverageDistribution: CoverageDistribution[] = [];
  
  // Pie chart segments
  pieSegments: PieSegment[] = [];
  
  // Top clients data
  topClients: TopClient[] = [];
  
  // Export options modal
  showExportModal: boolean = false;
  exportDateRange: string = 'current';
  includeCharts: boolean = true;
  includeTables: boolean = true;
  includeMetrics: boolean = true;
  
  // Notification modal
  showNotification: boolean = false;
  notificationTitle: string = '';
  notificationMessage: string = '';
  notificationSuccess: boolean = true;

  // Industry class distribution for backup data
  private industryClassColors: {[key: string]: string} = {
    'Professional Services': '#4A6BD6',
    'Retail': '#42C0C0',
    'Construction': '#CC7952',
    'Food and Beverage': '#87D987',
    'Other': '#8F8F8F'
  };

  // Coverage type colors for backup data
  private coverageTypeColors: {[key: string]: string} = {
    'Bodily Injury and Property Damage': '#4A6BD6',
    'Products and Completed Operations': '#42C0C0',
    'Advertising Injury': '#CC7952',
    'Legal Defense Cost': '#87D987',
    'Professional Liability': '#E76F51',
    'Reputational Harm': '#2A9D8F',
    'Other': '#8F8F8F'
  };
  
  constructor(
    private router: Router,
    private http: HttpClient
  ) {
    // Subscribe to router events to track current route
    this.router.events
      .pipe(filter(event => event instanceof NavigationEnd))
      .subscribe((event: any) => {
        this.currentRoute = event.url;
        // Close mobile menu when navigating
        this.mobileMenuOpen = false;
      });
      
    // Check initial screen size
    this.checkScreenSize();
    
    // Initialize date range
    this.setDefaultDateRange();
  }
  
  // Host listener to detect screen size changes
  @HostListener('window:resize', ['$event'])
  onResize() {
    this.checkScreenSize();
  }
  
  // Check if the screen is mobile size
  checkScreenSize() {
    this.isMobileView = window.innerWidth < 992;
    // Auto-collapse sidebar on mobile
    if (this.isMobileView && !this.mobileMenuOpen) {
      this.sidebarCollapsed = true;
    }
  }
  
  ngOnInit(): void {
    // Check if dark mode is saved in localStorage
    const savedDarkMode = localStorage.getItem('darkMode');
    if (savedDarkMode) {
      this.darkModeEnabled = JSON.parse(savedDarkMode);
      document.body.classList.toggle('dark-mode', this.darkModeEnabled);
    }
    
    // Check if sidebar state is saved in localStorage
    const savedSidebarState = localStorage.getItem('sidebarCollapsed');
    if (savedSidebarState) {
      this.sidebarCollapsed = JSON.parse(savedSidebarState);
    }
    
    // Check authentication
    this.checkAuthentication();
    
    // Load API data (clients and quotes)
    this.loadApiData();
  }
  
  /**
   * Check if user is authenticated
   */
  checkAuthentication(): void {
    const token = localStorage.getItem(this.AUTH_TOKEN_KEY);
    this.isAuthenticated = !!token;
    
    // If not authenticated, redirect to login
    if (!this.isAuthenticated) {
      // Store current location to redirect back after login
      sessionStorage.setItem('redirectUrl', this.currentRoute);
      
      // Show a message that we're redirecting
      this.showNotificationModal(false, 'Authentication Required', 'Please log in to view reports.');
      
      // Uncomment the next line to enable automatic redirect
      // setTimeout(() => this.router.navigate(['/login']), 2000);
    }
  }
  
  /**
   * Get authentication headers for API requests
   */
  getAuthHeaders(): HttpHeaders {
    const token = localStorage.getItem(this.AUTH_TOKEN_KEY);
    return new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token || ''}`
    });
  }
  
  /**
   * Set default date range based on selection
   */
  setDefaultDateRange(): void {
    const today = new Date();
    const endDate = new Date(today);
    
    let startDate: Date;
    
    if (this.selectedDateRange === 'custom' && this.startDate && this.endDate) {
      // Use already set custom dates
      return;
    }
    
    // Calculate start date based on selection
    switch(this.selectedDateRange) {
      case '7':
        startDate = new Date(today);
        startDate.setDate(today.getDate() - 7);
        break;
      case '90':
        startDate = new Date(today);
        startDate.setDate(today.getDate() - 90);
        break;
      case '365':
        startDate = new Date(today);
        startDate.setDate(today.getDate() - 365);
        break;
      case '30':
      default:
        startDate = new Date(today);
        startDate.setDate(today.getDate() - 30);
        break;
    }
    
    // Format dates for input fields
    this.startDate = this.formatDateForInput(startDate);
    this.endDate = this.formatDateForInput(endDate);
  }
  
  /**
   * Format a date for input field (YYYY-MM-DD)
   */
  formatDateForInput(date: Date): string {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  }
  
  /**
   * Update date range when selector changes
   */
  updateDateRange(): void {
    this.setDefaultDateRange();
    this.updateCharts();
  }
  
  /**
   * Load all API data (clients and quotes)
   */
  loadApiData(): void {
    this.isLoading = true;
    this.apiError = false;
    
    // Check if authenticated
    if (!this.isAuthenticated) {
      this.isLoading = false;
      this.showNotificationModal(false, 'Authentication Required', 'Please log in to view reports.');
      return;
    }
    
    const httpOptions = {
      headers: this.getAuthHeaders()
    };
    
    // Use forkJoin to make parallel API calls and wait for all to complete
    forkJoin({
      clients: this.http.get<ApiClient[]>(`${this.apiBaseUrl}/Clients`, httpOptions)
        .pipe(catchError(error => {
          console.error('Error loading clients:', error);
          return of([] as ApiClient[]);
        })),
      quotes: this.http.get<ApiQuote[]>(`${this.apiBaseUrl}/Quote/insurance-quotes`, httpOptions)
        .pipe(catchError(error => {
          console.error('Error loading quotes:', error);
          return of([] as ApiQuote[]);
        }))
    })
    .pipe(
      finalize(() => {
        this.isLoading = false;
      })
    )
    .subscribe({
      next: (results) => {
        // Handle successful API response
        if (Array.isArray(results.clients) && results.clients.length > 0) {
          this.clients = results.clients;
        } else {
          // Use fallback data for clients
          this.loadFallbackClients();
          this.apiError = true;
        }
        
        if (Array.isArray(results.quotes) && results.quotes.length > 0) {
          this.quotes = results.quotes;
        } else {
          // Use fallback data for quotes
          this.loadFallbackQuotes();
          this.apiError = true;
        }
        
        // Process data to build reports
        this.processReportData();
        
        // Show success message if no errors
        if (!this.apiError) {
          this.responseMessage = 'Report data loaded successfully';
          this.isSuccess = true;
          
          // Clear message after 3 seconds
          setTimeout(() => {
            this.responseMessage = '';
          }, 3000);
        } else {
          this.responseMessage = 'Could not load data from API. Using fallback data.';
          this.isSuccess = false;
          
          // Clear message after 5 seconds
          setTimeout(() => {
            this.responseMessage = '';
          }, 5000);
        }
      },
      error: (error) => {
        console.error('Error loading API data:', error);
        this.apiError = true;
        
        // Load fallback data
        this.loadFallbackClients();
        this.loadFallbackQuotes();
        
        // Process fallback data
        this.processReportData();
        
        // Show error message
        this.responseMessage = 'Failed to load data from API. Using fallback data.';
        this.isSuccess = false;
        
        // Clear message after 5 seconds
        setTimeout(() => {
          this.responseMessage = '';
        }, 5000);
      }
    });
  }
  
  /**
   * Load fallback client data when API fails
   */
  loadFallbackClients(): void {
    this.clients = [
      {
        clientId: 12,
        clientName: "John Siddharth",
        businessName: "Tech Solutions LLC",
        email: "john@techsolutions.com",
        phone: "555-123-4567",
        status: "Prospect",
        activePolicies: 0
      },
      {
        clientId: 11,
        clientName: "John Smith",
        businessName: "Tech Solutions LLC",
        email: "john@techsolutions.com",
        phone: "555-123-4567",
        status: "Prospect",
        activePolicies: 0
      },
      {
        clientId: 10,
        clientName: "Sarah Williams",
        businessName: "Artisan Bakery",
        email: "sarah@artisanbakery.com",
        phone: "555-234-5678",
        status: "Active",
        activePolicies: 2
      },
      {
        clientId: 9,
        clientName: "Michael Chen",
        businessName: "Chen Technology Solutions",
        email: "michael@chentechsolutions.com",
        phone: "555-345-6789",
        status: "Active",
        activePolicies: 3
      },
      {
        clientId: 8,
        clientName: "Alicia Rodriguez",
        businessName: "AR Interior Design",
        email: "alicia@arinteriordesign.com",
        phone: "555-456-7890",
        status: "Active",
        activePolicies: 1
      }
    ];
  }
  
  /**
   * Load fallback quote data when API fails
   */
  loadFallbackQuotes(): void {
    this.quotes = [
      {
        quoteId: 22,
        businessName: "Acme Consulting LLC",
        ownerFirstName: "John",
        ownerLastName: "Smith",
        email: "john.smith@acmeconsulting.com",
        phone: "555-123-4567",
        businessStructure: "Limited Liability Corporation (LLC)",
        industryClass: "Professional Services",
        annualRevenue: 750000,
        businessAddress: "123 Business Ave, Suite 101",
        zipCode: "10001",
        hasMultipleLocations: false,
        isNonProfit: false,
        businessDescription: "IT consulting services specializing in software development and cybersecurity",
        hasAdditionalServices: true,
        hasClaimsHistory: true,
        claimCount: 3,
        isHazardous: false,
        yearsInBusiness: 5,
        employeeCount: 15,
        executiveOfficerCount: 3,
        coverageLimit: 1000000,
        annualPremium: 8889,
        monthlyPremium: 740.75,
        createdDate: "2025-04-26T21:53:22.2795056",
        status: "pending",
        selectedCoverages: [
          {
            name: "Bodily Injury and Property Damage",
            description: "Covers physical injuries and damage caused to third parties.",
            isBaseCoverage: true,
            factorValue: 1.0
          },
          {
            name: "Products and Completed Operations",
            description: "Protects against liability from sold products and completed services.",
            isBaseCoverage: false,
            factorValue: 0.25
          },
          {
            name: "Professional Liability",
            description: "Covers claims arising from professional services that resulted in financial loss.",
            isBaseCoverage: false,
            factorValue: 1.75
          }
        ]
      },
      {
        quoteId: 21,
        businessName: "Acme Consulting LLC",
        ownerFirstName: "John",
        ownerLastName: "Smith",
        email: "john.smith@acmeconsulting.com",
        phone: "555-123-4567",
        businessStructure: "Limited Liability Corporation (LLC)",
        industryClass: "Professional Services",
        annualRevenue: 750000,
        businessAddress: "123 Business Ave, Suite 101",
        zipCode: "10001",
        hasMultipleLocations: false,
        isNonProfit: false,
        businessDescription: "IT consulting services specializing in software development",
        hasAdditionalServices: true,
        hasClaimsHistory: true,
        claimCount: 2,
        isHazardous: false,
        yearsInBusiness: 5,
        employeeCount: 15,
        executiveOfficerCount: 3,
        coverageLimit: 1000000,
        annualPremium: 8400,
        monthlyPremium: 700.00,
        createdDate: "2025-03-15T14:30:22.2795056",
        status: "approved",
        selectedCoverages: [
          {
            name: "Bodily Injury and Property Damage",
            description: "Covers physical injuries and damage caused to third parties.",
            isBaseCoverage: true,
            factorValue: 1.0
          },
          {
            name: "Advertising Injury",
            description: "Covers claims related to misleading advertisements and copyright issues.",
            isBaseCoverage: false,
            factorValue: 0.15
          }
        ]
      },
      {
        quoteId: 20,
        businessName: "Green Landscaping",
        ownerFirstName: "Mark",
        ownerLastName: "Anderson",
        email: "mark@greenlandscaping.com",
        phone: "555-987-6543",
        businessStructure: "Sole Proprietorship",
        industryClass: "Construction",
        annualRevenue: 350000,
        businessAddress: "789 Garden Way",
        zipCode: "10002",
        hasMultipleLocations: false,
        isNonProfit: false,
        businessDescription: "Landscaping and garden maintenance services",
        hasAdditionalServices: false,
        hasClaimsHistory: false,
        claimCount: 0,
        isHazardous: false,
        yearsInBusiness: 3,
        employeeCount: 5,
        executiveOfficerCount: 1,
        coverageLimit: 500000,
        annualPremium: 3400,
        monthlyPremium: 283.33,
        createdDate: "2025-02-10T09:15:00.0000000",
        status: "bound",
        selectedCoverages: [
          {
            name: "Bodily Injury and Property Damage",
            description: "Covers physical injuries and damage caused to third parties.",
            isBaseCoverage: true,
            factorValue: 1.0
          }
        ]
      },
      {
        quoteId: 19,
        businessName: "Fresh Bakery",
        ownerFirstName: "Emily",
        ownerLastName: "Martinez",
        email: "emily@freshbakery.com",
        phone: "555-456-7890",
        businessStructure: "Limited Liability Corporation (LLC)",
        industryClass: "Food and Beverage",
        annualRevenue: 250000,
        businessAddress: "456 Main St",
        zipCode: "10003",
        hasMultipleLocations: false,
        isNonProfit: false,
        businessDescription: "Artisanal bakery specializing in bread and pastries",
        hasAdditionalServices: false,
        hasClaimsHistory: false,
        claimCount: 0,
        isHazardous: false,
        yearsInBusiness: 2,
        employeeCount: 4,
        executiveOfficerCount: 1,
        coverageLimit: 500000,
        annualPremium: 1875,
        monthlyPremium: 156.25,
        createdDate: "2025-01-05T11:30:00.0000000",
        status: "bound",
        selectedCoverages: [
          {
            name: "Products and Completed Operations",
            description: "Protects against liability from sold products and completed services.",
            isBaseCoverage: true,
            factorValue: 1.0
          }
        ]
      },
      {
        quoteId: 18,
        businessName: "Tech Solutions",
        ownerFirstName: "Michael",
        ownerLastName: "Chen",
        email: "michael@techsolutions.com",
        phone: "555-789-0123",
        businessStructure: "S-Corporation",
        industryClass: "Professional Services",
        annualRevenue: 1200000,
        businessAddress: "789 Tech Blvd",
        zipCode: "10004",
        hasMultipleLocations: true,
        isNonProfit: false,
        businessDescription: "IT consulting and software development",
        hasAdditionalServices: true,
        hasClaimsHistory: false,
        claimCount: 0,
        isHazardous: false,
        yearsInBusiness: 7,
        employeeCount: 25,
        executiveOfficerCount: 4,
        coverageLimit: 2000000,
        annualPremium: 5100,
        monthlyPremium: 425.00,
        createdDate: "2024-12-15T14:45:00.0000000",
        status: "bound",
        selectedCoverages: [
          {
            name: "Advertising Injury",
            description: "Covers claims related to misleading advertisements and copyright issues.",
            isBaseCoverage: true,
            factorValue: 1.0
          },
          {
            name: "Professional Liability",
            description: "Covers claims arising from professional services that resulted in financial loss.",
            isBaseCoverage: false,
            factorValue: 1.75
          }
        ]
      }
    ];
  }
  
  /**
   * Process data from API to build report components
   */
  processReportData(): void {
    // Calculate performance metrics
    this.calculatePerformanceMetrics();
    
    // Build top clients list
    this.buildTopClientsList();
    
    // Generate coverage distribution data
    this.generateCoverageDistribution();
    
    // Generate chart data
    this.generateChartData();
    
    // Generate pie chart segments
    this.generatePieSegments();
  }
  
  /**
   * Calculate performance metrics from quotes
   */
  calculatePerformanceMetrics(): void {
    // Calculate total premium
    this.totalPremium = this.quotes.reduce((sum, quote) => sum + quote.annualPremium, 0);
    
    // Calculate total quotes count
    this.totalQuotes = this.quotes.length;
    
    // Calculate total bound policies count
    this.totalBoundPolicies = this.quotes.filter(quote => quote.status.toLowerCase() === 'bound').length;
    
    // Calculate conversion rate (bound policies / total quotes)
    this.conversionRate = this.totalQuotes > 0 
      ? Math.round((this.totalBoundPolicies / this.totalQuotes) * 100)
      : 0;
    
    // Generate random trends for demo (in real app, would compare to previous period)
    this.premiumTrend = Math.round((Math.random() * 30) - 10);
    this.quotesTrend = Math.round((Math.random() * 30) - 10);
    this.boundPoliciesTrend = Math.round((Math.random() * 30) - 10);
    this.conversionTrend = Math.round((Math.random() * 20) - 5);
  }
  
  /**
   * Build list of top clients by premium
   */
  buildTopClientsList(): void {
    // Create a map of clientId to total premium
    const clientPremiums = new Map<number, number>();
    const clientBusinessNames = new Map<number, string>();
    const clientActivePolicies = new Map<number, number>();
    const clientLastActivity = new Map<number, Date>();
    
    // Collect data from quotes
    this.quotes.forEach(quote => {
      if (quote.clientId) {
        // Add premium to client's total
        const currentPremium = clientPremiums.get(quote.clientId) || 0;
        clientPremiums.set(quote.clientId, currentPremium + quote.annualPremium);
        
        // Store business name
        clientBusinessNames.set(quote.clientId, quote.businessName);
        
        // Set active policies (from client data if available)
        const client = this.clients.find(c => c.clientId === quote.clientId);
        if (client) {
          clientActivePolicies.set(quote.clientId, client.activePolicies);
        } else {
          // If client not found, use 1 as default for bound quotes
          if (quote.status.toLowerCase() === 'bound') {
            const current = clientActivePolicies.get(quote.clientId) || 0;
            clientActivePolicies.set(quote.clientId, current + 1);
          } else {
            clientActivePolicies.set(quote.clientId, 0);
          }
        }
        
        // Update last activity date if quote is newer
        const quoteDate = new Date(quote.createdDate);
        const currentLastActivity = clientLastActivity.get(quote.clientId);
        if (!currentLastActivity || quoteDate > currentLastActivity) {
          clientLastActivity.set(quote.clientId, quoteDate);
        }
      }
    });
    
    // Create top clients array from collected data
    const topClientsList: TopClient[] = [];
    
    // Add clients from clients data
    this.clients.forEach(client => {
      if (clientPremiums.has(client.clientId)) {
        topClientsList.push({
          name: client.clientName,
          businessName: client.businessName,
          activePolicies: client.activePolicies,
          premium: clientPremiums.get(client.clientId) || 0,
          lastActivity: clientLastActivity.get(client.clientId) || new Date()
        });
      }
    });
    
    // Add clients that were only in quotes but not in clients data
    clientPremiums.forEach((premium, clientId) => {
      const exists = topClientsList.some(client => 
        this.clients.some(apiClient => apiClient.clientId === clientId));
      
      if (!exists) {
        // Find client name from quotes
        const quote = this.quotes.find(q => q.clientId === clientId);
        if (quote) {
          topClientsList.push({
            name: `${quote.ownerFirstName} ${quote.ownerLastName}`,
            businessName: clientBusinessNames.get(clientId) || '',
            activePolicies: clientActivePolicies.get(clientId) || 0,
            premium: premium,
            lastActivity: clientLastActivity.get(clientId) || new Date()
          });
        }
      }
    });
    
    // Sort by premium (highest first) and take top 5
    this.topClients = topClientsList
      .sort((a, b) => b.premium - a.premium)
      .slice(0, 5);
    
    // If no clients found, use fallback data
    if (this.topClients.length === 0) {
      this.topClients = [
        {
          name: 'Michael Chen',
          businessName: 'Chen Technology Solutions',
          activePolicies: 3,
          premium: 12500,
          lastActivity: new Date(2025, 3, 15)
        },
        {
          name: 'Sarah Williams',
          businessName: 'Artisan Bakery',
          activePolicies: 2,
          premium: 8750,
          lastActivity: new Date(2025, 3, 10)
        },
        {
          name: 'Robert Johnson',
          businessName: 'Johnson Consulting LLC',
          activePolicies: 1,
          premium: 7200,
          lastActivity: new Date(2025, 3, 8)
        },
        {
          name: 'Emily Martinez',
          businessName: 'Martinez Floral Design',
          activePolicies: 2,
          premium: 6500,
          lastActivity: new Date(2025, 3, 5)
        },
        {
          name: 'David Smith',
          businessName: 'Smith Construction Inc.',
          activePolicies: 1,
          premium: 5800,
          lastActivity: new Date(2025, 3, 1)
        }
      ];
    }
  }
  
  /**
   * Generate coverage distribution data for pie chart
   */
  generateCoverageDistribution(): void {
    // Count selected coverages
    const coverageCounts = new Map<string, number>();
    let totalCoverage = 0;
    
    // Collect coverage data from quotes
    this.quotes.forEach(quote => {
      if (quote.selectedCoverages && quote.selectedCoverages.length > 0) {
        quote.selectedCoverages.forEach(coverage => {
          const current = coverageCounts.get(coverage.name) || 0;
          coverageCounts.set(coverage.name, current + 1);
          totalCoverage++;
        });
      }
    });
    
    // Convert to percentages and create distribution array
    this.coverageDistribution = [];
    
    // Use predefined colors for known coverage types
    coverageCounts.forEach((count, name) => {
      const percentage = Math.round((count / totalCoverage) * 100);
      if (percentage > 0) {
        this.coverageDistribution.push({
          name: name,
          value: percentage,
          color: this.coverageTypeColors[name] || '#8F8F8F'
        });
      }
    });
    
    // Sort by percentage (highest first)
    this.coverageDistribution.sort((a, b) => b.value - a.value);
    
    // If no coverage data, use fallback
    if (this.coverageDistribution.length === 0) {
      this.coverageDistribution = [
        { name: 'Bodily Injury and Property Damage', value: 35, color: '#4A6BD6' },
        { name: 'Products and Completed Operations', value: 25, color: '#42C0C0' },
        { name: 'Advertising Injury', value: 15, color: '#CC7952' },
        { name: 'Professional Liability', value: 15, color: '#87D987' },
        { name: 'Other', value: 10, color: '#8F8F8F' }
      ];
    }
    
    // Ensure total is 100% (handle rounding errors)
    const totalPercentage = this.coverageDistribution.reduce((sum, item) => sum + item.value, 0);
    if (totalPercentage !== 100 && this.coverageDistribution.length > 0) {
      // Adjust the largest item
      this.coverageDistribution[0].value += (100 - totalPercentage);
    }
  }
  
  /**
   * Generate chart data (premiumData, quotesData, policiesData, conversionRateData)
   */
  generateChartData(): void {
    // Get last 6 months labels
    this.lastSixMonths = this.getLast6MonthLabels();
    this.monthLabels = [...this.lastSixMonths];
    
    // Initialize arrays with zeros
    this.premiumData = new Array(6).fill(0);
    this.quotesData = new Array(6).fill(0);
    this.policiesData = new Array(6).fill(0);
    this.conversionRateData = new Array(6).fill(0);
    
    // Group quotes by month
    const quotesByMonth = new Map<number, ApiQuote[]>();
    
    // Current month and year
    const currentDate = new Date();
    const currentMonth = currentDate.getMonth();
    const currentYear = currentDate.getFullYear();
    
    // Initialize months
    for (let i = 0; i < 6; i++) {
      const monthIndex = (currentMonth - i + 12) % 12; // Go back i months
      quotesByMonth.set(monthIndex, []);
    }
    
    // Group quotes by month
    this.quotes.forEach(quote => {
      const quoteDate = new Date(quote.createdDate);
      const quoteMonth = quoteDate.getMonth();
      const quoteYear = quoteDate.getFullYear();
      
      // Only include quotes from current year or last year
      if (quoteYear === currentYear || quoteYear === currentYear - 1) {
        // Check if this month is in our 6-month range
        for (let i = 0; i < 6; i++) {
          const monthIndex = (currentMonth - i + 12) % 12;
          
          // Handle year boundary
          const monthYear = currentMonth - i < 0 ? currentYear - 1 : currentYear;
          
          if (quoteMonth === monthIndex && quoteYear === monthYear) {
            const monthQuotes = quotesByMonth.get(monthIndex) || [];
            monthQuotes.push(quote);
            quotesByMonth.set(monthIndex, monthQuotes);
            break;
          }
        }
      }
    });
    
    // Calculate data for each month
    for (let i = 0; i < 6; i++) {
      const monthIndex = (currentMonth - i + 12) % 12;
      const monthQuotes = quotesByMonth.get(monthIndex) || [];
      
      // Calculate premium for this month
      this.premiumData[5 - i] = monthQuotes.reduce((sum, quote) => sum + quote.annualPremium, 0);
      
      // Count quotes for this month
      this.quotesData[5 - i] = monthQuotes.length;
      
      // Count bound policies for this month
      this.policiesData[5 - i] = monthQuotes.filter(quote => 
        quote.status.toLowerCase() === 'bound').length;
      
      // Calculate conversion rate for this month
      this.conversionRateData[5 - i] = monthQuotes.length > 0
        ? Math.round((this.policiesData[5 - i] / monthQuotes.length) * 100)
        : 0;
    }
    
    // If no data, use fallback
    if (this.premiumData.every(val => val === 0)) {
      this.premiumData = [18500, 22400, 19800, 26700, 29300, 28300];
    }
    
    if (this.quotesData.every(val => val === 0)) {
      this.quotesData = [10, 12, 8, 15, 13, 10];
    }
    
    if (this.policiesData.every(val => val === 0)) {
      this.policiesData = [6, 7, 5, 9, 8, 7];
    }
    
    if (this.conversionRateData.every(val => val === 0)) {
      this.conversionRateData = [60, 58, 63, 60, 62, 70];
    }
  }
  
  /**
   * Get labels for last 6 months
   */
  getLast6MonthLabels(): string[] {
    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    const labels = [];
    
    const currentDate = new Date();
    const currentMonth = currentDate.getMonth();
    
    for (let i = 5; i >= 0; i--) {
      const monthIndex = (currentMonth - i + 12) % 12;
      labels.push(months[monthIndex]);
    }
    
    return labels;
  }
  
  /**
   * Generate pie chart segments from coverage distribution data
   */
  generatePieSegments(): void {
    this.pieSegments = [];
    let cumulativePercentage = 0;
    
    this.coverageDistribution.forEach(coverage => {
      // Calculate the start and end points for this segment
      const startPercentage = cumulativePercentage;
      cumulativePercentage += coverage.value;
      
      // Create the segment path (stroke-dasharray format: "percentage of stroke to draw, remainder")
      this.pieSegments.push({
        path: `${coverage.value} ${100 - coverage.value} ${startPercentage}`,
        color: coverage.color
      });
    });
  }
  
  /**
   * Refresh reports data
   */
  refreshReports(): void {
    this.loadApiData();
  }
  
  /**
   * Update charts when data changes
   */
  updateCharts(): void {
    // In a real app, this would make an API call with the new date range
    // For demo purposes, we'll simulate updating with random changes
    this.isLoading = true;
    
    setTimeout(() => {
      // Generate some random variations to the existing data
      this.premiumData = this.premiumData.map(value => 
        Math.max(10000, Math.round(value * (0.9 + Math.random() * 0.2)))
      );
      
      this.quotesData = this.quotesData.map(value => 
        Math.max(5, Math.round(value * (0.9 + Math.random() * 0.2)))
      );
      
      this.policiesData = this.policiesData.map(value => 
        Math.max(3, Math.round(value * (0.9 + Math.random() * 0.2)))
      );
      
      this.conversionRateData = this.conversionRateData.map(value => 
        Math.min(95, Math.max(50, Math.round(value * (0.95 + Math.random() * 0.1))))
      );
      
      // Update summary metrics
      this.totalPremium = this.premiumData.reduce((sum, value) => sum + value, 0);
      this.totalQuotes = this.quotesData.reduce((sum, value) => sum + value, 0);
      this.totalBoundPolicies = this.policiesData.reduce((sum, value) => sum + value, 0);
      this.conversionRate = Math.round((this.totalBoundPolicies / this.totalQuotes) * 100);
      
      // Update trends (randomized for demo)
      this.premiumTrend = Math.round((Math.random() * 30) - 10);
      this.quotesTrend = Math.round((Math.random() * 30) - 10);
      this.boundPoliciesTrend = Math.round((Math.random() * 30) - 10);
      this.conversionTrend = Math.round((Math.random() * 20) - 5);
      
      this.isLoading = false;
      
      // Show success message
      this.responseMessage = 'Charts updated successfully';
      this.isSuccess = true;
      
      // Clear message after 3 seconds
      setTimeout(() => {
        this.responseMessage = '';
      }, 3000);
    }, 1000);
  }
  
  /**
   * Toggle sidebar collapsed state
   */
  toggleSidebar(): void {
    this.sidebarCollapsed = !this.sidebarCollapsed;
    localStorage.setItem('sidebarCollapsed', JSON.stringify(this.sidebarCollapsed));
    
    // On mobile, also control the mobile menu state
    if (this.isMobileView) {
      this.mobileMenuOpen = !this.sidebarCollapsed;
    }
  }
  
  /**
   * Toggle mobile menu specifically
   */
  toggleMobileMenu(): void {
    this.mobileMenuOpen = !this.mobileMenuOpen;
    // When opening mobile menu, make sure sidebar isn't collapsed
    if (this.mobileMenuOpen) {
      this.sidebarCollapsed = false;
    }
  }
  
  /**
   * Close mobile menu
   */
  closeMobileMenu(): void {
    this.mobileMenuOpen = false;
  }
  
  /**
   * Toggle dark mode
   */
  toggleDarkMode(): void {
    this.darkModeEnabled = !this.darkModeEnabled;
    document.body.classList.toggle('dark-mode', this.darkModeEnabled);
    localStorage.setItem('darkMode', JSON.stringify(this.darkModeEnabled));
  }
  
  /**
   * Toggle chart type between bar and line
   */
  toggleChartType(chartName: string): void {
    if (this.chartTypes[chartName] === 'bar') {
      this.chartTypes[chartName] = 'line';
    } else {
      this.chartTypes[chartName] = 'bar';
    }
  }
  
  /**
   * Calculate height percentage for bar chart
   */
  getBarHeight(value: number, dataset: number[]): number {
    const max = Math.max(...dataset);
    return max > 0 ? (value / max) * 100 : 0;
  }
  
  /**
   * Get points for SVG polyline in line chart
   */
  getLinePoints(data: number[]): string {
    if (!data || data.length === 0) return '';
    
    // Scale the values to the chart height (0-100)
    const max = Math.max(...data);
    const min = Math.min(...data);
    const range = max - min;
    
    // Generate points for the polyline
    return data.map((value, index) => {
      const x = 25 + index * 50;
      // Invert y coordinate (SVG has 0,0 at top-left)
      // Scale to leave some margin at top and bottom
      const scaledValue = range > 0 
        ? 80 - ((value - min) / range) * 60 
        : 50;
      return `${x},${scaledValue}`;
    }).join(' ');
  }
  
  /**
   * Get client initials for avatar
   */
  getClientInitials(name: string): string {
    if (!name) return '??';
    
    const parts = name.split(' ');
    if (parts.length === 1) return parts[0].charAt(0).toUpperCase();
    
    return (parts[0].charAt(0) + parts[parts.length - 1].charAt(0)).toUpperCase();
  }
  
  /**
   * Show export options modal
   */
  exportReports(): void {
    // Verify authentication
    if (!this.isAuthenticated) {
      this.showNotificationModal(false, 'Authentication Required', 'Please log in to export reports.');
      return;
    }
    
    this.showExportModal = true;
    
    // Set default export options
    this.exportDateRange = 'current';
    this.includeCharts = true;
    this.includeTables = true;
    this.includeMetrics = true;
  }
  
  /**
   * Cancel export dialog
   */
  cancelExport(event?: MouseEvent): void {
    // Only close if event is undefined (direct close) or if target is the modal backdrop
    if (!event || (event.target as HTMLElement).classList.contains('modal-overlay')) {
      this.showExportModal = false;
    }
  }
  
  /**
   * Select export file type
   */
  selectExportOption(option: string): void {
    // Here you can handle selection of export type
    // For demo, we'll just proceed with export
    this.confirmExport();
  }
  
  /**
   * Start export process
   */
  confirmExport(): void {
    this.isLoading = true;
    
    // Simulate export processing
    setTimeout(() => {
      this.isLoading = false;
      this.showExportModal = false;
      
      // Show success notification
      this.showNotificationModal(true, 'Export Successful', 'Your report has been exported successfully.');
    }, 2000);
  }
  
  /**
   * Download specific chart
   */
  downloadChart(chartId: string): void {
    // In a real app, this would generate and download the chart
    // For demo purposes, we'll just show a notification
    this.showNotificationModal(true, 'Chart Downloaded', `The "${chartId}" chart has been downloaded.`);
  }
  
  /**
   * Download table data
   */
  downloadTable(tableId: string): void {
    // In a real app, this would generate and download the table data
    // For demo purposes, we'll just show a notification
    this.showNotificationModal(true, 'Table Downloaded', `The "${tableId}" table data has been downloaded.`);
  }
  
  /**
   * Show notification modal
   */
  showNotificationModal(success: boolean, title: string, message: string): void {
    this.notificationSuccess = success;
    this.notificationTitle = title;
    this.notificationMessage = message;
    this.showNotification = true;
    
    // Auto-close notification after 3 seconds
    setTimeout(() => {
      this.closeNotification();
    }, 3000);
  }
  
  /**
   * Close notification modal
   */
  closeNotification(): void {
    this.showNotification = false;
  }
  
  /**
   * Logout function
   */
  logout(): void {
    // Clear authentication token
    localStorage.removeItem(this.AUTH_TOKEN_KEY);
    
    // Redirect to login page
    this.router.navigate(['/login']);
    
    // Show notification
    this.showNotificationModal(true, 'Logged Out', 'You have been successfully logged out.');
  }
}