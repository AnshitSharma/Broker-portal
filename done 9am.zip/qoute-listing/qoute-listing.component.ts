import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';

interface InsuranceQuote {
  id: number;
  companyName: string;
  companyLogo: string;
  tagline?: string;
  coverageLimit: string;
  premium: number;
  claimSettlement: string;
  rating?: number;
  features: string[];
  maxCoverage: string;
  maxTerm: number;
  highlights?: string[];
}

@Component({
  selector: 'app-quote-listing',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './qoute-listing.component.html',  
  styleUrls: ['./qoute-listing.component.css']   
})
export class QuoteListingComponent implements OnInit {
  quotes: InsuranceQuote[] = [];
  filteredQuotes: InsuranceQuote[] = [];
  
  // Filters
  coverageFilter: string = '';
  sortBy: string = 'premium';
  coverageLimits: string[] = ['1 Cr', '2 Cr', '5 Cr'];
  
  constructor(private router: Router) { }

  ngOnInit(): void {
    this.loadQuotes();
    this.applyFilters();
  }

  loadQuotes(): void {
    // Mock data - in a real application, this would come from a service or API
    this.quotes = [
      {
        id: 1,
        companyName: 'ICICI Prudential',
        companyLogo: 'assets/logos/icici-logo.png',
        tagline: 'iProtect Smart',
        coverageLimit: '1 Cr',
        premium: 598,
        claimSettlement: '99.17%',
        rating: 4.5,
        features: [
          '100% payout on Terminal Illness',
          'Waiver of premium on permanent accidental disability'
        ],
        maxCoverage: '1 Cr',
        maxTerm: 30,
        highlights: ['Highest claims settled worth ₹1,650 Crores in FY22']
      },
      {
        id: 2,
        companyName: 'HDFC Life',
        companyLogo: 'assets/logos/hdfc-logo.png',
        tagline: 'Click 2 Protect Super',
        coverageLimit: '1 Cr',
        premium: 749,
        claimSettlement: '99.5%',
        rating: 4.7,
        features: [
          'Early Payout On Terminal Illness',
          'Extend your policy at Maturity'
        ],
        maxCoverage: '1 Cr',
        maxTerm: 35
      },
      {
        id: 3,
        companyName: 'Axis Max',
        companyLogo: 'assets/logos/axis-logo.png',
        tagline: 'Smart Term Plan Plus',
        coverageLimit: '1 Cr',
        premium: 659,
        claimSettlement: '99.7%',
        rating: 4.3,
        features: [
          'Early payout on Terminal Illness',
          'Lifeline Plan(Option to increase life cover)'
        ],
        maxCoverage: '1 Cr',
        maxTerm: 25,
        highlights: ['Option to delay 12 Months Premium']
      },
      {
        id: 4,
        companyName: 'Tata AIA',
        companyLogo: 'assets/logos/tata-aia-logo.png',
        tagline: 'Sampoorna Raksha Promise',
        coverageLimit: '1 Cr',
        premium: 649,
        claimSettlement: '99.13%',
        rating: 4.6,
        features: [
          'Option to delay 12 months premium',
          'Waiver of premium on Terminal Illness',
          'Early payout on Terminal Illness'
        ],
        maxCoverage: '1 Cr',
        maxTerm: 40
      },
      {
        id: 5,
        companyName: 'Bajaj Allianz',
        companyLogo: 'assets/logos/bajaj-allianz-logo.png',
        tagline: 'Life eTouch II',
        coverageLimit: '1 Cr',
        premium: 487,
        claimSettlement: '99.23%',
        rating: 4.4,
        features: [
          'Premium return option',
          'Additional accidental death benefit',
          'Tax benefits under Section 80C & 10(10D)'
        ],
        maxCoverage: '1 Cr',
        maxTerm: 30
      },
      {
        id: 6,
        companyName: 'SBI Life',
        companyLogo: 'assets/logos/sbi-life-logo.png',
        tagline: 'Smart Shield',
        coverageLimit: '1 Cr',
        premium: 525,
        claimSettlement: '98.78%',
        rating: 4.3,
        features: [
          'Level term cover',
          'Increasing term cover option',
          'Joint life option available'
        ],
        maxCoverage: '1 Cr',
        maxTerm: 35
      },
      {
        id: 7,
        companyName: 'Max Life',
        companyLogo: 'assets/logos/max-life-logo.png',
        tagline: 'Smart Secure Plus',
        coverageLimit: '1 Cr',
        premium: 619,
        claimSettlement: '99.35%',
        rating: 4.5,
        features: [
          'Special exit value',
          'Terminal illness benefit',
          'Additional benefits for women'
        ],
        maxCoverage: '1 Cr',
        maxTerm: 30
      },
      {
        id: 8,
        companyName: 'Kotak Life',
        companyLogo: 'assets/logos/kotak-logo.png',
        tagline: 'e-Preferred Term',
        coverageLimit: '1 Cr',
        premium: 539,
        claimSettlement: '98.93%',
        rating: 4.4,
        features: [
          'Comprehensive life cover',
          'Limited pay option',
          'Enhanced protection with riders'
        ],
        maxCoverage: '1 Cr',
        maxTerm: 25
      }
    ];
  }

  applyFilters(): void {
    let result = [...this.quotes];
    
    // Apply coverage filter
    if (this.coverageFilter) {
      result = result.filter(quote => quote.coverageLimit === this.coverageFilter);
    }
    
    // Apply sort
    if (this.sortBy === 'premium') {
      result.sort((a, b) => a.premium - b.premium);
    } else if (this.sortBy === 'claim') {
      result.sort((a, b) => parseFloat(b.claimSettlement) - parseFloat(a.claimSettlement));
    } else if (this.sortBy === 'rating') {
      result.sort((a, b) => (b.rating || 0) - (a.rating || 0));
    }
    
    this.filteredQuotes = result;
  }

  selectCoverage(coverage: string): void {
    this.coverageFilter = coverage;
    this.applyFilters();
  }

  changeSortBy(sortType: string): void {
    this.sortBy = sortType;
    this.applyFilters();
  }

  resetFilters(): void {
    this.coverageFilter = '';
    this.sortBy = 'premium';
    this.applyFilters();
  }

  viewPlan(quoteId: number): void {
    // Navigate to the detailed quote page
    this.router.navigate(['/quotes', quoteId]);
  }

  calculateSavings(premium: number): string {
    // Mock calculation - in real app this would be more sophisticated
    const savings = Math.round(premium * 0.18); // 18% tax savings
    return savings.toString();
  }

  handleImageError(event: any): void {
    // Fallback for image loading errors
    event.target.src = 'assets/logos/default-logo.png';
  }

  /**
   * Get the width of stars based on rating
   * @param rating Rating value out of 5
   * @returns Width in percentage
   */
  getStarWidth(rating: number): number {
    return (rating / 5) * 100;
  }
}