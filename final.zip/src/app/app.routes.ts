
import { Routes } from '@angular/router';
import { QuoteFormComponent } from './features/quote/quote-form/quote-form.component';
import { QuoteListComponent } from './features/quote/quote-list/quote-list.component';
import { QuoteDetailsComponent } from './features/quote/quote-details/quote-details.component';
import { InsuranceCodeComponent } from './insurance-quote/insurance-quote.component';
import { NextPageComponent } from './next-page/next-page.component';
import { FinalPageComponent } from './final-page/final-page.component';
import { CoverageDetailsComponent } from './coverage-details/coverage-details.component';
import { HomeComponent } from './home/home.component';
import { PoliciesComponent } from './policies/policies.component';
import { ClientsComponent } from './clients/clients.component';
import { QuoteSummaryComponent } from './quote-summary/quote-summary.component';
import { QuoteListingComponent } from '../../qoute-listing/qoute-listing.component';
import { ContactUsComponent } from './contact-us/contact-us.component';
import { BrokerDashboardComponent } from './broker-dashboard/broker-dashboard.component';
import { LoginComponent } from './auth/login/login.component';
import { RegisterComponent } from './auth/register/register.component';
import { AuthGuard } from './guards/auth.guard';
import { ReportDashboardComponent } from './report-dashboard/report-dashboard.component';
import { QuotePreviewComponent } from './qoutepreview/qoutepreview.component';
import { AboutUsComponent } from './about-us/about-us.component';




export const routes: Routes = [
  { path: 'quotes-list', component: QuoteListComponent },
  { path: 'quote-form/new', component: QuoteFormComponent },
  { path: 'quote-details/:id', component: QuoteDetailsComponent },
  { path: 'new-quote', component: InsuranceCodeComponent,  },
  { path: 'next-page', component: NextPageComponent },
  { path: 'final-page', component: FinalPageComponent  },
  { path: 'coverage-details', component: CoverageDetailsComponent, },
  { path: 'quote-summary', component: QuoteSummaryComponent },
  { path: 'quote-preview', component: QuotePreviewComponent },

  // { path: 'about-us', component: AboutUsComponent },

  { path: 'home', component: HomeComponent },
  { path: 'clients', component: ClientsComponent },
  { path: 'policies', component: PoliciesComponent },
  { path: 'dashboard', component: BrokerDashboardComponent },
  { path: 'quotes', component: BrokerDashboardComponent },
  { path: 'policies', component: BrokerDashboardComponent },
  { path: 'clients', component: BrokerDashboardComponent },
  { path: 'reports', component: BrokerDashboardComponent },
  { path: 'commission', component: BrokerDashboardComponent },
  { path: 'profile', component: BrokerDashboardComponent },
  { path: 'settings', component: BrokerDashboardComponent },
  { path: 'report-dashboard', component: ReportDashboardComponent },

  { path: 'quote-listing', component: QuoteListingComponent, canActivate: [AuthGuard] },
  { path: 'contact-us', component: ContactUsComponent },
  { path: 'login', component: LoginComponent },
  { path: 'register', component: RegisterComponent },
  { path: '', redirectTo: '/home', pathMatch: 'full' },
  { path: '**', redirectTo: '/home' }
];