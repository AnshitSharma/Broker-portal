import { Component, OnInit, HostListener } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { Router, NavigationEnd } from '@angular/router';
import { filter } from 'rxjs/operators';

interface PolicyDocument {
  id: string;
  policyId: string;
  name: string;
  date: Date;
  type: 'certificate' | 'policy' | 'endorsement' | 'invoice';
  url: string;
}

interface Policy {
  id: string;
  originalQuoteId: string;
  clientName: string;
  businessName: string;
  effectiveDate: Date;
  expirationDate: Date;
  premium: number;
  coverageType: string;
  status: 'active' | 'expired' | 'cancelled' | 'pending-renewal';
}

interface ClientDetails {
  email: string;
  phone: string;
}

@Component({
  selector: 'app-policies',
  standalone: true,
  imports: [CommonModule, RouterModule, FormsModule],
  templateUrl: './policies.component.html',
  styleUrls: ['./policies.component.css']
})
export class PoliciesComponent implements OnInit {
  // Expose Math object to be used in template
  Math = Math;
  
  // UI State
  darkModeEnabled: boolean = false;
  sidebarCollapsed: boolean = false;
  mobileMenuOpen: boolean = false;
  currentRoute: string = '/policies';
  selectedPolicy: Policy | null = null;
  
  // Screen size detection
  isMobileView: boolean = false;
  
  // Pagination
  currentPage: number = 1;
  itemsPerPage: number = 10;
  totalPages: number = 1;
  
  // Broker details
  brokerName: string = 'John Broker';
  brokerRole: string = 'Senior Insurance Broker';
  
  // Filter and search states
  policySearchQuery: string = '';
  policyCoverageFilter: string = 'all';
  startDate: string = '';
  endDate: string = '';
  
  // User preferences
  notificationsEnabled: boolean = true;
  
  // Policy stats
  upcomingRenewals: number = 4;
  totalPremium: number = 0;
  uniqueClients: number = 0;
  
  // Coverage types for filter dropdown
  coverageTypes: string[] = [
    'Bodily Injury and Property Damage',
    'Products and Completed Operations',
    'Advertising Injury',
    'Reputational Harm',
    'Independent Contractors'
  ];
  
  // Generated list of bound policies
  boundPolicies: Policy[] = [
    { 
      id: 'POL-2025-01254', 
      originalQuoteId: 'Q-39465',
      clientName: 'Michael Chen', 
      businessName: 'Chen Technology Solutions', 
      effectiveDate: new Date(2025, 3, 10), 
      expirationDate: new Date(2026, 3, 10),
      premium: 5100, 
      coverageType: 'Advertising Injury',
      status: 'active'
    },
    { 
      id: 'POL-2025-01247', 
      originalQuoteId: 'Q-39439',
      clientName: 'Emily Martinez', 
      businessName: 'Martinez Floral Design', 
      effectiveDate: new Date(2025, 3, 5), 
      expirationDate: new Date(2026, 3, 5),
      premium: 1875, 
      coverageType: 'Products and Completed Operations',
      status: 'active'
    },
    { 
      id: 'POL-2025-01232', 
      originalQuoteId: 'Q-39435',
      clientName: 'Mark Anderson', 
      businessName: 'Anderson Landscaping', 
      effectiveDate: new Date(2025, 2, 28), 
      expirationDate: new Date(2026, 2, 28),
      premium: 3400, 
      coverageType: 'Bodily Injury and Property Damage',
      status: 'active'
    },
    { 
      id: 'POL-2025-01228', 
      originalQuoteId: 'Q-38976',
      clientName: 'Laura Peterson', 
      businessName: 'Peterson Consulting Group', 
      effectiveDate: new Date(2025, 2, 15), 
      expirationDate: new Date(2026, 2, 15),
      premium: 4250, 
      coverageType: 'Professional Liability',
      status: 'active'
    },
    { 
      id: 'POL-2025-01211', 
      originalQuoteId: 'Q-38942',
      clientName: 'Robert Johnson', 
      businessName: 'Johnson Consulting LLC', 
      effectiveDate: new Date(2025, 2, 1), 
      expirationDate: new Date(2026, 2, 1),
      premium: 6750, 
      coverageType: 'Bodily Injury and Property Damage',
      status: 'active'
    },
    { 
      id: 'POL-2025-01187', 
      originalQuoteId: 'Q-38836',
      clientName: 'James Wilson', 
      businessName: 'Wilson Plumbing Services', 
      effectiveDate: new Date(2025, 1, 20), 
      expirationDate: new Date(2026, 1, 20),
      premium: 3850, 
      coverageType: 'Independent Contractors',
      status: 'active'
    },
    { 
      id: 'POL-2025-01165', 
      originalQuoteId: 'Q-38791',
      clientName: 'Jennifer Lee', 
      businessName: 'Lee Medical Supplies', 
      effectiveDate: new Date(2025, 1, 10), 
      expirationDate: new Date(2026, 1, 10),
      premium: 5200, 
      coverageType: 'Products and Completed Operations',
      status: 'active'
    },
    { 
      id: 'POL-2025-01152', 
      originalQuoteId: 'Q-38754',
      clientName: 'David Smith', 
      businessName: 'Smith Construction Inc.', 
      effectiveDate: new Date(2025, 1, 5), 
      expirationDate: new Date(2026, 1, 5),
      premium: 9200, 
      coverageType: 'Independent Contractors',
      status: 'active'
    },
    { 
      id: 'POL-2025-01138', 
      originalQuoteId: 'Q-38699',
      clientName: 'Sarah Williams', 
      businessName: 'Artisan Bakery', 
      effectiveDate: new Date(2025, 0, 25), 
      expirationDate: new Date(2026, 0, 25),
      premium: 2950, 
      coverageType: 'Products and Completed Operations',
      status: 'active'
    },
    { 
      id: 'POL-2025-01107', 
      originalQuoteId: 'Q-38623',
      clientName: 'Michael Chen', 
      businessName: 'Chen Technology Solutions', 
      effectiveDate: new Date(2025, 0, 15), 
      expirationDate: new Date(2026, 0, 15),
      premium: 3500, 
      coverageType: 'Reputational Harm',
      status: 'active'
    },
    { 
      id: 'POL-2024-00987', 
      originalQuoteId: 'Q-38489',
      clientName: 'Alicia Rodriguez', 
      businessName: 'AR Interior Design', 
      effectiveDate: new Date(2024, 11, 10), 
      expirationDate: new Date(2025, 11, 10),
      premium: 2100, 
      coverageType: 'Professional Liability',
      status: 'active'
    },
    { 
      id: 'POL-2024-00963', 
      originalQuoteId: 'Q-38452',
      clientName: 'William Brown', 
      businessName: 'Brown & Associates', 
      effectiveDate: new Date(2024, 11, 5), 
      expirationDate: new Date(2025, 11, 5),
      premium: 4800, 
      coverageType: 'Advertising Injury',
      status: 'active'
    }
  ];
  
  // Policy documents
  policyDocuments: PolicyDocument[] = [
    {
      id: 'DOC-5721',
      policyId: 'POL-2025-01254',
      name: 'Policy Declaration',
      date: new Date(2025, 3, 10),
      type: 'policy',
      url: '/documents/POL-2025-01254/declaration.pdf'
    },
    {
      id: 'DOC-5722',
      policyId: 'POL-2025-01254',
      name: 'Certificate of Insurance',
      date: new Date(2025, 3, 10),
      type: 'certificate',
      url: '/documents/POL-2025-01254/certificate.pdf'
    },
    {
      id: 'DOC-5723',
      policyId: 'POL-2025-01254',
      name: 'Premium Invoice',
      date: new Date(2025, 3, 10),
      type: 'invoice',
      url: '/documents/POL-2025-01254/invoice.pdf'
    },
    {
      id: 'DOC-5698',
      policyId: 'POL-2025-01247',
      name: 'Policy Declaration',
      date: new Date(2025, 3, 5),
      type: 'policy',
      url: '/documents/POL-2025-01247/declaration.pdf'
    },
    {
      id: 'DOC-5699',
      policyId: 'POL-2025-01247',
      name: 'Certificate of Insurance',
      date: new Date(2025, 3, 5),
      type: 'certificate',
      url: '/documents/POL-2025-01247/certificate.pdf'
    }
  ];
  
  // Client details mapping for contact information
  clientDetails: {[key: string]: ClientDetails} = {
    'Robert Johnson': { email: 'robert.johnson@johnsonconsulting.com', phone: '(555) 123-4567' },
    'Sarah Williams': { email: 'sarah@artisanbakery.com', phone: '(555) 234-5678' },
    'Michael Chen': { email: 'michael@chentechsolutions.com', phone: '(555) 345-6789' },
    'Alicia Rodriguez': { email: 'alicia@arinteriordesign.com', phone: '(555) 456-7890' },
    'David Smith': { email: 'dsmith@smithconstruction.com', phone: '(555) 567-8901' },
    'Jennifer Lee': { email: 'jennifer@leemedicalsupplies.com', phone: '(555) 678-9012' },
    'William Brown': { email: 'william@brownassociates.com', phone: '(555) 789-0123' },
    'Emily Martinez': { email: 'emily@martinezfloral.com', phone: '(555) 890-1234' },
    'James Wilson': { email: 'james@wilsonplumbing.com', phone: '(555) 901-2345' },
    'Laura Peterson': { email: 'laura@petersonconsulting.com', phone: '(555) 012-3456' }
  };
  
  // Coverage descriptions
  coverageDescriptions: {[key: string]: string} = {
    'Bodily Injury and Property Damage': 'Covers claims for physical injuries to others and damage to their property resulting from your business operations.',
    'Products and Completed Operations': 'Protects against liability arising from products you sell or services you provide after the product is sold or the work is completed.',
    'Advertising Injury': 'Covers liability for damages arising from your advertising, such as copyright infringement, slander, libel, or invasion of privacy.',
    'Reputational Harm': 'Provides coverage for claims alleging damage to someone\'s reputation, such as defamation, slander, or libel.',
    'Independent Contractors': 'Extends liability protection to cover independent contractors working on behalf of your business.',
    'Professional Liability': 'Covers claims arising from errors and omissions in professional services, advice, or recommendations provided by your business.'
  };

  // For displaying filtered policies
  filteredPolicies: Policy[] = [];

  constructor(private router: Router) {
    // Subscribe to router events to track current route
    this.router.events
      .pipe(filter(event => event instanceof NavigationEnd))
      .subscribe((event: any) => {
        this.currentRoute = event.url;
        // Reset to first page when changing routes
        this.currentPage = 1;
        // Close mobile menu when navigating
        this.mobileMenuOpen = false;
      });
      
    // Check initial screen size
    this.checkScreenSize();
  }

  // Host listener to detect screen size changes
  @HostListener('window:resize', ['$event'])
  onResize() {
    this.checkScreenSize();
  }

  // Check if the screen is mobile size
  checkScreenSize() {
    this.isMobileView = window.innerWidth < 992;
    // Auto-collapse sidebar on mobile
    if (this.isMobileView && !this.mobileMenuOpen) {
      this.sidebarCollapsed = true;
    }
  }

  ngOnInit(): void {
    // Check if dark mode is saved in localStorage
    const savedDarkMode = localStorage.getItem('darkMode');
    if (savedDarkMode) {
      this.darkModeEnabled = JSON.parse(savedDarkMode);
      document.body.classList.toggle('dark-mode', this.darkModeEnabled);
    }
    
    // Check if sidebar state is saved in localStorage
    const savedSidebarState = localStorage.getItem('sidebarCollapsed');
    if (savedSidebarState) {
      this.sidebarCollapsed = JSON.parse(savedSidebarState);
    }
    
    // Initialize current route
    this.currentRoute = this.router.url;
    
    // Calculate policy stats
    this.calculatePolicyStats();
    
    // Initialize filtered policies
    this.filterPolicies();
  }

  // Calculate policy statistics
  calculatePolicyStats(): void {
    // Calculate total premium
    this.totalPremium = this.boundPolicies.reduce((total, policy) => total + policy.premium, 0);
    
    // Calculate unique clients
    const uniqueClientNames = new Set(this.boundPolicies.map(policy => policy.clientName));
    this.uniqueClients = uniqueClientNames.size;
  }

  // Toggle sidebar collapsed state
  toggleSidebar(): void {
    this.sidebarCollapsed = !this.sidebarCollapsed;
    localStorage.setItem('sidebarCollapsed', JSON.stringify(this.sidebarCollapsed));
    
    // On mobile, also control the mobile menu state
    if (this.isMobileView) {
      this.mobileMenuOpen = !this.sidebarCollapsed;
    }
  }

  // Toggle mobile menu specifically
  toggleMobileMenu(): void {
    this.mobileMenuOpen = !this.mobileMenuOpen;
    // When opening mobile menu, make sure sidebar isn't collapsed
    if (this.mobileMenuOpen) {
      this.sidebarCollapsed = false;
    }
  }

  // Close mobile menu
  closeMobileMenu(): void {
    this.mobileMenuOpen = false;
  }

  // Toggle dark mode
  toggleDarkMode(): void {
    this.darkModeEnabled = !this.darkModeEnabled;
    document.body.classList.toggle('dark-mode', this.darkModeEnabled);
    localStorage.setItem('darkMode', JSON.stringify(this.darkModeEnabled));
  }

  // Toggle notifications
  toggleNotifications(): void {
    this.notificationsEnabled = !this.notificationsEnabled;
    // In a real app, you would update user preferences in backend
  }

  // Create a new quote
  createNewQuote(): void {
    this.router.navigate(['/insurance']);
    // Close mobile menu when navigating
    this.mobileMenuOpen = false;
  }

  // Filter policies based on search criteria and filters
  filterPolicies(): void {
    let filtered = [...this.boundPolicies];
    
    // Apply coverage type filter
    if (this.policyCoverageFilter !== 'all') {
      filtered = filtered.filter(policy => policy.coverageType === this.policyCoverageFilter);
    }
    
    // Apply search filter
    if (this.policySearchQuery.trim() !== '') {
      const search = this.policySearchQuery.toLowerCase();
      filtered = filtered.filter(policy => 
        policy.id.toLowerCase().includes(search) ||
        policy.clientName.toLowerCase().includes(search) ||
        policy.businessName.toLowerCase().includes(search) ||
        policy.coverageType.toLowerCase().includes(search)
      );
    }
    
    // Apply date filters if set
    if (this.startDate) {
      const start = new Date(this.startDate);
      filtered = filtered.filter(policy => new Date(policy.effectiveDate) >= start);
    }
    
    if (this.endDate) {
      const end = new Date(this.endDate);
      // Set to end of day
      end.setHours(23, 59, 59, 999);
      filtered = filtered.filter(policy => new Date(policy.effectiveDate) <= end);
    }
    
    // Update filtered policies
    this.filteredPolicies = filtered;
    
    // Update total pages
    this.totalPages = Math.ceil(this.filteredPolicies.length / this.itemsPerPage);
    
    // Reset to first page if current page is now invalid
    if (this.currentPage > this.totalPages && this.totalPages > 0) {
      this.currentPage = 1;
    }
  }

  // Reset date filter
  resetDateFilter(): void {
    this.startDate = '';
    this.endDate = '';
    this.filterPolicies();
  }

  // Get paginated policies for current page
  getPaginatedPolicies(): Policy[] {
    // Apply pagination
    const startIndex = (this.currentPage - 1) * this.itemsPerPage;
    const endIndex = startIndex + this.itemsPerPage;
    return this.filteredPolicies.slice(startIndex, endIndex);
  }

  // Get page numbers array for pagination display
  getPageNumbers(): number[] {
    const pages: number[] = [];
    const maxDisplayPages = 5;
    
    if (this.totalPages <= maxDisplayPages) {
      // Display all pages if total pages is less than max display
      for (let i = 1; i <= this.totalPages; i++) {
        pages.push(i);
      }
    } else {
      // Display a subset of pages with current page in middle if possible
      const halfMax = Math.floor(maxDisplayPages / 2);
      
      let startPage = Math.max(this.currentPage - halfMax, 1);
      let endPage = startPage + maxDisplayPages - 1;
      
      if (endPage > this.totalPages) {
        endPage = this.totalPages;
        startPage = Math.max(endPage - maxDisplayPages + 1, 1);
      }
      
      for (let i = startPage; i <= endPage; i++) {
        pages.push(i);
      }
    }
    
    return pages;
  }

  // Change page in pagination
  changePage(page: number): void {
    if (page < 1 || page > this.totalPages) {
      return;
    }
    this.currentPage = page;
  }

  // View policy details
  viewPolicyDetails(policy: Policy): void {
    this.selectedPolicy = policy;
  }

  // Close policy details modal
  closePolicyDetails(): void {
    this.selectedPolicy = null;
  }

  // Download policy document
  downloadPolicy(policy: Policy): void {
    // In a real app, this would trigger a document download
    alert(`Downloading policy document for ${policy.id} - ${policy.clientName}`);
    
    // Simulate download by creating a fake download link
    const link = document.createElement('a');
    link.href = `/api/policies/${policy.id}/download`;
    link.download = `${policy.id}_${policy.businessName.replace(/\s+/g, '_')}.pdf`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }

  // Download document 
  downloadDocument(policyDocument: PolicyDocument): void {
    // In a real app, this would download the specific document
    alert(`Downloading ${policyDocument.name} for policy ${policyDocument.policyId}`);

    
    // Simulate download
    const link = document.createElement('a');
    link.href = policyDocument.url;
    link.download = `${policyDocument.policyId}_${policyDocument.name.replace(/\s+/g, '_')}.pdf`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }

  // Generate certificate for policy
  generateCertificate(policy: Policy): void {
    // In a real app, this would open a form or generate a certificate
    alert(`Generating certificate for policy ${policy.id} for ${policy.clientName}`);
  }

  // Renew policy
  renewPolicy(policy: Policy): void {
    // In a real app, this would start the renewal process
    alert(`Starting renewal process for policy ${policy.id} for ${policy.clientName}`);
  }

  // Get client email
  getClientEmail(clientName: string): string {
    return this.clientDetails[clientName]?.email || 'No email available';
  }

  // Get client phone
  getClientPhone(clientName: string): string {
    return this.clientDetails[clientName]?.phone || 'No phone available';
  }

  // Get policy documents
  getPolicyDocuments(policyId: string): PolicyDocument[] {
    return this.policyDocuments.filter(doc => doc.policyId === policyId);
  }

  // Get coverage description
  getCoverageDescription(coverageType: string): string {
    return this.coverageDescriptions[coverageType] || 'No description available';
  }
}