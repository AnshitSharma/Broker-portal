import { Component, OnInit, HostListener } from '@angular/core';
import { Router, RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-navbar',
  standalone: true,
  imports: [RouterModule, CommonModule],
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit {
  isLoggedIn: boolean = false;
  isScrolled: boolean = false;
  mobileMenuOpen: boolean = false;
  
  constructor(private router: Router) {}

  ngOnInit(): void {
    // Check if user is already logged in from localStorage
    const savedLoginState = localStorage.getItem('isLoggedIn');
    if (savedLoginState) {
      this.isLoggedIn = JSON.parse(savedLoginState);
    }
  }

  // Add scroll listener for navbar effects
  @HostListener('window:scroll')
  onWindowScroll(): void {
    const scrollPosition = window.pageYOffset || document.documentElement.scrollTop || document.body.scrollTop || 0;
    this.isScrolled = scrollPosition > 50;
  }

  // Toggle auth state
  toggleAuth(): void {
    this.isLoggedIn = !this.isLoggedIn;
    
    // Save login state to localStorage
    localStorage.setItem('isLoggedIn', JSON.stringify(this.isLoggedIn));
    
    if (!this.isLoggedIn) {
      this.router.navigate(['/home']);
    }
  }
  
  // Toggle mobile menu visibility
  toggleMobileMenu(): void {
    this.mobileMenuOpen = !this.mobileMenuOpen;
    
    // Prevent body scrolling when menu is open
    if (this.mobileMenuOpen) {
      this.disableBodyScroll();
    } else {
      this.enableBodyScroll();
    }
  }
  
  // Close mobile menu
  closeMobileMenu(): void {
    this.mobileMenuOpen = false;
    this.enableBodyScroll();
  }

  // Helper method to disable body scrolling
  private disableBodyScroll(): void {
    document.body.style.overflow = 'hidden';
  }

  // Helper method to enable body scrolling
  private enableBodyScroll(): void {
    document.body.style.overflow = '';
  }
}