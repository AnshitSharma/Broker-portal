import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpClient, HttpClientModule, HttpHeaders } from '@angular/common/http';
import { catchError, finalize, of } from 'rxjs';

interface Coverage {
  title: string;
  description: string;
  id: number;
  image?: string;
  selected: boolean;
}

interface BusinessCategory {
  code: string;
  name: string;
}

// Define interfaces for storage data
interface BasicInfoData {
  businessStatus?: { id: string; label: string; selected: boolean }[];
  businessStructure?: string;
  ownerFirstName?: string;
  ownerLastName?: string;
  businessName?: string;
  ownerFullName?: string;
  emailAddress?: string;
  phoneNumber?: string;
  [key: string]: any;
}

interface LocationInfoData {
  businessLocation?: string;
  businessStreetAddress?: string;
  zipCode?: string;
  ownOrRent?: string;
  hasOtherLocations?: string;
  [key: string]: any;
}

interface BusinessDetailsData {
  businessYear?: string;
  employeeCount?: number;
  executiveOfficers?: number;
  businessDescription?: string;
  isNonProfit?: string;
  additionalServices?: string;
  hasLiabilityClaims?: string;
  claimsCount?: number;
  claimsType?: string;
  hasHazardousOperations?: string;
  businessCategory?: string;
  annualRevenue?: number;
  coverageLimit?: string | number;
  [key: string]: any;
}

@Component({
  selector: 'app-quote-summary',
  standalone: true,
  templateUrl: './quote-summary.component.html',
  styleUrls: ['./quote-summary.component.css'],
  imports: [CommonModule, FormsModule, HttpClientModule]
})
export class QuoteSummaryComponent implements OnInit {
  // Quote information
  quoteId: string = '';
  quoteDate: Date = new Date();
  
  // API and UI state
  isSubmitting: boolean = false;
  apiError: boolean = false;
  errorMessage: string = '';
  showSuccessModal: boolean = false;
  
  // Authentication state
  isAuthenticated: boolean = false;
  
  // Selected coverages from previous step
  selectedCoverages: Coverage[] = [];
  
  // Business information from step 1 and 3
  businessInfo: any = {
    ownerFirstName: '',
    ownerLastName: '',
    ownerName: '',
    businessName: '',
    businessStructure: '',
    businessYear: '',
    employeeCount: 0,
    executiveOfficers: 0,
    businessDescription: '',
    isNonProfit: 'No',
    additionalServices: 'No',
    hasLiabilityClaims: 'No',
    claimsCount: 0,
    claimsType: '',
    hasHazardousOperations: 'No',
    businessCategory: '',
    annualRevenue: 0,
    coverageLimit: 1000000,
    emailAddress: '',
    phoneNumber: ''
  };
  
  // Location information from step 2
  locationInfo: any = {
    businessLocation: '',
    businessStreetAddress: '',
    zipCode: '',
    ownOrRent: '',
    hasOtherLocations: 'No'
  };
  
  // Business categories for lookup
  businessCategories: BusinessCategory[] = [
    { code: '2382', name: 'Building Equipment Contractors' },
    { code: '2383', name: 'Building Finishing Contractors' },
    { code: '4231', name: 'Motor Vehicle and Parts Dealers (Wholesale)' },
    { code: '4232', name: 'Furniture and Home Furnishings Wholesalers' },
    { code: '4243', name: 'Apparel and Piece Goods Merchants (Wholesale)' },
    { code: '4451', name: 'Grocery Stores' },
    { code: '4452', name: 'Specialty Food Stores' },
    { code: '4461', name: 'Health and Personal Care Stores' },
    { code: '4481', name: 'Clothing Stores' },
    { code: '4511', name: 'Sporting Goods, Hobby, and Musical Instrument Stores' },
    { code: '4529', name: 'Other General Merchandise Stores' },
    { code: '5121', name: 'Motion Picture and Video Industries' },
    { code: '5312', name: 'Offices of Real Estate Agents and Brokers' },
    { code: '5414', name: 'Specialized Design Services' },
    { code: '5416', name: 'Management, Scientific, and Technical Consulting' },
    { code: '5419', name: 'Other Professional, Scientific, and Technical Services' },
    { code: '5617', name: 'Services to Buildings and Dwellings' },
    { code: '7223', name: 'Special Food Services (Catering, Food Trucks)' },
    { code: '7225', name: 'Restaurants and Other Eating Places' },
    { code: '8121', name: 'Personal Care Services (Salons, Barber Shops)' },
    { code: '8129', name: 'Other Personal Services' }
  ];

  // Mapping for business structure names to IDs
  businessStructureMapping: { [key: string]: number } = {
    'Sole Proprietorship': 1,
    'Limited Liability Company (LLC)': 2,
    'Limited Liability Corporation (LLC)': 2,
    'S-Corporation': 3,
    'C-Corporation': 4,
    'Partnership': 5,
    'Non-Profit Organization': 6,
    'Other': 7
  };

  // Mapping for industry class names to IDs
  industryClassMapping: { [key: string]: number } = {
    'Consulting Services': 1,
    'Retail': 2,
    'Construction': 3,
    'Food and Beverage': 4,
    'Cleaning Services': 5,
    'E-commerce': 6,
    'Healthcare Services': 7,
    'Personal Care Services': 8,
    'Fitness and Wellness': 9,
    'Professional Services': 10,
    'Manufacturing': 11,
    'Daycare/Education': 12,
    'Event Planning': 13,
    'Technology Services': 14,
    'Transportation': 15,
    'Real Estate Services': 16,
    'Auto Repair': 17,
    'Non-profit Organizations': 18,
    'Specialty Food Stores': 5, // Using appropriate match
    'Building Equipment Contractors': 3, // Using Construction as a match
    'Management, Scientific, and Technical Consulting': 1 // Using Consulting Services as a match
  };

  // Mapping for location types
  locationTypeMapping: { [key: string]: number } = {
    'Commercial': 1,
    'Commercial/Retail': 1,
    'Retail': 2,
    'Office': 3,
    'Industrial': 4,
    'Industrial Facility': 4,
    'Personal Residence': 5,
    'Shared Office/Co-working Space': 3,
    'Other': 1
  };

  // Mapping for ownership types
  ownershipTypeMapping: { [key: string]: number } = {
    'Own': 1,
    'Rent': 2,
    'Lease': 2,
    'Other': 1
  };
  
  // Storage key constants
  private readonly STORAGE_KEY = 'insurance_quote_data';
  private readonly BASIC_INFO_KEY = 'quoteBasicInfo';
  private readonly LOCATION_INFO_KEY = 'quoteLocationInfo';
  private readonly AUTH_TOKEN_KEY = 'auth_token';
  
  // API URL for submitting quotes
  private readonly API_URL = 'https://localhost:7124/api/Quote/insurance-quotes';
  
  constructor(private router: Router, private http: HttpClient) {}

  ngOnInit(): void {
    this.loadQuoteData();
    this.checkAuthentication();
  }

  /**
   * Check if user is authenticated
   */
  checkAuthentication(): void {
    const token = localStorage.getItem(this.AUTH_TOKEN_KEY);
    this.isAuthenticated = !!token;
    
    // If not authenticated, redirect to login
    if (!this.isAuthenticated) {
      // Store current location to redirect back after login
      sessionStorage.setItem('redirectUrl', '/quote-summary');
      // Uncomment the following line to enable automatic redirect to login
      // this.router.navigate(['/login']);
    }
  }

  /**
   * Load data from previous steps
   */
  loadQuoteData(): void {
    // Generate a random quote ID
    this.quoteId = 'BIZ-' + Math.floor(100000 + Math.random() * 900000);
    
    // Load coverage data from session storage
    const coverageData = sessionStorage.getItem('selectedCoverages');
    if (coverageData) {
      this.selectedCoverages = JSON.parse(coverageData);
      
      // Add ids to coverages if they don't have them
      this.selectedCoverages = this.selectedCoverages.map((coverage, index) => {
        if (!coverage.id) {
          // Map coverage types to expected ids based on their titles
          let id;
          if (coverage.title.includes('Bodily Injury')) {
            id = 1;
          } else if (coverage.title.includes('Products and Completed Operations')) {
            id = 2;
          } else if (coverage.title.includes('Advertising')) {
            id = 3;
          } else if (coverage.title.includes('Legal Defense')) {
            id = 4;
          } else if (coverage.title.includes('Property Damage to Rental')) {
            id = 5;
          } else {
            // Fallback to index + 1 if no specific mapping
            id = index + 1;
          }
          return {...coverage, id};
        }
        return coverage;
      });
    }
    
    // Load basic info data from session storage (step 1)
    let basicInfo: BasicInfoData = {};
    const basicInfoData = sessionStorage.getItem(this.BASIC_INFO_KEY);
    if (basicInfoData) {
      basicInfo = JSON.parse(basicInfoData);
      console.log('Loaded basic info from storage:', basicInfo);
    }
    
    // Load location info from session storage (step 2)
    let locationInfo: LocationInfoData = {};
    const locationInfoData = sessionStorage.getItem(this.LOCATION_INFO_KEY);
    if (locationInfoData) {
      locationInfo = JSON.parse(locationInfoData);
      console.log('Loaded location info from storage:', locationInfo);
    }
    
    // Load business details from session storage (step 3)
    let businessDetails: BusinessDetailsData = {};
    const businessDetailsData = sessionStorage.getItem(this.STORAGE_KEY);
    if (businessDetailsData) {
      businessDetails = JSON.parse(businessDetailsData);
      console.log('Loaded business details from storage:', businessDetails);
    }
    
    // Process business info from all storage sources or use fallback data
    this.businessInfo = {
      // From basic info (step 1)
      ownerFirstName: basicInfo.ownerFirstName || 'John',
      ownerLastName: basicInfo.ownerLastName || 'Smith',
      ownerName: `${basicInfo.ownerFirstName || 'John'} ${basicInfo.ownerLastName || 'Smith'}`,
      businessName: basicInfo.businessName || 'Smith Consulting LLC',
      businessStructure: basicInfo.businessStructure || 'Limited Liability Corporation (LLC)',
      emailAddress: basicInfo.emailAddress || 'contact@example.com',
      phoneNumber: basicInfo.phoneNumber || '(555) 123-4567',
      
      // From business details (step 3)
      businessYear: businessDetails.businessYear || '2018',
      employeeCount: businessDetails.employeeCount !== undefined ? businessDetails.employeeCount : 5,
      executiveOfficers: businessDetails.executiveOfficers !== undefined ? businessDetails.executiveOfficers : 2,
      businessDescription: businessDetails.businessDescription || 'IT Consulting Services',
      isNonProfit: businessDetails.isNonProfit || 'No',
      additionalServices: businessDetails.additionalServices || 'Yes',
      hasLiabilityClaims: businessDetails.hasLiabilityClaims || 'No',
      claimsCount: businessDetails.claimsCount || 0,
      claimsType: businessDetails.claimsType || 'N/A',
      hasHazardousOperations: businessDetails.hasHazardousOperations || 'No',
      businessCategory: this.getBusinessCategoryName(businessDetails.businessCategory) || 'Management, Scientific, and Technical Consulting',
      businessCategoryId: businessDetails.businessCategory,
      annualRevenue: businessDetails.annualRevenue || 250000,
      coverageLimit: businessDetails.coverageLimit || 1000000
    };
    
    // Process location info from session storage (step 2)
    this.locationInfo = {
      businessLocation: locationInfo.businessLocation || 'Commercial Building',
      businessStreetAddress: locationInfo.businessStreetAddress || '123 Business Ave, Suite 101',
      zipCode: locationInfo.zipCode || '10001',
      ownOrRent: locationInfo.ownOrRent || 'Rent',
      hasOtherLocations: locationInfo.hasOtherLocations || 'No'
    };
    
    console.log('Processed business info:', this.businessInfo);
    console.log('Processed location info:', this.locationInfo);
  }

  /**
   * Get business category name from code
   */
  getBusinessCategoryName(code: string | undefined): string {
    if (!code) return '';
    
    const category = this.businessCategories.find(cat => cat.code === code);
    return category ? category.name : '';
  }

  /**
   * Get number of years in business based on business year
   */
  getYearsInBusiness(): number {
    const currentYear = new Date().getFullYear();
    const establishedYear = parseInt(this.businessInfo.businessYear) || currentYear;
    return Math.max(0, currentYear - establishedYear);
  }

  /**
   * Navigate back to the coverage selection page
   */
  previousStep(): void {
    this.router.navigate(['/coverage-details']);
  }

  /**
   * Get auth token for API requests
   */
  getAuthHeaders(): HttpHeaders {
    const token = localStorage.getItem(this.AUTH_TOKEN_KEY);
    return new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token || ''}`
    });
  }

  /**
   * Get business structure ID from name
   */
  getBusinessStructureId(name: string): number {
    return this.businessStructureMapping[name] || 2; // Default to LLC if not found
  }

  /**
   * Get industry class ID from name
   */
  getIndustryClassId(name: string): number {
    return this.industryClassMapping[name] || 1; // Default to Consulting Services if not found
  }

  /**
   * Get location type ID from name
   */
  getLocationTypeId(name: string): number {
    return this.locationTypeMapping[name] || 1; // Default to Commercial if not found
  }

  /**
   * Get ownership type ID from name
   */
  getOwnershipTypeId(name: string): number {
    return this.ownershipTypeMapping[name] || 1; // Default to Own if not found
  }

  /**
   * Prepare the quote data for API submission according to the API schema
   */
  prepareQuoteData(): any {
    // Get the coverage IDs from the selected coverages
    const selectedCoverageIds = this.selectedCoverages
      .filter(coverage => coverage.selected)
      .map(coverage => coverage.id);
    
    // Convert Yes/No string values to boolean
    const hasAdditionalServices = this.businessInfo.additionalServices === 'Yes';
    const hasClaimsHistory = this.businessInfo.hasLiabilityClaims === 'Yes';
    const isHazardous = this.businessInfo.hasHazardousOperations === 'Yes';
    const isNonProfit = this.businessInfo.isNonProfit === 'Yes';
    const hasMultipleLocations = this.locationInfo.hasOtherLocations === 'Yes';
    
    // Convert coverage limit to number if it's a string
    const coverageLimit = typeof this.businessInfo.coverageLimit === 'string' 
      ? parseInt(this.businessInfo.coverageLimit)
      : this.businessInfo.coverageLimit || 1000000;
    
    // Create the API request object
    return {
      businessName: this.businessInfo.businessName,
      ownerFirstName: this.businessInfo.ownerFirstName,
      ownerLastName: this.businessInfo.ownerLastName,
      email: this.businessInfo.emailAddress,
      phone: this.businessInfo.phoneNumber,
      
      // Convert string values to IDs for the API
      businessStructureId: this.getBusinessStructureId(this.businessInfo.businessStructure),
      industryClassId: this.getIndustryClassId(this.businessInfo.businessCategory),
      locationTypeId: this.getLocationTypeId(this.locationInfo.businessLocation),
      ownershipTypeId: this.getOwnershipTypeId(this.locationInfo.ownOrRent),
      
      // Use default business status ID
      businessStatusId: 1, // Assuming 1 = In business with insurance
      
      annualRevenue: this.businessInfo.annualRevenue || 250000,
      businessAddress: this.locationInfo.businessStreetAddress,
      zipCode: this.locationInfo.zipCode,
      
      hasMultipleLocations: hasMultipleLocations,
      isNonProfit: isNonProfit,
      businessDescription: this.businessInfo.businessDescription,
      
      hasAdditionalServices: hasAdditionalServices,
      hasClaimsHistory: hasClaimsHistory,
      claimCount: hasClaimsHistory ? this.businessInfo.claimsCount || 0 : null,
      isHazardous: isHazardous,
      
      yearsInBusiness: this.getYearsInBusiness(),
      employeeCount: this.businessInfo.employeeCount || 0,
      executiveOfficerCount: this.businessInfo.executiveOfficers || 0,
      coverageLimit: coverageLimit,
      selectedCoverages: selectedCoverageIds
    };
  }

  /**
   * Submit the quote data to the API
   */
  submitQuoteToApi(): void {
    this.isSubmitting = true;
    this.apiError = false;
    
    // Check if authenticated
    if (!this.isAuthenticated) {
      // Store data and redirect to login
      sessionStorage.setItem('pendingQuoteData', JSON.stringify(this.prepareQuoteData()));
      sessionStorage.setItem('redirectUrl', '/quote-summary');
      this.router.navigate(['/login']);
      return;
    }
    
    const quoteData = this.prepareQuoteData();
    console.log('Submitting quote data:', quoteData);
    
    // Include auth token in the request
    const httpOptions = {
      headers: this.getAuthHeaders()
    };
    
    this.http.post<any>(this.API_URL, quoteData, httpOptions)
      .pipe(
        catchError(error => {
          console.error('Error submitting quote to API:', error);
          this.apiError = true;
          
          if (error.status === 401) {
            // Unauthorized error - token expired or invalid
            this.errorMessage = 'Your session has expired. Please log in again.';
            localStorage.removeItem(this.AUTH_TOKEN_KEY);
            sessionStorage.setItem('redirectUrl', '/quote-summary');
            setTimeout(() => this.router.navigate(['/login']), 2000);
          } else {
            this.errorMessage = error.message || 'Failed to submit quote. Please try again.';
          }
          
          return of(null);
        }),
        finalize(() => {
          this.isSubmitting = false;
        })
      )
      .subscribe(response => {
        if (response && !this.apiError) {
          // Store response in session storage to access in the preview component
          sessionStorage.setItem('quoteApiResponse', JSON.stringify(response));
          this.router.navigate(['/quote-preview']);
        }
        // If there was an error, the error message is already displayed
      });
  }

  /**
   * Proceed with the insurance application
   * Now with API integration and authentication
   */
  proceedToApplication(): void {
    try {
      // Submit to the API and navigate to preview
      this.submitQuoteToApi();
    } catch (error) {
      // If unexpected error occurs during API submission, fall back to local processing
      console.error('Unexpected error during API submission:', error);
      this.apiError = true;
      this.errorMessage = 'An unexpected error occurred.';
      
      // Create mock response and navigate to preview
      const mockResponse = {
        message: "Quote created successfully",
        quoteId: parseInt(this.quoteId.replace('BIZ-', '')) || 123456,
        ownerName: this.businessInfo.ownerName,
        businessName: this.businessInfo.businessName,
        email: this.businessInfo.emailAddress,
        phone: this.businessInfo.phoneNumber,
        status: "pending"
      };
      
      sessionStorage.setItem('quoteApiResponse', JSON.stringify(mockResponse));
      this.router.navigate(['/quote-preview']);
    }
  }
}