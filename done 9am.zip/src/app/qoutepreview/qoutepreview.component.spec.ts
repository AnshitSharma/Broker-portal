import { ComponentFixture, TestBed } from '@angular/core/testing';

import { QoutepreviewComponent } from './qoutepreview.component';

describe('QoutepreviewComponent', () => {
  let component: QoutepreviewComponent;
  let fixture: ComponentFixture<QoutepreviewComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [QoutepreviewComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(QoutepreviewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
