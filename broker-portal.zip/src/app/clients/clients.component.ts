import { Component, OnInit, HostListener } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { Router, NavigationEnd } from '@angular/router';
import { filter } from 'rxjs/operators';

interface ClientQuote {
  id: string;
  clientId: string;
  clientName: string;
  businessName: string;
  quoteDate: Date;
  premium: number;
  status: 'pending' | 'approved' | 'declined' | 'bound';
  coverageType: string;
}

interface Policy {
  id: string;
  clientId: string;
  originalQuoteId: string;
  clientName: string;
  businessName: string;
  effectiveDate: Date;
  expirationDate: Date;
  premium: number;
  coverageType: string;
  status: 'active' | 'expired' | 'cancelled' | 'pending-renewal';
}

interface Client {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  address: string;
  city: string;
  state: string;
  zipCode: string;
  status: 'active' | 'inactive' | 'prospect';
  dateAdded: Date;
  businessName?: string;
  businessType?: string;
  industry?: string;
  businessAddress?: string;
  businessCity?: string;
  businessState?: string;
  businessZipCode?: string;
  additionalInfo?: string;
  activePolicies: number;
}

interface ClientNote {
  id: number;
  clientId: string;
  author: string;
  date: Date;
  content: string;
}

interface ClientActivity {
  id: number;
  clientId: string;
  type: 'quote' | 'policy' | 'contact' | 'note' | 'document';
  description: string;
  details?: string;
  time: Date;
}

// Interface for client form data
interface ClientFormData {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  address: string;
  city: string;
  state: string;
  zipCode: string;
  status: 'active' | 'inactive' | 'prospect';
  dateAdded: Date;
  businessName: string;
  businessType: string;
  industry: string;
  businessAddress: string;
  businessCity: string;
  businessState: string;
  businessZipCode: string;
  additionalInfo: string;
  activePolicies: number;
}

@Component({
  selector: 'app-clients',
  standalone: true,
  imports: [CommonModule, RouterModule, FormsModule],
  templateUrl: './clients.component.html',
  styleUrls: ['./clients.component.css']
})
export class ClientsComponent implements OnInit {
  // UI State
  darkModeEnabled: boolean = false;
  sidebarCollapsed: boolean = false;
  mobileMenuOpen: boolean = false;
  currentRoute: string = '/clients';
  selectedClient: Client | null = null;
  activeTab: string = 'info';
  formTab: string = 'personal';
  
  // Screen size detection
  isMobileView: boolean = false;
  
  // Pagination
  currentPage: number = 1;
  itemsPerPage: number = 10;
  totalPages: number = 1;
  
  // Broker details
  brokerName: string = 'John Broker';
  brokerRole: string = 'Senior Insurance Broker';
  
  // Filter and search states
  clientSearchQuery: string = '';
  clientStatusFilter: string = 'all';
  clientSortBy: string = 'name-asc';
  
  // User preferences
  notificationsEnabled: boolean = true;
  
  // Client form state
  showClientForm: boolean = false;
  editingClient: boolean = false;
  sameBillingAddress: boolean = true;
  
  // Client form data object
  clientFormData: ClientFormData = {
    id: '',
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    address: '',
    city: '',
    state: '',
    zipCode: '',
    status: 'active',
    dateAdded: new Date(),
    businessName: '',
    businessType: '',
    industry: '',
    businessAddress: '',
    businessCity: '',
    businessState: '',
    businessZipCode: '',
    additionalInfo: '',
    activePolicies: 0
  };
  
  // New note for client
  newNote: string = '';
  
  // Client stats
  totalClients: number = 0;
  activeClients: number = 0;
  newClients: number = 0;
  uniqueBusinesses: number = 0;
  
  // Client data
  allClients: Client[] = [
    {
      id: 'CL-1001',
      firstName: 'Robert',
      lastName: 'Johnson',
      email: 'robert.johnson@johnsonconsulting.com',
      phone: '(555) 123-4567',
      address: '123 Main St',
      city: 'Chicago',
      state: 'IL',
      zipCode: '60601',
      status: 'active',
      dateAdded: new Date(2024, 6, 15),
      businessName: 'Johnson Consulting LLC',
      businessType: 'LLC',
      industry: 'Professional Services',
      businessAddress: '456 Business Blvd, Suite 200',
      businessCity: 'Chicago',
      businessState: 'IL',
      businessZipCode: '60603',
      activePolicies: 2
    },
    {
      id: 'CL-1002',
      firstName: 'Sarah',
      lastName: 'Williams',
      email: 'sarah@artisanbakery.com',
      phone: '(555) 234-5678',
      address: '789 Oak Ave',
      city: 'Portland',
      state: 'OR',
      zipCode: '97205',
      status: 'active',
      dateAdded: new Date(2024, 8, 22),
      businessName: 'Artisan Bakery',
      businessType: 'Sole Proprietorship',
      industry: 'Food Service',
      activePolicies: 1
    },
    {
      id: 'CL-1003',
      firstName: 'Michael',
      lastName: 'Chen',
      email: 'michael@chentechsolutions.com',
      phone: '(555) 345-6789',
      address: '567 Pine St',
      city: 'San Francisco',
      state: 'CA',
      zipCode: '94105',
      status: 'active',
      dateAdded: new Date(2024, 5, 10),
      businessName: 'Chen Technology Solutions',
      businessType: 'Corporation',
      industry: 'Technology',
      businessAddress: '1250 Market St, Floor 3',
      businessCity: 'San Francisco',
      businessState: 'CA',
      businessZipCode: '94103',
      activePolicies: 2
    },
    {
      id: 'CL-1004',
      firstName: 'Alicia',
      lastName: 'Rodriguez',
      email: 'alicia@arinteriordesign.com',
      phone: '(555) 456-7890',
      address: '321 Maple Dr',
      city: 'Miami',
      state: 'FL',
      zipCode: '33101',
      status: 'inactive',
      dateAdded: new Date(2024, 2, 18),
      businessName: 'AR Interior Design',
      businessType: 'LLC',
      industry: 'Professional Services',
      activePolicies: 0
    },
    {
      id: 'CL-1005',
      firstName: 'David',
      lastName: 'Smith',
      email: 'dsmith@smithconstruction.com',
      phone: '(555) 567-8901',
      address: '852 Cedar Ln',
      city: 'Dallas',
      state: 'TX',
      zipCode: '75201',
      status: 'active',
      dateAdded: new Date(2024, 4, 5),
      businessName: 'Smith Construction Inc.',
      businessType: 'Corporation',
      industry: 'Construction',
      businessAddress: '100 Builder Way',
      businessCity: 'Dallas',
      businessState: 'TX',
      businessZipCode: '75207',
      activePolicies: 1
    },
    {
      id: 'CL-1006',
      firstName: 'Jennifer',
      lastName: 'Lee',
      email: 'jennifer@leemedicalsupplies.com',
      phone: '(555) 678-9012',
      address: '741 Birch St',
      city: 'Boston',
      state: 'MA',
      zipCode: '02108',
      status: 'active',
      dateAdded: new Date(2024, 7, 30),
      businessName: 'Lee Medical Supplies',
      businessType: 'LLC',
      industry: 'Healthcare',
      activePolicies: 1
    },
    {
      id: 'CL-1007',
      firstName: 'William',
      lastName: 'Brown',
      email: 'william@brownassociates.com',
      phone: '(555) 789-0123',
      address: '963 Elm St',
      city: 'Denver',
      state: 'CO',
      zipCode: '80202',
      status: 'active',
      dateAdded: new Date(2024, 9, 12),
      businessName: 'Brown & Associates',
      businessType: 'Partnership',
      industry: 'Professional Services',
      activePolicies: 1
    },
    {
      id: 'CL-1008',
      firstName: 'Emily',
      lastName: 'Martinez',
      email: 'emily@martinezfloral.com',
      phone: '(555) 890-1234',
      address: '159 Rose Ln',
      city: 'Seattle',
      state: 'WA',
      zipCode: '98101',
      status: 'active',
      dateAdded: new Date(2025, 0, 8),
      businessName: 'Martinez Floral Design',
      businessType: 'Sole Proprietorship',
      industry: 'Retail',
      activePolicies: 1
    },
    {
      id: 'CL-1009',
      firstName: 'James',
      lastName: 'Wilson',
      email: 'james@wilsonplumbing.com',
      phone: '(555) 901-2345',
      address: '357 Spruce Ave',
      city: 'Phoenix',
      state: 'AZ',
      zipCode: '85001',
      status: 'prospect',
      dateAdded: new Date(2025, 2, 15),
      businessName: 'Wilson Plumbing Services',
      businessType: 'Sole Proprietorship',
      industry: 'Construction',
      activePolicies: 0
    },
    {
      id: 'CL-1010',
      firstName: 'Laura',
      lastName: 'Peterson',
      email: 'laura@petersonconsulting.com',
      phone: '(555) 012-3456',
      address: '258 Aspen Ct',
      city: 'Minneapolis',
      state: 'MN',
      zipCode: '55401',
      status: 'active',
      dateAdded: new Date(2024, 11, 3),
      businessName: 'Peterson Consulting Group',
      businessType: 'LLC',
      industry: 'Professional Services',
      activePolicies: 1
    },
    {
      id: 'CL-1011',
      firstName: 'Kevin',
      lastName: 'Taylor',
      email: 'kevin@taylorauto.com',
      phone: '(555) 456-7890',
      address: '753 Walnut Dr',
      city: 'Indianapolis',
      state: 'IN',
      zipCode: '46204',
      status: 'active',
      dateAdded: new Date(2024, 10, 20),
      businessName: 'Taylor Auto Repair',
      businessType: 'Sole Proprietorship',
      industry: 'Automotive',
      activePolicies: 1
    },
    {
      id: 'CL-1012',
      firstName: 'Elizabeth',
      lastName: 'Clark',
      email: 'elizabeth@clarkdental.com',
      phone: '(555) 567-8901',
      address: '951 Cherry St',
      city: 'Atlanta',
      state: 'GA',
      zipCode: '30301',
      status: 'active',
      dateAdded: new Date(2024, 8, 17),
      businessName: 'Clark Dental Office',
      businessType: 'Professional Corporation',
      industry: 'Healthcare',
      activePolicies: 1
    }
  ];
  
  // Client notes
  clientNotes: ClientNote[] = [
    {
      id: 1,
      clientId: 'CL-1001',
      author: 'John Broker',
      date: new Date(2025, 2, 10, 14, 30),
      content: 'Discussed expansion plans for the consulting business. Client may need to increase coverage limits in the next 6 months.'
    },
    {
      id: 2,
      clientId: 'CL-1001',
      author: 'Maria Underwriter',
      date: new Date(2025, 2, 15, 11, 45),
      content: 'Client provided updated employee count and revenue figures for policy renewal.'
    },
    {
      id: 3,
      clientId: 'CL-1003',
      author: 'John Broker',
      date: new Date(2025, 1, 28, 10, 15),
      content: 'Client is considering adding cyber liability coverage due to recent data breach concerns in the industry.'
    },
    {
      id: 4,
      clientId: 'CL-1005',
      author: 'John Broker',
      date: new Date(2025, 2, 5, 16, 20),
      content: 'Client won a major construction contract and will need additional coverage for new projects.'
    },
    {
      id: 5,
      clientId: 'CL-1008',
      author: 'Lisa Claims',
      date: new Date(2025, 3, 1, 9, 30),
      content: 'Client reported a minor property damage incident but decided not to file a claim after discussing deductible.'
    }
  ];
  
  // Client activity
  clientActivity: ClientActivity[] = [
    {
      id: 1,
      clientId: 'CL-1001',
      type: 'quote',
      description: 'New quote created',
      details: 'General Liability coverage - $2,850 premium',
      time: new Date(2025, 3, 7, 14, 32)
    },
    {
      id: 2,
      clientId: 'CL-1001',
      type: 'policy',
      description: 'Policy renewed',
      details: 'Professional Liability policy renewed with premium increase of 5%',
      time: new Date(2025, 2, 15, 11, 10)
    },
    {
      id: 3,
      clientId: 'CL-1001',
      type: 'contact',
      description: 'Phone call with client',
      details: 'Discussed upcoming renewal and potential coverage changes',
      time: new Date(2025, 2, 8, 10, 45)
    },
    {
      id: 4,
      clientId: 'CL-1001',
      type: 'note',
      description: 'Note added',
      details: 'Updated business information in CRM',
      time: new Date(2025, 1, 20, 15, 30)
    },
    {
      id: 5,
      clientId: 'CL-1003',
      type: 'quote',
      description: 'Quote approved',
      details: 'Client approved Cyber Liability quote',
      time: new Date(2025, 3, 4, 9, 15)
    },
    {
      id: 6,
      clientId: 'CL-1003',
      type: 'document',
      description: 'Certificate issued',
      details: 'New certificate of insurance issued for vendor requirement',
      time: new Date(2025, 2, 28, 16, 20)
    },
    {
      id: 7,
      clientId: 'CL-1005',
      type: 'policy',
      description: 'Policy endorsement',
      details: 'Added additional insured to policy',
      time: new Date(2025, 3, 2, 11, 45)
    },
    {
      id: 8,
      clientId: 'CL-1008',
      type: 'contact',
      description: 'Email sent',
      details: 'Sent policy renewal notification and updated coverage options',
      time: new Date(2025, 3, 1, 14, 10)
    }
  ];
  
  // Policies data
  policies: Policy[] = [
    { 
      id: 'POL-2025-01254', 
      clientId: 'CL-1003',
      originalQuoteId: 'Q-39465',
      clientName: 'Michael Chen', 
      businessName: 'Chen Technology Solutions', 
      effectiveDate: new Date(2025, 3, 10), 
      expirationDate: new Date(2026, 3, 10),
      premium: 5100, 
      coverageType: 'Advertising Injury',
      status: 'active'
    },
    { 
      id: 'POL-2025-01247', 
      clientId: 'CL-1008',
      originalQuoteId: 'Q-39439',
      clientName: 'Emily Martinez', 
      businessName: 'Martinez Floral Design', 
      effectiveDate: new Date(2025, 3, 5), 
      expirationDate: new Date(2026, 3, 5),
      premium: 1875, 
      coverageType: 'Products and Completed Operations',
      status: 'active'
    },
    { 
      id: 'POL-2025-01211', 
      clientId: 'CL-1001',
      originalQuoteId: 'Q-38942',
      clientName: 'Robert Johnson', 
      businessName: 'Johnson Consulting LLC', 
      effectiveDate: new Date(2025, 2, 1), 
      expirationDate: new Date(2026, 2, 1),
      premium: 6750, 
      coverageType: 'Professional Liability',
      status: 'active'
    },
    {
      id: 'POL-2025-01165', 
      clientId: 'CL-1001',
      originalQuoteId: 'Q-38791',
      clientName: 'Robert Johnson', 
      businessName: 'Johnson Consulting LLC', 
      effectiveDate: new Date(2025, 1, 10), 
      expirationDate: new Date(2026, 1, 10),
      premium: 5200, 
      coverageType: 'General Liability',
      status: 'active'
    },
    { 
      id: 'POL-2025-01152', 
      clientId: 'CL-1005',
      originalQuoteId: 'Q-38754',
      clientName: 'David Smith', 
      businessName: 'Smith Construction Inc.', 
      effectiveDate: new Date(2025, 1, 5), 
      expirationDate: new Date(2026, 1, 5),
      premium: 9200, 
      coverageType: 'Independent Contractors',
      status: 'active'
    },
    { 
      id: 'POL-2025-01138', 
      clientId: 'CL-1002',
      originalQuoteId: 'Q-38699',
      clientName: 'Sarah Williams', 
      businessName: 'Artisan Bakery', 
      effectiveDate: new Date(2025, 0, 25), 
      expirationDate: new Date(2026, 0, 25),
      premium: 2950, 
      coverageType: 'Products and Completed Operations',
      status: 'active'
    },
    { 
      id: 'POL-2025-01107', 
      clientId: 'CL-1003',
      originalQuoteId: 'Q-38623',
      clientName: 'Michael Chen', 
      businessName: 'Chen Technology Solutions', 
      effectiveDate: new Date(2025, 0, 15), 
      expirationDate: new Date(2026, 0, 15),
      premium: 3500, 
      coverageType: 'Cyber Liability',
      status: 'active'
    }
  ];
  
  // Quotes data
  quotes: ClientQuote[] = [
    { 
      id: 'Q-39485', 
      clientId: 'CL-1001',
      clientName: 'Robert Johnson', 
      businessName: 'Johnson Consulting LLC', 
      quoteDate: new Date(2025, 3, 2), 
      premium: 2850, 
      status: 'pending',
      coverageType: 'Cyber Liability'
    },
    { 
      id: 'Q-39471', 
      clientId: 'CL-1002',
      clientName: 'Sarah Williams', 
      businessName: 'Artisan Bakery', 
      quoteDate: new Date(2025, 3, 3), 
      premium: 3200, 
      status: 'approved',
      coverageType: 'Workers Compensation'
    },
    { 
      id: 'Q-39458', 
      clientId: 'CL-1004',
      clientName: 'Alicia Rodriguez', 
      businessName: 'AR Interior Design', 
      quoteDate: new Date(2025, 3, 5), 
      premium: 1950, 
      status: 'declined',
      coverageType: 'Professional Liability'
    },
    { 
      id: 'Q-39441', 
      clientId: 'CL-1006',
      clientName: 'Jennifer Lee', 
      businessName: 'Lee Medical Supplies', 
      quoteDate: new Date(2025, 3, 1), 
      premium: 4250, 
      status: 'pending',
      coverageType: 'General Liability'
    },
    { 
      id: 'Q-39440', 
      clientId: 'CL-1007',
      clientName: 'William Brown', 
      businessName: 'Brown & Associates', 
      quoteDate: new Date(2025, 2, 29), 
      premium: 3120, 
      status: 'approved',
      coverageType: 'Professional Liability'
    }
  ];
  
  // For displaying filtered clients
  filteredClients: Client[] = [];
  
  constructor(private router: Router) {
    // Subscribe to router events to track current route
    this.router.events
      .pipe(filter(event => event instanceof NavigationEnd))
      .subscribe((event: any) => {
        this.currentRoute = event.url;
        // Reset to first page when changing routes
        this.currentPage = 1;
        // Close mobile menu when navigating
        this.mobileMenuOpen = false;
      });
      
    // Check initial screen size
    this.checkScreenSize();
  }
  
  // Host listener to detect screen size changes
  @HostListener('window:resize', ['$event'])
  onResize() {
    this.checkScreenSize();
  }
  
  // Check if the screen is mobile size
  checkScreenSize() {
    this.isMobileView = window.innerWidth < 992;
    // Auto-collapse sidebar on mobile
    if (this.isMobileView && !this.mobileMenuOpen) {
      this.sidebarCollapsed = true;
    }
  }
  
  ngOnInit(): void {
    // Check if dark mode is saved in localStorage
    const savedDarkMode = localStorage.getItem('darkMode');
    if (savedDarkMode) {
      this.darkModeEnabled = JSON.parse(savedDarkMode);
      document.body.classList.toggle('dark-mode', this.darkModeEnabled);
    }
    
    // Check if sidebar state is saved in localStorage
    const savedSidebarState = localStorage.getItem('sidebarCollapsed');
    if (savedSidebarState) {
      this.sidebarCollapsed = JSON.parse(savedSidebarState);
    }
    
    // Initialize current route
    this.currentRoute = this.router.url;
    
    // Calculate client stats
    this.calculateClientStats();
    
    // Initialize filtered clients
    this.filterClients();
  }
  
  // Calculate client statistics
  calculateClientStats(): void {
    this.totalClients = this.allClients.length;
    this.activeClients = this.allClients.filter(client => client.status === 'active').length;
    
    // Calculate clients added this month
    const today = new Date();
    const firstDayOfMonth = new Date(today.getFullYear(), today.getMonth(), 1);
    this.newClients = this.allClients.filter(client => client.dateAdded >= firstDayOfMonth).length;
    
    // Calculate unique businesses
    const uniqueBusinessNames = new Set(
      this.allClients
        .filter(client => client.businessName && client.businessName.trim() !== '')
        .map(client => client.businessName)
    );
    this.uniqueBusinesses = uniqueBusinessNames.size;
  }
  
  // Toggle sidebar collapsed state
  toggleSidebar(): void {
    this.sidebarCollapsed = !this.sidebarCollapsed;
    localStorage.setItem('sidebarCollapsed', JSON.stringify(this.sidebarCollapsed));
    
    // On mobile, also control the mobile menu state
    if (this.isMobileView) {
      this.mobileMenuOpen = !this.sidebarCollapsed;
    }
  }
  
  // Toggle mobile menu specifically
  toggleMobileMenu(): void {
    this.mobileMenuOpen = !this.mobileMenuOpen;
    // When opening mobile menu, make sure sidebar isn't collapsed
    if (this.mobileMenuOpen) {
      this.sidebarCollapsed = false;
    }
  }
  
  // Close mobile menu
  closeMobileMenu(): void {
    this.mobileMenuOpen = false;
  }
  
  // Toggle dark mode
  toggleDarkMode(): void {
    this.darkModeEnabled = !this.darkModeEnabled;
    document.body.classList.toggle('dark-mode', this.darkModeEnabled);
    localStorage.setItem('darkMode', JSON.stringify(this.darkModeEnabled));
  }
  
  // Toggle notifications
  toggleNotifications(): void {
    this.notificationsEnabled = !this.notificationsEnabled;
    // In a real app, you would update user preferences in backend
  }
  
  // Filter clients based on search criteria and filters
  filterClients(): void {
    let filtered = [...this.allClients];
    
    // Apply status filter
    if (this.clientStatusFilter !== 'all') {
      filtered = filtered.filter(client => client.status === this.clientStatusFilter);
    }
    
    // Apply search filter
    if (this.clientSearchQuery.trim() !== '') {
      const search = this.clientSearchQuery.toLowerCase();
      filtered = filtered.filter(client => 
        `${client.firstName.toLowerCase()} ${client.lastName.toLowerCase()}`.includes(search) ||
        client.email.toLowerCase().includes(search) ||
        client.phone.toLowerCase().includes(search) ||
        (client.businessName && client.businessName.toLowerCase().includes(search))
      );
    }
    
    // Apply sorting
    switch(this.clientSortBy) {
      case 'name-asc':
        filtered.sort((a, b) => `${a.firstName} ${a.lastName}`.localeCompare(`${b.firstName} ${b.lastName}`));
        break;
      case 'name-desc':
        filtered.sort((a, b) => `${b.firstName} ${b.lastName}`.localeCompare(`${a.firstName} ${a.lastName}`));
        break;
      case 'date-desc':
        filtered.sort((a, b) => b.dateAdded.getTime() - a.dateAdded.getTime());
        break;
      case 'date-asc':
        filtered.sort((a, b) => a.dateAdded.getTime() - b.dateAdded.getTime());
        break;
    }
    
    // Update filtered clients
    this.filteredClients = filtered;
    
    // Update total pages
    this.totalPages = Math.ceil(this.filteredClients.length / this.itemsPerPage);
    
    // Reset to first page if current page is now invalid
    if (this.currentPage > this.totalPages && this.totalPages > 0) {
      this.currentPage = 1;
    }
  }
  
  // Get paginated clients for current page
  getPaginatedClients(): Client[] {
    const startIndex = (this.currentPage - 1) * this.itemsPerPage;
    const endIndex = startIndex + this.itemsPerPage;
    return this.filteredClients.slice(startIndex, endIndex);
  }
  
  // Get page numbers array for pagination display
  getPageNumbers(): number[] {
    const pages: number[] = [];
    const maxDisplayPages = 5;
    
    if (this.totalPages <= maxDisplayPages) {
      // Display all pages if total pages is less than max display
      for (let i = 1; i <= this.totalPages; i++) {
        pages.push(i);
      }
    } else {
      // Display a subset of pages with current page in middle if possible
      const halfMax = Math.floor(maxDisplayPages / 2);
      
      let startPage = Math.max(this.currentPage - halfMax, 1);
      let endPage = startPage + maxDisplayPages - 1;
      
      if (endPage > this.totalPages) {
        endPage = this.totalPages;
        startPage = Math.max(endPage - maxDisplayPages + 1, 1);
      }
      
      for (let i = startPage; i <= endPage; i++) {
        pages.push(i);
      }
    }
    
    return pages;
  }
  
  // Change page in pagination
  changePage(page: number): void {
    if (page < 1 || page > this.totalPages) {
      return;
    }
    this.currentPage = page;
  }
  
  // View client details
  viewClientDetails(client: Client): void {
    this.selectedClient = client;
    this.activeTab = 'info';
  }
  
  // Close client details modal
  closeClientDetails(event?: MouseEvent): void {
    this.selectedClient = null;
  }
  
  // Add new client
  addNewClient(): void {
    this.editingClient = false;
    this.resetClientForm();
    this.showClientForm = true;
    this.formTab = 'personal';
  }
  
  // Edit client
  editClient(client: Client): void {
    this.editingClient = true;
    this.populateClientForm(client);
    this.showClientForm = true;
    this.formTab = 'personal';
  }
  
  // Cancel client form
  cancelClientForm(event?: MouseEvent): void {
    this.showClientForm = false;
  }
  
  // Save client (add new or update existing)
  saveClient(): void {
    // Create client object from form
    const client: Client = {
      id: this.editingClient && this.clientFormData.id ? this.clientFormData.id : `CL-${Math.floor(1000 + Math.random() * 9000)}`,
      firstName: this.clientFormData.firstName,
      lastName: this.clientFormData.lastName,
      email: this.clientFormData.email,
      phone: this.clientFormData.phone,
      address: this.clientFormData.address,
      city: this.clientFormData.city,
      state: this.clientFormData.state,
      zipCode: this.clientFormData.zipCode,
      status: this.clientFormData.status,
      dateAdded: this.editingClient && this.clientFormData.dateAdded ? this.clientFormData.dateAdded : new Date(),
      businessName: this.clientFormData.businessName,
      businessType: this.clientFormData.businessType,
      industry: this.clientFormData.industry,
      businessAddress: this.sameBillingAddress ? this.clientFormData.address : this.clientFormData.businessAddress,
      businessCity: this.sameBillingAddress ? this.clientFormData.city : this.clientFormData.businessCity,
      businessState: this.sameBillingAddress ? this.clientFormData.state : this.clientFormData.businessState,
      businessZipCode: this.sameBillingAddress ? this.clientFormData.zipCode : this.clientFormData.businessZipCode,
      additionalInfo: this.clientFormData.additionalInfo,
      activePolicies: this.editingClient ? this.clientFormData.activePolicies : 0
    };
    
    if (this.editingClient) {
      // Update existing client
      const index = this.allClients.findIndex(c => c.id === client.id);
      if (index !== -1) {
        this.allClients[index] = client;
        
        // If this is the currently selected client, update that too
        if (this.selectedClient && this.selectedClient.id === client.id) {
          this.selectedClient = client;
        }
      }
    } else {
      // Add new client
      this.allClients.push(client);
      
      // Update stats
      this.calculateClientStats();
    }
    
    // Re-apply filters
    this.filterClients();
    
    // Close form
    this.showClientForm = false;
    
    // Show success message
    alert(`Client ${this.editingClient ? 'updated' : 'added'} successfully.`);
  }
  
  // Reset client form
  resetClientForm(): void {
    this.clientFormData = {
      id: '',
      firstName: '',
      lastName: '',
      email: '',
      phone: '',
      address: '',
      city: '',
      state: '',
      zipCode: '',
      status: 'active',
      dateAdded: new Date(),
      businessName: '',
      businessType: '',
      industry: '',
      businessAddress: '',
      businessCity: '',
      businessState: '',
      businessZipCode: '',
      additionalInfo: '',
      activePolicies: 0
    };
    this.sameBillingAddress = true;
  }
  
  // Populate client form with existing client data
  populateClientForm(client: Client): void {
    this.clientFormData = {
      id: client.id,
      firstName: client.firstName,
      lastName: client.lastName,
      email: client.email,
      phone: client.phone,
      address: client.address || '',
      city: client.city || '',
      state: client.state || '',
      zipCode: client.zipCode || '',
      status: client.status,
      dateAdded: client.dateAdded,
      businessName: client.businessName || '',
      businessType: client.businessType || '',
      industry: client.industry || '',
      businessAddress: client.businessAddress || '',
      businessCity: client.businessCity || '',
      businessState: client.businessState || '',
      businessZipCode: client.businessZipCode || '',
      additionalInfo: client.additionalInfo || '',
      activePolicies: client.activePolicies
    };
    this.sameBillingAddress = !client.businessAddress || client.businessAddress === client.address;
  }
  
  // Set active tab in client details
  setActiveTab(tab: string): void {
    this.activeTab = tab;
  }
  
  // Create quote for client
  createQuoteForClient(client: Client): void {
    // In a real app, this would route to the quote creation page
    // and pre-fill client information
    this.router.navigate(['/insurance'], { 
      queryParams: { clientId: client.id }
    });
  }
  
  // Email client
  emailClient(client: Client): void {
    // In a real app, this would open an email composition interface
    window.open(`mailto:${client.email}`);
  }
  
  // Export client list
  exportClientList(): void {
    // In a real app, this would generate a CSV or Excel file
    alert('Exporting client list...');
  }
  
  // Add a note for the selected client
  addNote(): void {
    if (!this.selectedClient || !this.newNote.trim()) {
      return;
    }
    
    const note: ClientNote = {
      id: this.clientNotes.length + 1,
      clientId: this.selectedClient.id,
      author: this.brokerName,
      date: new Date(),
      content: this.newNote.trim()
    };
    
    this.clientNotes.push(note);
    
    // Add activity entry for the note
    const activity: ClientActivity = {
      id: this.clientActivity.length + 1,
      clientId: this.selectedClient.id,
      type: 'note',
      description: 'Note added',
      details: note.content.length > 50 ? note.content.substring(0, 50) + '...' : note.content,
      time: new Date()
    };
    
    this.clientActivity.push(activity);
    
    // Clear the note input
    this.newNote = '';
  }
  
  // Get notes for a specific client
  getClientNotes(clientId: string): ClientNote[] {
    return this.clientNotes.filter(note => note.clientId === clientId);
  }
  
  // Get activities for a specific client
  getClientActivity(clientId: string): ClientActivity[] {
    return this.clientActivity
      .filter(activity => activity.clientId === clientId)
      .sort((a, b) => b.time.getTime() - a.time.getTime()); // Most recent first
  }
  
  // Get policies for a specific client
  getClientPolicies(clientId: string): Policy[] {
    return this.policies.filter(policy => policy.clientId === clientId);
  }
  
  // Get quotes for a specific client
  getClientQuotes(clientId: string): ClientQuote[] {
    return this.quotes.filter(quote => quote.clientId === clientId);
  }
  
  // Get status class for styling
  getStatusClass(status: string): string {
    switch(status) {
      case 'active': return 'status-active';
      case 'inactive': return 'status-inactive';
      case 'prospect': return 'status-prospect';
      default: return '';
    }
  }
  
  // Get quote status class for styling
  getQuoteStatusClass(status: string): string {
    switch(status) {
      case 'pending': return 'status-pending';
      case 'approved': return 'status-approved';
      case 'bound': return 'status-bound';
      case 'declined': return 'status-declined';
      default: return '';
    }
  }
  
  // Get activity icon based on type
  getActivityIcon(type: string): string {
    switch(type) {
      case 'quote': return 'fa-file-invoice-dollar';
      case 'policy': return 'fa-file-contract';
      case 'contact': return 'fa-phone-alt';
      case 'note': return 'fa-sticky-note';
      case 'document': return 'fa-file-alt';
      default: return 'fa-circle';
    }
  }
}