import { Injectable } from '@angular/core';
import { CanActivate, Router, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class RouteGuardsService implements CanActivate {
  constructor(private router: Router) {}

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean {
    const targetPath = state.url;
    
    // For quote-preview, check if we have the API response
    if (targetPath === '/quote-preview') {
      const hasApiResponse = !!sessionStorage.getItem('quoteApiResponse');
      if (!hasApiResponse) {
        this.router.navigate(['/quote-summary']);
        return false;
      }
      return true;
    }
    
    // For quote-summary, check if we have selected coverages
    if (targetPath === '/quote-summary') {
      const hasCoverages = !!sessionStorage.getItem('selectedCoverages');
      if (!hasCoverages) {
        this.router.navigate(['/coverage-details']);
        return false;
      }
      return true;
    }
    
    // For coverage-details, check if we have business details
    if (targetPath === '/coverage-details') {
      const hasBusinessDetails = !!sessionStorage.getItem('insurance_quote_data');
      if (!hasBusinessDetails) {
        this.router.navigate(['/final-page']);
        return false;
      }
      return true;
    }
    
    // For final-page, check if we have location info
    if (targetPath === '/final-page') {
      const hasLocationInfo = !!sessionStorage.getItem('quoteLocationInfo');
      if (!hasLocationInfo) {
        this.router.navigate(['/next-page']);
        return false;
      }
      return true;
    }
    
    // For next-page, check if we have basic info
    if (targetPath === '/next-page') {
      const hasBasicInfo = !!sessionStorage.getItem('quoteBasicInfo');
      if (!hasBasicInfo) {
        this.router.navigate(['/insurance']);
        return false;
      }
      return true;
    }
    
    return true;
  }
}