import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { StorageService } from '../services/storage.ts.service';

interface Coverage {
  title: string;
  description: string;
  price: number;
  selected: boolean;
}

interface InsuranceQuote {
  id: string;
  companyName: string;
  companyLogo: string;
  tagline: string;
  lifeAmount: string;
  claimSettlement: string;
  price: string;
  priceMonthly: number;
  maxLimit: string;
  features: string[];
  discount: string;
}

@Component({
  selector: 'app-quote-summary',
  standalone: true,
  templateUrl: './quote-summary.component.html',
  styleUrls: ['./quote-summary.component.css'],
  imports: [CommonModule, FormsModule]
})
export class QuoteSummaryComponent implements OnInit {
  // Quote information
  quoteId: string = '';
  quoteDate: Date = new Date();
  
  // Selected coverages from previous step
  selectedCoverages: Coverage[] = [];
  totalPrice: number = 0;
  
  // Business information from step 1
  businessInfo: any = {
    ownerName: '',
    businessName: '',
    businessStructure: '',
    businessYear: '',
    employeeCount: 0,
    executiveOfficers: 0,
    businessDescription: '',
    isNonProfit: 'No',
    additionalServices: 'No'
  };
  
  // Location information from step 2
  locationInfo: any = {
    businessLocation: '',
    businessStreetAddress: '',
    zipCode: '',
    ownOrRent: '',
    hasOtherLocations: 'No'
  };
  
  // Selected quote information from choose-quote component
  selectedQuote: InsuranceQuote | null = null;
  
  constructor(
    private router: Router,
    private storageService: StorageService
  ) {}
  
  ngOnInit(): void {
    this.loadQuoteData();
  }
  
  /**
   * Load data from previous steps
   */
  loadQuoteData(): void {
    // Generate a random quote ID
    this.quoteId = 'BIZ-' + Math.floor(100000 + Math.random() * 900000);
    
    // Load coverage data from session storage
    const coverageData = this.storageService.getItem('selectedCoverages');
    if (coverageData) {
      this.selectedCoverages = coverageData;
    }
    
    const totalPriceStr = this.storageService.getItem('totalPrice');
    if (totalPriceStr) {
      this.totalPrice = parseFloat(totalPriceStr);
    }
    
    // Load selected quote data from session storage
    const selectedQuoteData = this.storageService.getItem('selectedQuote');
    if (selectedQuoteData) {
      this.selectedQuote = selectedQuoteData;
    }
    
    // Load basic info from step 1
    const basicInfo = this.storageService.getItem('quoteBasicInfo');
    if (basicInfo) {
      // Owner info
      const firstName = basicInfo.ownerFirstName || '';
      const lastName = basicInfo.ownerLastName || '';
      this.businessInfo.ownerName = `${firstName} ${lastName}`.trim();
      this.businessInfo.businessName = basicInfo.businessName || '';
      this.businessInfo.businessStructure = basicInfo.businessStructure || '';
    }
    
    // Load location info from step 2
    const locationInfo = this.storageService.getItem('quoteLocationInfo');
    if (locationInfo) {
      this.locationInfo.businessLocation = locationInfo.businessLocation || '';
      this.locationInfo.businessStreetAddress = locationInfo.businessStreetAddress || '';
      this.locationInfo.zipCode = locationInfo.zipCode || '';
      this.locationInfo.ownOrRent = locationInfo.ownOrRent || '';
      this.locationInfo.hasOtherLocations = locationInfo.hasOtherLocations || 'No';
    }
    
    // Load business details from step 3
    const businessDetails = this.storageService.getItem('quoteBusinessDetails');
    if (businessDetails) {
      this.businessInfo.businessYear = businessDetails.businessYear || '';
      this.businessInfo.employeeCount = businessDetails.employeeCount || 0;
      this.businessInfo.executiveOfficers = businessDetails.executiveOfficers || 0;
      this.businessInfo.businessDescription = businessDetails.businessDescription || '';
      this.businessInfo.isNonProfit = businessDetails.isNonProfit || 'No';
      this.businessInfo.additionalServices = businessDetails.additionalServices || 'No';
    }
    
    // If data is still incomplete, use mock data for demonstration
    if (!this.businessInfo.ownerName) {
      this.setMockData();
    }
  }
  
  /**
   * Set mock data for demonstration purposes when real data is missing
   */
  setMockData(): void {
    // Mock data for business information (Step 1 & 3)
    this.businessInfo = {
      ownerName: 'John Smith',
      businessName: 'Smith Consulting LLC',
      businessStructure: 'Limited Liability Corporation (LLC)',
      businessYear: '2018',
      employeeCount: 5,
      executiveOfficers: 2,
      businessDescription: 'IT Consulting Services',
      isNonProfit: 'No',
      additionalServices: 'Yes'
    };
    
    // Mock data for location information (Step 2)
    this.locationInfo = {
      businessLocation: 'Commercial Building',
      businessStreetAddress: '123 Business Ave, Suite 101',
      zipCode: '10001',
      ownOrRent: 'Rent',
      hasOtherLocations: 'No'
    };
  }
  
  /**
   * Navigate back to the quote selection page
   */
  previousStep(): void {
    this.router.navigate(['/choose-quote']);
  }
  
  /**
   * Proceed with the insurance application
   */
  proceedToApplication(): void {
    // In a real application, you would save all the collected data
    // and navigate to a confirmation or payment page
    
    // For demo purposes, we'll just show an alert
    alert('Your insurance application has been submitted with ' + 
          (this.selectedQuote ? this.selectedQuote.companyName : 'your selected provider') + 
          '. A representative will contact you shortly.');
    
    // Clear all the session storage
    this.clearSessionStorage();
    
    // Navigate to a confirmation page or home
    this.router.navigate(['/']);
  }
  
  /**
   * Clear all session storage data
   */
  clearSessionStorage(): void {
    this.storageService.removeItem('selectedCoverages');
    this.storageService.removeItem('totalPrice');
    this.storageService.removeItem('selectedQuote');
    this.storageService.removeItem('quoteBasicInfo');
    this.storageService.removeItem('quoteLocationInfo');
    this.storageService.removeItem('quoteBusinessDetails');
    this.storageService.removeItem('coverageSelections');
    
    // Alternative: clear all storage at once
    // this.storageService.clear();
  }
}