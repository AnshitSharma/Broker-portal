import { Routes } from '@angular/router';
import { QuoteFormComponent } from './features/quote/quote-form/quote-form.component';
import { QuoteListComponent } from './features/quote/quote-list/quote-list.component';
import { QuoteDetailsComponent } from './features/quote/quote-details/quote-details.component';
import { InsuranceCodeComponent } from './insurance-quote/insurance-quote.component';
import { NextPageComponent } from './next-page/next-page.component';
import { FinalPageComponent } from './final-page/final-page.component';
import { CoverageDetailsComponent } from './coverage-details/coverage-details.component';
import { HomeComponent } from './home/home.component';
import { PoliciesComponent } from './policies/policies.component';
import { ClientsComponent } from './clients/clients.component';
import { QuoteSummaryComponent } from './quote-summary/quote-summary.component';
import { QuoteListingComponent } from '../../qoute-listing/qoute-listing.component';
import { ContactUsComponent } from './contact-us/contact-us.component';
import { BrokerDashboardComponent } from './broker-dashboard/broker-dashboard.component';
import { LoginComponent } from './auth/login/login.component';
import { RegisterComponent } from './auth/register/register.component';
import { AuthGuard } from './guards/auth.guard';
import { ReportDashboardComponent } from './report-dashboard/report-dashboard.component';
import { QuotePreviewComponent } from './qoutepreview/qoutepreview.component';
import { AboutUsComponent } from './about-us/about-us.component';
import {PasswordChangePageComponent} from './password-change/password-change.component';

export const routes: Routes = [
  // Public routes - no authentication required
  { path: 'home', component: HomeComponent },
  { path: 'login', component: LoginComponent },
  { path: 'password-change', component: PasswordChangePageComponent },
  { path: 'register', component: RegisterComponent },
  { path: 'contact-us', component: ContactUsComponent },
   {path: 'about-us', component: AboutUsComponent},

  // Optional - can be made public or protected
  { path: 'new-quote', component: InsuranceCodeComponent , canActivate: [AuthGuard]},
  { path: 'next-page', component: NextPageComponent, canActivate: [AuthGuard] },
  { path: 'final-page', component: FinalPageComponent , canActivate: [AuthGuard]},
  { path: 'coverage-details', component: CoverageDetailsComponent, canActivate: [AuthGuard] },
  { path: 'quote-summary', component: QuoteSummaryComponent, canActivate: [AuthGuard] },
  { path: 'quote-preview', component: QuotePreviewComponent , canActivate: [AuthGuard] },

  // Protected routes - require authentication
  { path: 'quotes-list', component: QuoteListComponent, canActivate: [AuthGuard] },
  { path: 'quote-form/new', component: QuoteFormComponent, canActivate: [AuthGuard] },
  { path: 'quote-details/:id', component: QuoteDetailsComponent, canActivate: [AuthGuard] },
  { path: 'quote-listing', component: QuoteListingComponent, canActivate: [AuthGuard] },
  
  // Dashboard and related components (protected)
  { path: 'dashboard', component: BrokerDashboardComponent, canActivate: [AuthGuard]}, 
  { path: 'quotes', component: BrokerDashboardComponent, canActivate: [AuthGuard] },
  { path: 'policies', component: PoliciesComponent, canActivate: [AuthGuard] },
  { path: 'clients', component: ClientsComponent, canActivate: [AuthGuard] },
  { path: 'commission', component: BrokerDashboardComponent, canActivate: [AuthGuard] },
  { path: 'profile', component: BrokerDashboardComponent, canActivate: [AuthGuard] },
  { path: 'settings', component: BrokerDashboardComponent, canActivate: [AuthGuard] },
  { path: 'report-dashboard', component: ReportDashboardComponent,canActivate: [AuthGuard]},
  
  // Default routes
  { path: '', redirectTo: '/home', pathMatch: 'full' },
  { path: '**', redirectTo: '/home' }
];