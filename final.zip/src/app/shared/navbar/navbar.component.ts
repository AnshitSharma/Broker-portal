import { Component, OnInit, HostListener } from '@angular/core';
import { Router, RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-navbar',
  standalone: true,
  imports: [RouterModule, CommonModule],
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit {
  isLoggedIn: boolean = false;
  isScrolled: boolean = false;
  mobileMenuOpen: boolean = false;
 
  constructor(private router: Router, private authService: AuthService) {}

  ngOnInit(): void {
    // Check authentication status on initialization
    this.isLoggedIn = this.authService.isAuthenticated();

    // Subscribe to auth status changes
    this.authService.currentUser$.subscribe(user => {
      this.isLoggedIn = !!user;
    });
  }

  // Add scroll listener for navbar effects
  @HostListener('window:scroll')
  onWindowScroll(): void {
    const scrollPosition = window.pageYOffset || document.documentElement.scrollTop || document.body.scrollTop || 0;
    this.isScrolled = scrollPosition > 50;
  }

  // Toggle auth state and navigate appropriately
  toggleAuth(): void {
    if (this.isLoggedIn) {
      // If currently logged in, log out
      this.authService.logout();
    } else {
      // If not logged in, navigate to login page
      this.router.navigate(['/login']);
    }
   
    // Close mobile menu if open
    if (this.mobileMenuOpen) {
      this.closeMobileMenu();
    }
  }
 
  // Toggle mobile menu visibility
  toggleMobileMenu(): void {
    this.mobileMenuOpen = !this.mobileMenuOpen;
   
    // Prevent body scrolling when menu is open
    if (this.mobileMenuOpen) {
      this.disableBodyScroll();
    } else {
      this.enableBodyScroll();
    }
  }
 
  // Close mobile menu
  closeMobileMenu(): void {
    if (this.mobileMenuOpen) {
      this.mobileMenuOpen = false;
      this.enableBodyScroll();
    }
  }

  // Helper method to disable body scrolling
  private disableBodyScroll(): void {
    document.body.style.overflow = 'hidden';
  }

  // Helper method to enable body scrolling
  private enableBodyScroll(): void {
    document.body.style.overflow = '';
  }
}