import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { StorageService } from '../services/storage.ts.service';

@Component({
  selector: 'app-insurance-quote',
  standalone: true,
  templateUrl: './insurance-quote.component.html',
  styleUrls: ['./insurance-quote.component.css'],
  imports: [CommonModule, FormsModule]
})
export class InsuranceCodeComponent implements OnInit {
  // Step progress
  currentStep = 1;
  showErrors = false;
  
  // Business Status
  businessStatus = [
    { id: 'active-insured', label: 'I\'m in business and have insurance.', selected: false },
    { id: 'active-uninsured', label: 'I\'m in business but don\'t have insurance yet.', selected: false },
    { id: 'starting', label: 'I\'m starting a business and curious about insurance.', selected: false }
  ];
  
  // Business Structure
  businessStructure = '';
  businessStructures = [
    'Sole Proprietorship',
    'Limited Liability Company (LLC)',
    'S-Corporation',
    'C-Corporation',
    'Partnership',
    'Non-Profit Organization',
    'Other'
  ];
  
  // Owner Information
  ownerFirstName = '';
  ownerLastName = '';
  businessName = '';
  namePattern = /^[A-Za-z\s\-']+$/; // Only allow letters, spaces, hyphens, and apostrophes
  
  // Name validation errors
  // firstNameHasNumbers = false;
  // lastNameHasNumbers = false;
  
firstNameHasInvalidChars = false;
  lastNameHasInvalidChars = false;


  // Contact Information
  emailAddress = '';
  phoneNumber = '';
  
  constructor(
    private router: Router,
    private storageService: StorageService
  ) {}
  
  ngOnInit(): void {
    // Check if we already have stored data (returning from a later step)
    this.loadStoredData();
  }
  
  // Load any previously stored data
  loadStoredData(): void {
    const storedData = this.storageService.getItem('quoteBasicInfo');
    if (storedData) {
      // Business Status
      if (storedData.businessStatus) {
        this.businessStatus = storedData.businessStatus;
      }
      
      // Business Structure
      if (storedData.businessStructure) {
        this.businessStructure = storedData.businessStructure;
      }
      
      // Owner Information
      if (storedData.ownerFirstName) {
        this.ownerFirstName = storedData.ownerFirstName;
      }
      
      if (storedData.ownerLastName) {
        this.ownerLastName = storedData.ownerLastName;
      }
      
      if (storedData.businessName) {
        this.businessName = storedData.businessName;
      }

      // Contact Information
      if (storedData.emailAddress) {
        this.emailAddress = storedData.emailAddress;
      }

      if (storedData.phoneNumber) {
        this.phoneNumber = storedData.phoneNumber;
      }
    }
  }
  
  // Validate form before proceeding
  validateForm(): boolean {
    // Check if at least one business status is selected
    const hasBusinessStatus = this.businessStatus.some(status => status.selected);
    
    // Check if business structure is selected
    const hasBusinessStructure = !!this.businessStructure;
    
    // Check if owner information is provided and valid
    const hasOwnerInfo = !!this.ownerFirstName && !!this.ownerLastName && 
                          this.isValidName(this.ownerFirstName) && this.isValidName(this.ownerLastName);

    // Check if contact information is provided and valid
    const hasValidContactInfo = this.isValidEmail() && this.isValidPhone();
    
    return hasBusinessStatus && hasBusinessStructure && hasOwnerInfo && hasValidContactInfo;
  }
  
  // Validate name fields (no numbers allowed)
  
validateName(type: 'first' | 'last'): void {
      if (type === 'first') {
        this.firstNameHasInvalidChars = this.ownerFirstName ? !this.isValidName(this.ownerFirstName) : false;
      } else if (type === 'last') {
        this.lastNameHasInvalidChars = this.ownerLastName ? !this.isValidName(this.ownerLastName) : false;
      }
    }
  

  
  
  // Check if name is valid (no numbers)
  isValidName(name: string): boolean {
    return this.namePattern.test(name);
  }

  // Validate email address
  validateEmail(): boolean {
    return this.isValidEmail();
  }

  // Check if email is valid
  isValidEmail(): boolean {
    if (!this.emailAddress) return false;
    
    const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    return emailRegex.test(this.emailAddress);
  }

  // Handle phone number input - only allow numbers and limit to 10 digits
  onPhoneInput(event: Event): void {
    const inputElement = event.target as HTMLInputElement;
    let value = inputElement.value;
    
    // Remove any non-digit characters
    const digitsOnly = value.replace(/\D/g, '');
    
    // Limit to 10 digits
    const truncated = digitsOnly.substring(0, 10);
    
    // Update the model value
    this.phoneNumber = truncated;
    
    // Update the input field value if it was changed
    if (value !== truncated) {
      inputElement.value = truncated;
    }
  }

  // Validate phone number
  validatePhone(): boolean {
    return this.isValidPhone();
  }

  // Check if phone number is valid (exactly 10 digits)
  isValidPhone(): boolean {
    if (!this.phoneNumber) return false;
    return this.phoneNumber.length === 10;
  }
  
  // Navigate to the previous step
  previousStep(): void {
    if (this.currentStep > 1) {
      this.currentStep--;
    }
  }
  
  // Navigate to the next step
  nextStep(): void {
    this.showErrors = true;
    
    if (this.validateForm()) {
      // Save data to session storage before navigating
      this.saveDataToStorage();
      
      // Navigate to the next step
      this.router.navigate(['/next-page']);
    }
  }
  
  // Save data to storage
  saveDataToStorage(): void {
    const basicInfo = {
      businessStatus: this.businessStatus,
      businessStructure: this.businessStructure,
      ownerFirstName: this.ownerFirstName,
      ownerLastName: this.ownerLastName,
      businessName: this.businessName,
      ownerFullName: `${this.ownerFirstName} ${this.ownerLastName}`,
      emailAddress: this.emailAddress,
      phoneNumber: this.phoneNumber
    };
    
    this.storageService.setItem('quoteBasicInfo', basicInfo);
  }
}