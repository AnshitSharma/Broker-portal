import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable, of, throwError } from 'rxjs';
import { catchError, map } from 'rxjs/operators';

// Client interface to match API response
export interface ApiClient {
  clientId: number;
  clientName: string;
  businessName: string;
  email: string;
  phone: string;
  status: string; // 'Active', 'Inactive', or 'Prospect'
  activePolicies: number;
}

export interface ApiResponse {
  success: boolean;
  message: string;
  data?: any;
}

@Injectable({
  providedIn: 'root'
})
export class ClientService {
  private apiUrl = 'https://localhost:7124/api/clients';
  
  // Fallback data in case API fails
  private fallbackClients: ApiClient[] = [
    {
      clientId: 12,
      clientName: "John Siddharth",
      businessName: "Tech Solutions LLC",
      email: "john@techsolutions.com",
      phone: "555-123-4567",
      status: "Prospect",
      activePolicies: 0
    },
    {
      clientId: 11,
      clientName: "John Smith",
      businessName: "Tech Solutions LLC",
      email: "john@techsolutions.com",
      phone: "555-123-4567",
      status: "Prospect",
      activePolicies: 0
    },
    {
      clientId: 10,
      clientName: "Sarah Williams", 
      businessName: "Artisan Bakery",
      email: "sarah@artisanbakery.com",
      phone: "555-234-5678",
      status: "Active",
      activePolicies: 2
    },
    {
      clientId: 9,
      clientName: "Michael Chen",
      businessName: "Chen Technology Solutions",
      email: "michael@chentechsolutions.com",
      phone: "555-345-6789",
      status: "Active",
      activePolicies: 3
    },
    {
      clientId: 8,
      clientName: "Emily Martinez",
      businessName: "Martinez Floral Design",
      email: "emily@martinezfloral.com",
      phone: "555-456-7890",
      status: "Inactive",
      activePolicies: 0
    }
  ];

  constructor(private http: HttpClient) {}

  /**
   * Get all clients from the API
   * Falls back to static data if API call fails
   */
  getClients(): Observable<ApiClient[]> {
    return this.http.get<ApiClient[]>(this.apiUrl).pipe(
      catchError(error => {
        console.error('Error fetching clients from API:', error);
        return of(this.fallbackClients);
      })
    );
  }

  /**
   * Get a specific client by ID
   * Falls back to static data if API call fails
   */
  getClient(id: number): Observable<ApiClient | null> {
    return this.http.get<ApiClient>(`${this.apiUrl}/${id}`).pipe(
      catchError(error => {
        console.error(`Error fetching client ${id} from API:`, error);
        const fallbackClient = this.fallbackClients.find(c => c.clientId === id) || null;
        return of(fallbackClient);
      })
    );
  }

  /**
   * Add a new client
   * Returns ApiResponse with success status and message
   */
  addClient(client: ApiClient): Observable<ApiResponse> {
    // Remove clientId before sending to API (will be assigned by server)
    const { clientId, ...clientData } = client;
    
    return this.http.post<ApiClient>(this.apiUrl, clientData).pipe(
      map(response => ({
        success: true,
        message: 'Client added successfully',
        data: response
      })),
      catchError(error => {
        console.error('Error adding client:', error);
        return of({
          success: false,
          message: error.error?.message || 'Failed to add client. Please try again.'
        });
      })
    );
  }

  /**
   * Update an existing client
   * Returns ApiResponse with success status and message
   */
  updateClient(client: ApiClient): Observable<ApiResponse> {
    return this.http.put<ApiClient>(`${this.apiUrl}/${client.clientId}`, {
      firstName: this.getFirstName(client.clientName),
      lastName: this.getLastName(client.clientName),
      businessName: client.businessName,
      email: client.email,
      phone: client.phone,
      status: client.status,
      activePolicies: client.activePolicies
    }).pipe(
      map(response => ({
        success: true,
        message: 'Client updated successfully',
        data: client // Use updated client data
      })),
      catchError(error => {
        console.error(`Error updating client ${client.clientId}:`, error);
        return of({
          success: false,
          message: error.error?.message || 'Failed to update client. Please try again.'
        });
      })
    );
  }

  /**
   * Delete a client
   * Returns ApiResponse with success status and message
   */
  deleteClient(id: number): Observable<ApiResponse> {
    return this.http.delete(`${this.apiUrl}/${id}`).pipe(
      map(() => ({
        success: true,
        message: 'Client deleted successfully'
      })),
      catchError(error => {
        console.error(`Error deleting client ${id}:`, error);
        return of({
          success: false,
          message: error.error?.message || 'Failed to delete client. Please try again.'
        });
      })
    );
  }

  /**
   * Helper method to extract first name from clientName
   */
  private getFirstName(clientName: string): string {
    const nameParts = clientName.split(' ');
    return nameParts[0] || '';
  }

  /**
   * Helper method to extract last name from clientName
   */
  private getLastName(clientName: string): string {
    const nameParts = clientName.split(' ');
    return nameParts.slice(1).join(' ') || '';
  }
}