import { Injectable } from '@angular/core';
import {
  HttpRequest,
  HttpHandler,
  HttpEvent,
  HttpInterceptor,
  HttpErrorResponse
} from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { Router } from '@angular/router';
import { AuthService } from './auth.service';

@Injectable()
export class AuthInterceptor implements HttpInterceptor {
  constructor(private authService: AuthService, private router: Router) {}

  intercept(request: HttpRequest<unknown>, next: HttpHandler): Observable<HttpEvent<unknown>> {
    // Get the auth token from the service
    const token = this.authService.getToken();
    
    // Clone the request and add the token if available
    if (token) {
      request = request.clone({
        setHeaders: {
          Authorization: `Bearer ${token}`
        }
      });
    }
    
    // Handle the request and catch any errors
    return next.handle(request).pipe(
      catchError((error: HttpErrorResponse) => {
        // Handle 401 Unauthorized errors - token expired or invalid
        if (error.status === 401) {
          // Automatically log the user out
          this.authService.logout();
          this.router.navigate(['/login'], { 
            state: { 
              message: 'Your session has expired. Please log in again.' 
            } 
          });
        }
        
        // Create a more user-friendly error message
        let errorMessage = 'An unknown error occurred';
        
        if (error.error instanceof ErrorEvent) {
          // Client-side error
          errorMessage = error.error.message;
        } else if (typeof error.error === 'object' && error.error !== null) {
          // If server returns error object with message property
          errorMessage = error.error.message || error.statusText;
          
          // If server returns validation errors in a specific format
          if (error.error.errors) {
            // Format validation errors into a readable string
            const validationErrors = error.error.errors;
            const errors = [];
            
            for (const key in validationErrors) {
              if (validationErrors.hasOwnProperty(key)) {
                errors.push(validationErrors[key]);
              }
            }
            
            if (errors.length > 0) {
              errorMessage = errors.join(' ');
            }
          }
        } else if (typeof error.error === 'string') {
          // If error is just a string
          errorMessage = error.error;
        } else {
          // Default to HTTP status text
          errorMessage = error.statusText;
        }
        
        // Return the error so components can handle it
        return throwError(() => errorMessage);
      })
    );
  }
}