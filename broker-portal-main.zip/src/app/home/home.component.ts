import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { TestimonialCarouselComponent } from '../shared/testimonial-carousel/testimonial-carousel.component';

interface FaqItem {
  question: string;
  answer: string;
  iconType: 'shield' | 'alert' | 'package' | 'scale' | 'calendar' | 'building' | 'file';
}

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [CommonModule, FormsModule, TestimonialCarouselComponent],
  templateUrl: './home.component.html',
  styleUrl: './home.component.css'
})
export class HomeComponent {
  // Track which FAQ item is open
  openIndex: number | null = null;
  
  // FAQ data with icons
  faqItems: FaqItem[] = [
    {
      question: "Why Is General Liability Needed?",
      answer: "General liability insurance protects your business from financial loss if you're held responsible for property damage, bodily injuries, or advertising injury claims. It covers legal defense costs and settlements, protecting your business assets from potentially devastating lawsuits.",
      iconType: 'shield'
    },
    {
      question: "What Does a General Liability Policy Not Cover?",
      answer: "General liability typically doesn't cover employee injuries (covered by workers' compensation), professional errors (covered by professional liability), damage to your own property (covered by commercial property insurance), or intentional acts of wrongdoing. It also doesn't cover data breaches, vehicle accidents, or employee disputes.",
      iconType: 'alert'
    },
    {
      question: "Can I Bundle General Liability With Other Types of Insurance?",
      answer: "Yes, many insurance providers offer Business Owner's Policies (BOPs) that bundle general liability with property insurance and sometimes other coverages at a discounted rate. This is often more cost-effective than purchasing separate policies and provides more comprehensive protection.",
      iconType: 'package'
    },
    {
      question: "Is General Liability Business Insurance Required by Law?",
      answer: "While not universally required by federal law, some states and municipalities may require certain businesses to carry general liability insurance. Additionally, many client contracts, commercial leases, and loan agreements require proof of general liability coverage.",
      iconType: 'scale'
    },
    {
      question: "What Types of Events Can General Liability Insurance Help Pay For?",
      answer: "General liability insurance typically covers bodily injury claims (customer slips and falls), property damage claims (employee damages client property), reputational harm (slander or libel claims), advertising injury (copyright infringement), and legal defense costs regardless of fault.",
      iconType: 'calendar'
    },
    {
      question: "Do You Need Business Liability Insurance for an LLC?",
      answer: "Yes, while an LLC structure helps protect your personal assets from business liabilities, it doesn't protect your business assets from lawsuits. General liability insurance provides that additional layer of protection for your business investments and is recommended even for LLCs.",
      iconType: 'building'
    },
    {
      question: "What Information Do I Need To Get a General Liability Quote?",
      answer: "To get a quote, you'll typically need: basic business information (name, address, structure), details about your operations, number of employees, annual revenue, claims history, and specifics about your industry and services provided. More detailed information helps ensure accurate coverage and pricing.",
      iconType: 'file'
    }
  ];

  constructor(private router: Router) {
    // No FontAwesome loading needed here
  }
  
  // Method for quote request form submission
  requestQuote(): void {
    // This would handle the quote request form submission
    console.log('Quote requested');
    this.router.navigate(['/insurance']);
  }
  
  // Method to navigate to different sections
  scrollToSection(sectionId: string): void {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  }

  /**
   * Toggle the open/closed state of an FAQ item
   */
  toggleItem(index: number): void {
    if (this.openIndex === index) {
      // If clicking already open item, close it
      this.openIndex = null;
    } else {
      // Open the clicked item
      this.openIndex = index;
    }
  }

  /**
   * Contact our experts
   */
  contactExperts(): void {
    console.log('Contact experts');
    // You could implement a contact form or modal here
    // For now, navigate to insurance quote page as a placeholder action
    this.router.navigate(['/insurance']);
  }
}