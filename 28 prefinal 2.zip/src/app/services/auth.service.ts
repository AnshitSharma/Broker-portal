import { Injectable, PLATFORM_ID, Inject } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Router } from '@angular/router';
import { BehaviorSubject, Observable, throwError } from 'rxjs';
import { catchError, map, tap } from 'rxjs/operators';
import { isPlatformBrowser, isPlatformServer } from '@angular/common';

// User model
export interface User {
  id: string;
  email: string;
  name: string;
  role: string;
  firstName?: string;
  lastName?: string;
  username?: string;
}

// User data for UI display
export interface UserData {
  id: string;
  email: string;
  firstName?: string;
  lastName?: string;
  username?: string;
  role: string;
  name: string;
}

// Authentication response model
export interface AuthResponse {
  user: User;
  token: string;
  expiresIn: number;
}

// Login credentials model
export interface LoginCredentials {
  email: string;
  password: string;
}

// Login request model - for compatibility with your login component
export interface LoginRequest {
  email: string;
  password: string;
}

// Registration credentials model
export interface RegistrationCredentials {
  email: string;
  password: string;
  name: string;
}

// Register request model - for compatibility with your register component
export interface RegisterRequest {
  firstName: string;
  lastName: string;
  email: string;
  password: string;
}

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private readonly API_URL = 'http://localhost:7124/api/auth';
  private readonly TOKEN_KEY = 'auth_token';
  private readonly USER_KEY = 'auth_user';
  private readonly EXPIRATION_KEY = 'auth_expiration';
  
  private tokenExpirationTimer: any;
  private currentUserSubject = new BehaviorSubject<User | null>(null);
  private isBrowser: boolean;
  
  // In-memory storage for server-side rendering
  private memoryStorage: Map<string, string> = new Map();
  
  currentUser$ = this.currentUserSubject.asObservable();
  
  constructor(
    private http: HttpClient,
    private router: Router,
    @Inject(PLATFORM_ID) private platformId: Object
  ) {
    this.isBrowser = isPlatformBrowser(this.platformId);
    
    // Only check auth status if we're in a browser environment
    if (this.isBrowser) {
      this.checkAuthStatus();
    }
  }
  
  /**
   * Login user with email and password
   */
  login(credentials: LoginRequest): Observable<User> {
    // Convert from LoginRequest to LoginCredentials if needed
    const loginCredentials: LoginCredentials = {
      email: credentials.email,
      password: credentials.password
    };
    
    return this.http.post<AuthResponse>(`${this.API_URL}/login`, loginCredentials)
      .pipe(
        tap(response => {
          console.log('Auth response:', response);
          this.handleAuthSuccess(response);
        }),
        map(response => response.user),
        catchError(this.handleError.bind(this))
      );
  }
  
  /**
   * Register a new user
   */
  register(credentials: RegisterRequest): Observable<User> {
    // Convert from RegisterRequest to format expected by the API
    const registrationCredentials: RegistrationCredentials = {
      email: credentials.email,
      password: credentials.password,
      name: `${credentials.firstName} ${credentials.lastName}`
    };
    
    return this.http.post<AuthResponse>(`${this.API_URL}/register`, registrationCredentials)
      .pipe(
        tap(response => this.handleAuthSuccess(response)),
        map(response => response.user),
        catchError(this.handleError.bind(this))
      );
  }
  
  /**
   * Log the user out
   */
  logout(): void {
    // Clear all auth data from storage
    this.removeItem(this.TOKEN_KEY);
    this.removeItem(this.USER_KEY);
    this.removeItem(this.EXPIRATION_KEY);
    
    // Clear the user subject
    this.currentUserSubject.next(null);
    
    // Clear any existing expiration timer
    if (this.tokenExpirationTimer) {
      clearTimeout(this.tokenExpirationTimer);
      this.tokenExpirationTimer = null;
    }
    
    // Redirect to login page
    this.router.navigate(['/login']);
  }
  
  /**
   * Get the authentication token
   */
  getToken(): string | null {
    return this.getItem(this.TOKEN_KEY);
  }
  
  /**
   * Check if the user is authenticated
   */
  isAuthenticated(): boolean {
    const token = this.getToken();
    const isExpired = this.isTokenExpired();
    return !!token && !isExpired;
  }
  
  /**
   * Get the current authenticated user
   */
  getCurrentUser(): User | null {
    const userJson = this.getItem(this.USER_KEY);
    return userJson ? JSON.parse(userJson) : null;
  }
  
  /**
   * Get user data for UI display
   * This method is specifically for the navbar and other UI components
   */
  getUserData(): UserData | null {
    const user = this.getCurrentUser();
    if (!user) return null;
    
    // Extract the first name and last name from the name if available
    let firstName = user.firstName;
    let lastName = user.lastName;
    
    if (!firstName && user.name) {
      const nameParts = user.name.split(' ');
      firstName = nameParts[0];
      if (nameParts.length > 1) {
        lastName = nameParts.slice(1).join(' ');
      }
    }
    
    return {
      id: user.id,
      email: user.email,
      firstName: firstName,
      lastName: lastName,
      username: user.username || user.email.split('@')[0],
      role: user.role,
      name: user.name
    };
  }
  
  /**
   * Check if user has a specific role
   */
  hasRole(role: string): boolean {
    const user = this.getCurrentUser();
    return !!user && user.role === role;
  }
  
  /**
   * Check if token is expired
   */
  private isTokenExpired(): boolean {
    const expirationTime = this.getItem(this.EXPIRATION_KEY);
    if (!expirationTime) {
      return true;
    }
    
    return new Date().getTime() > parseInt(expirationTime, 10);
  }
  
  /**
   * Handle successful authentication
   */
  private handleAuthSuccess(response: AuthResponse): void {
    const { token, user, expiresIn } = response;
    
    console.log('Handling auth success:', { token: token ? 'exists' : 'missing', user, expiresIn });
    
    // Save token and user to storage
    this.setItem(this.TOKEN_KEY, token);
    this.setItem(this.USER_KEY, JSON.stringify(user));
    
    // Calculate and store expiration time
    const expirationDate = new Date().getTime() + expiresIn * 1000;
    this.setItem(this.EXPIRATION_KEY, expirationDate.toString());
    
    // Set auto logout timer
    if (this.isBrowser) {
      this.setAutoLogoutTimer(expiresIn * 1000);
    }
    
    // Update the user subject
    this.currentUserSubject.next(user);
  }
  
  /**
   * Set timer for auto logout when token expires
   */
  private setAutoLogoutTimer(expirationDuration: number): void {
    this.tokenExpirationTimer = setTimeout(() => {
      this.logout();
    }, expirationDuration);
  }
  
  /**
   * Check authentication status on application init
   */
  private checkAuthStatus(): void {
    const token = this.getToken();
    const user = this.getCurrentUser();
    
    if (token && user && !this.isTokenExpired()) {
      // User is authenticated, set the current user subject
      this.currentUserSubject.next(user);
      
      // Calculate remaining token time and set auto logout
      const expirationTime = this.getItem(this.EXPIRATION_KEY);
      if (expirationTime) {
        const expiresIn = parseInt(expirationTime, 10) - new Date().getTime();
        if (expiresIn > 0) {
          this.setAutoLogoutTimer(expiresIn);
        }
      }
    } else if (this.isTokenExpired()) {
      // Token is expired, log the user out
      this.logout();
    }
  }
  
  /**
   * Handle HTTP errors
   */
  private handleError(error: HttpErrorResponse) {
    let errorMessage = 'An unknown error occurred';
    
    if (error.error instanceof ErrorEvent) {
      // Client-side error
      errorMessage = `Error: ${error.error.message}`;
    } else {
      // Server-side error
      if (error.status === 401) {
        errorMessage = 'Invalid credentials. Please try again.';
      } else if (error.status === 403) {
        errorMessage = 'Access denied. You do not have permission to perform this action.';
      } else if (error.status === 404) {
        errorMessage = 'The requested resource was not found.';
      } else if (error.error && error.error.message) {
        errorMessage = error.error.message;
      }
    }
    
    console.error('Auth error:', error);
    return throwError(() => new Error(errorMessage));
  }
  
  /**
   * Safe wrapper for localStorage.getItem that works in both browser and server
   */
  private getItem(key: string): string | null {
    if (this.isBrowser) {
      return localStorage.getItem(key);
    } else {
      return this.memoryStorage.get(key) || null;
    }
  }
  
  /**
   * Safe wrapper for localStorage.setItem that works in both browser and server
   */
  private setItem(key: string, value: string): void {
    if (this.isBrowser) {
      localStorage.setItem(key, value);
    } else {
      this.memoryStorage.set(key, value);
    }
  }
  
  
  private removeItem(key: string): void {
    if (this.isBrowser) {
      localStorage.removeItem(key);
    } else {
      this.memoryStorage.delete(key);
    }
  }
}