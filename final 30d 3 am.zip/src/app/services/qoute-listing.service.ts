import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, catchError, of } from 'rxjs';

export interface QuoteListItem {
  quoteId: string;
  quoteNumber: string;
  clientName: string;
  businessName: string;
  createdDate: string;
  coverageType: string;
  premium: number;
  status: 'pending' | 'approved' | 'declined' | 'bound';
}

@Injectable({
  providedIn: 'root'
})
export class QuoteService {
  private apiUrl = 'http://localhost:5075/api/insurance-quotes'; // Replace with your API URL

  constructor(private http: HttpClient) { }

  /**
   * Get all quotes from the API
   * @returns Observable of quote list items
   */
  getQuotes(): Observable<QuoteListItem[]> {
    return this.http.get<QuoteListItem[]>(this.apiUrl)
      .pipe(
        catchError(error => {
          console.error('Error fetching quotes:', error);
          return of([]); // Return empty array if API fails
        })
      );
  }

  /**
   * Get quote by ID
   * @param id The quote ID
   * @returns Observable of the quote list item
   */
  getQuoteById(id: string): Observable<QuoteListItem | null> {
    return this.http.get<QuoteListItem>(`${this.apiUrl}/${id}`)
      .pipe(
        catchError(error => {
          console.error(`Error fetching quote ${id}:`, error);
          return of(null);
        })
      );
  }

  /**
   * Create a new quote
   * @param quote The quote to create
   * @returns Observable of the created quote
   */
  createQuote(quote: Partial<QuoteListItem>): Observable<QuoteListItem | null> {
    return this.http.post<QuoteListItem>(this.apiUrl, quote)
      .pipe(
        catchError(error => {
          console.error('Error creating quote:', error);
          return of(null);
        })
      );
  }

  /**
   * Update an existing quote
   * @param id The quote ID
   * @param quote The updated quote data
   * @returns Observable of the updated quote
   */
  updateQuote(id: string, quote: Partial<QuoteListItem>): Observable<QuoteListItem | null> {
    return this.http.put<QuoteListItem>(`${this.apiUrl}/${id}`, quote)
      .pipe(
        catchError(error => {
          console.error(`Error updating quote ${id}:`, error);
          return of(null);
        })
      );
  }

  /**
   * Delete a quote
   * @param id The quote ID to delete
   * @returns Observable of operation success
   */
  deleteQuote(id: string): Observable<boolean> {
    return this.http.delete<void>(`${this.apiUrl}/${id}`)
      .pipe(
        catchError(error => {
          console.error(`Error deleting quote ${id}:`, error);
          return of(false);
        }),
        // Convert successful response to boolean
        _ => of(true)
      );
  }
}