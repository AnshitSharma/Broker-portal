import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { AuthService, LoginRequest } from '../../services/auth.service';

interface LoginData {
  email: string;
  password: string;
  rememberMe: boolean;
}

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule, HttpClientModule],
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  loginData: LoginData = {
    email: '',
    password: '',
    rememberMe: false
  };

  loading: boolean = false;
  submitted: boolean = false;
  showPassword: boolean = false;
  errorMessage: string = '';
  successMessage: string = '';

  constructor(private router: Router, private authService: AuthService) { }

  ngOnInit(): void {
    // Check if user is already logged in
    if (this.authService.isAuthenticated()) {
      this.router.navigate(['/home']);
      return;
    }
    
    // Get success message from router state if it exists
    const navigation = this.router.getCurrentNavigation();
    if (navigation?.extras?.state) {
      const state = navigation.extras.state as {message: string};
      if (state.message) {
        this.successMessage = state.message;
      }
    }
    
    // Check if email is remembered from localStorage
    const rememberedEmail = localStorage.getItem('rememberedEmail');
    if (rememberedEmail) {
      this.loginData.email = rememberedEmail;
      this.loginData.rememberMe = true;
    }
  }

  togglePasswordVisibility(): void {
    this.showPassword = !this.showPassword;
  }

  onSubmit(): void {
    this.submitted = true;
    this.errorMessage = '';
    
    // Validate the form
    if (!this.loginData.email || !this.loginData.password) {
      return;
    }

    this.loading = true;

    // Prepare login request
    const loginRequest: LoginRequest = {
      email: this.loginData.email,
      password: this.loginData.password
    };

    // Call authentication service
    this.authService.login(loginRequest).subscribe({
      next: (response) => {
        // Handle remember me
        if (this.loginData.rememberMe) {
          localStorage.setItem('rememberedEmail', this.loginData.email);
        } else {
          localStorage.removeItem('rememberedEmail');
        }

        // Navigate to home page after successful login
        this.router.navigate(['/home']);
      },
      error: (error) => {
        this.errorMessage = error.message || 'Login failed. Please try again.';
        this.loading = false;
      },
      complete: () => {
        this.loading = false;
      }
    });
  }
}