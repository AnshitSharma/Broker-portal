import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { AuthService, LoginRequest } from '../../services/auth.service';

interface LoginData {
  email: string;
  password: string;
  rememberMe: boolean;
}

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule, HttpClientModule],
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  loginData: LoginData = {
    email: '',
    password: '',
    rememberMe: false
  };

  loading: boolean = false;
  submitted: boolean = false;
  showPassword: boolean = false;
  errorMessage: string = '';
  successMessage: string = '';

  constructor(public router: Router, private authService: AuthService) { }

  ngOnInit(): void {
    // Get success message from router state if it exists
    const navigation = this.router.getCurrentNavigation();
    if (navigation?.extras?.state) {
      const state = navigation.extras.state as {message: string};
      this.successMessage = state.message;
    }
    
    // Check if user is already logged in from localStorage
    const rememberedEmail = localStorage.getItem('rememberedEmail');
    if (rememberedEmail) {
      this.loginData.email = rememberedEmail;
      this.loginData.rememberMe = true;
    }

    // Add particle animation to background
    this.initializeBackground();
  }

  togglePasswordVisibility(): void {
    this.showPassword = !this.showPassword;
  }

  onSubmit(): void {
    this.submitted = true;
    
    // Validate the form
    if (!this.loginData.email || !this.loginData.password) {
      return;
    }

    this.loading = true;
    this.errorMessage = '';

    // Prepare login request
    const loginRequest: LoginRequest = {
      email: this.loginData.email,
      password: this.loginData.password
    };

    // Call API service
    this.authService.login(loginRequest).subscribe({
      next: (response) => {
        // Store email in localStorage if remember me is checked
        if (this.loginData.rememberMe) {
          localStorage.setItem('rememberedEmail', this.loginData.email);
        } else {
          localStorage.removeItem('rememberedEmail');
        }

        // Navigate to home page after successful login
        this.router.navigate(['/home']);
        console.log('Login successful', response);
      },
      error: (error) => {
        this.errorMessage = typeof error === 'string' ? error : 'Login failed. Please check your credentials.';
        this.loading = false;
        console.error('Login error:', error);
      },
      complete: () => {
        this.loading = false;
      }
    });
  }

  // Initialize background effects
  private initializeBackground(): void {
    // This would normally create animated particles using a library like particles.js
    // For now, we'll use CSS effects only to keep things simple
    console.log('Background animation initialized');
  }
}