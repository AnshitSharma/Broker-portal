import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

interface QuoteResponse {
  message: string;
  quoteId: number;
  ownerName?: string;
  businessName?: string;
  email?: string;
  phone?: string;
  hasAdditionalServices?: boolean;
  hasClaimsHistory?: boolean;
  claimCount?: number;
  isHazardous?: boolean;
  annualPremium?: number;
  monthlyPremium?: number;
  createdDate?: string;
  status: string;
  clientId?: number;
  client?: {
    clientId: number;
    name: string;
    businessName: string;
    email: string;
    phone: string;
  };
  [key: string]: any; // Allow any additional properties
}

@Component({
  selector: 'app-quote-preview',
  standalone: true,
  templateUrl: './qoutepreview.component.html',
  styleUrls: ['./qoutepreview.component.css'],
  imports: [CommonModule, FormsModule]
})
export class QuotePreviewComponent implements OnInit {
  // The API response data
  quoteResponse: QuoteResponse | null = null;
 
  // UI state
  isLoading: boolean = true;
  noData: boolean = false;
 
  constructor(private router: Router) {}
 
  ngOnInit(): void {
    // Try to load the API response from session storage
    this.loadApiResponse();
   
    // Set timeout to simulate loading state for better UX
    setTimeout(() => {
      this.isLoading = false;
    }, 1000);
  }
 
  /**
   * Load the API response from sessionStorage
   */
  loadApiResponse(): void {
    const responseData = sessionStorage.getItem('quoteApiResponse');
   
    if (responseData) {
      try {
        this.quoteResponse = JSON.parse(responseData);
        console.log('Loaded API response:', this.quoteResponse);
        
        // Ensure premium values are properly formatted if they exist
        if (this.quoteResponse) {
          // If monthlyPremium doesn't exist but annualPremium does, calculate it
          if (this.quoteResponse.annualPremium && !this.quoteResponse.monthlyPremium) {
            this.quoteResponse.monthlyPremium = parseFloat((this.quoteResponse.annualPremium / 12).toFixed(2));
          }
          
          // If annualPremium doesn't exist but monthlyPremium does, calculate it
          if (!this.quoteResponse.annualPremium && this.quoteResponse.monthlyPremium) {
            this.quoteResponse.annualPremium = parseFloat((this.quoteResponse.monthlyPremium * 12).toFixed(2));
          }
        }
      } catch (error) {
        console.error('Error parsing API response:', error);
        this.noData = true;
      }
    } else {
      this.noData = true;
    }
  }
 
  /**
   * Format date string for display
   */
  formatDate(dateString?: string): string {
    if (!dateString) return 'N/A';
   
    try {
      const date = new Date(dateString);
      return date.toLocaleDateString() + ' ' + date.toLocaleTimeString();
    } catch (error) {
      return dateString;
    }
  }
 
  /**
   * Navigate to home page
   */
  goToHome(): void {
    // Clear session storage
    this.clearSessionData();
   
    // Navigate to home
    this.router.navigate(['/']);
  }
 
  /**
   * Start a new quote
   */
  startNewQuote(): void {
    // Clear session storage
    this.clearSessionData();
   
    // Navigate to first step
    this.router.navigate(['/insurance']);
  }
  
  /**
   * Clear all session data related to quotes
   */
  private clearSessionData(): void {
    sessionStorage.removeItem('quoteApiResponse');
    sessionStorage.removeItem('selectedCoverages');
    sessionStorage.removeItem('totalPrice');
    sessionStorage.removeItem('coverageSelections');
    sessionStorage.removeItem('quoteBasicInfo');
    sessionStorage.removeItem('quoteLocationInfo');
    sessionStorage.removeItem('insurance_quote_data');
  }
}