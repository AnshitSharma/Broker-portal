import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, Subject, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class PasswordChangeService {
  private readonly API_URL = 'https://localhost:7124/api/Users/change-password';
  
  // Subject to trigger modal opening from anywhere in the app
  private openModalSubject = new Subject<void>();
  openModal$ = this.openModalSubject.asObservable();
  
  constructor(private http: HttpClient) {}
  
  /**
   * Change user's password
   * @param email User's email
   * @param currentPassword Current password
   * @param newPassword New password
   */
  changePassword(email: string, currentPassword: string, newPassword: string): Observable<any> {
    const request = {
      email,
      currentPassword,
      newPassword
    };
    
    return this.http.post(this.API_URL, request)
      .pipe(
        catchError(this.handleError)
      );
  }
  
  /**
   * Open the password change modal
   */
  openPasswordChangeModal(): void {
    this.openModalSubject.next();
  }
  
  /**
   * Handle HTTP errors
   */
  private handleError(error: any) {
    let errorMessage = 'An unknown error occurred while changing password';
    
    if (error.error instanceof ErrorEvent) {
      // Client-side error
      errorMessage = `Error: ${error.error.message}`;
    } else {
      // Server-side error
      if (error.status === 401) {
        errorMessage = 'Current password is incorrect. Please try again.';
      } else if (error.status === 400) {
        // Try to extract validation errors
        if (error.error && typeof error.error === 'string') {
          errorMessage = error.error;
        } else if (error.error && typeof error.error === 'object') {
          const validationErrors = [];
          for (const key in error.error) {
            if (error.error.hasOwnProperty(key)) {
              validationErrors.push(error.error[key]);
            }
          }
          if (validationErrors.length > 0) {
            errorMessage = validationErrors.join(' ');
          }
        }
      } else if (error.status === 404) {
        errorMessage = 'User with this email was not found.';
      }
    }
    
    return throwError(() => new Error(errorMessage));
  }
}