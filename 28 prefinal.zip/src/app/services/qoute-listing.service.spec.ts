import { TestBed } from '@angular/core/testing';

import { QouteListingService } from './qoute-listing.service';

describe('QouteListingService', () => {
  let service: QouteListingService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(QouteListingService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
