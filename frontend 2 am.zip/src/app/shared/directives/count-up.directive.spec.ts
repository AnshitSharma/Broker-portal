import { CountUpDirective } from './count-up.directive';

describe('CountUpDirective', () => {
  it('should create an instance', () => {
    const directive = new CountUpDirective();
    expect(directive).toBeTruthy();
  });
});
