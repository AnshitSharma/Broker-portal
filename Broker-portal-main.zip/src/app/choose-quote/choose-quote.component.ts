import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { StorageService } from '../services/storage.ts.service';

interface InsuranceQuote {
  id: string;
  companyName: string;
  companyLogo: string;
  tagline: string;
  lifeAmount: string;
  claimSettlement: string;
  price: string;
  priceMonthly: number;
  maxLimit: string;
  features: string[];
  discount: string;
  specialFeature?: string;
}

@Component({
  selector: 'app-choose-quote',
  standalone: true,
  templateUrl: './choose-quote.component.html',
  styleUrls: ['./choose-quote.component.css'],
  imports: [CommonModule, FormsModule, RouterModule]
})
export class ChooseQuoteComponent implements OnInit {
  // Array of insurance quotes from different companies
  availableQuotes: InsuranceQuote[] = [
    {
      id: 'icici-prudential',
      companyName: 'ICICI Prudential',
      companyLogo: 'assets/images/logos/icici-prudential.png',
      tagline: 'iProtect Smart',
      lifeAmount: '₹ 1 Cr',
      claimSettlement: '99.17%',
      price: '₹ 598/month',
      priceMonthly: 598,
      maxLimit: 'Max Limit: 99 yrs',
      features: [
        'Highest claims settled worth ₹1950 Crores in FY22',
        '100% payout on Terminal illness free',
        'Waiver of premium on permanent accidental disability free'
      ],
      discount: '16.5 K'
    },
    {
      id: 'hdfc-life',
      companyName: 'HDFC Life',
      companyLogo: 'assets/images/logos/hdfc-life.png',
      tagline: 'Click 2 Protect Super',
      lifeAmount: '₹ 1 Cr',
      claimSettlement: '99.5%',
      price: '₹ 749/month',
      priceMonthly: 749,
      maxLimit: 'Max Limit: 85 yrs',
      features: [
        'Early Payout On Terminal Illness free',
        'Extend your policy at Maturity free'
      ],
      discount: '10.4 K'
    },
    {
      id: 'axis-max',
      companyName: 'Axis Max',
      companyLogo: 'assets/images/logos/axis-max.png',
      tagline: 'Smart Term Plan Plus',
      lifeAmount: '₹ 1 Cr',
      claimSettlement: '99.7%',
      price: '₹ 659/month',
      priceMonthly: 659,
      maxLimit: 'Max Limit: 85 yrs',
      features: [
        'Early payout on Terminal illness free',
        'Option to delay 12 Months Premium free',
        'Lifeline Plus(Option to increase life cover) free'
      ],
      discount: '9.8 K'
    },
    {
      id: 'tata-aia',
      companyName: 'Tata AIA',
      companyLogo: 'assets/images/logos/tata-aia.png',
      tagline: 'Sampoorna Raksha Promise',
      lifeAmount: '₹ 1 Cr',
      claimSettlement: '99.13%',
      price: '₹ 649/month',
      priceMonthly: 649,
      maxLimit: 'Max Limit: 100 yrs',
      features: [
        'Option to delay 12 months premium free',
        'Waiver of premium on Terminal Illness free',
        'Early payout on Terminal Illness free'
      ],
      discount: '10.8 K'
    },
    {
      id: 'bajaj-allianz',
      companyName: 'Bajaj Allianz Life',
      companyLogo: 'assets/images/logos/bajaj-allianz.png',
      tagline: 'e Touch II',
      lifeAmount: '₹ 1 Cr',
      claimSettlement: '99.23%',
      price: '₹ 487/month',
      priceMonthly: 487,
      maxLimit: 'Max Limit: 85 yrs',
      features: [
        'Coverage till 99 years of age',
        'Option for regular income along with lump sum',
        'Return of Premium option'
      ],
      discount: '10.6 K'
    }
  ];

  selectedQuoteId: string | null = null;

  constructor(
    private router: Router,
    private storageService: StorageService
  ) {}

  ngOnInit(): void {
    // Try to load previously selected quote from session storage
    this.loadSelectedQuote();
    
    // Sort quotes by monthly price (ascending)
    this.sortQuotes('price-asc');
  }
  
  /**
   * Load previously selected quote from session storage
   */
  loadSelectedQuote(): void {
    const savedQuote = this.storageService.getItem('selectedQuote');
    if (savedQuote && savedQuote.id) {
      this.selectedQuoteId = savedQuote.id;
    }
  }

  /**
   * Event handler for sort dropdown change
   */
  onSortChange(event: Event): void {
    const target = event.target as HTMLSelectElement;
    if (target) {
      this.sortQuotes(target.value);
    }
  }

  /**
   * Sort quotes based on different criteria
   */
  sortQuotes(criteria: string): void {
    switch (criteria) {
      case 'price-asc':
        this.availableQuotes.sort((a, b) => a.priceMonthly - b.priceMonthly);
        break;
      case 'price-desc':
        this.availableQuotes.sort((a, b) => b.priceMonthly - a.priceMonthly);
        break;
      case 'claim-settlement':
        this.availableQuotes.sort((a, b) => {
          return parseFloat(b.claimSettlement.replace('%', '')) - 
                 parseFloat(a.claimSettlement.replace('%', ''));
        });
        break;
      case 'company':
        this.availableQuotes.sort((a, b) => a.companyName.localeCompare(b.companyName));
        break;
    }
  }

  /**
   * Select a quote
   */
  selectQuote(quoteId: string): void {
    this.selectedQuoteId = quoteId;
    
    // Save the selection to session storage right away
    this.saveSelectedQuote();
  }
  
  /**
   * Save the selected quote to session storage
   */
  saveSelectedQuote(): void {
    if (this.selectedQuoteId) {
      const selectedQuote = this.availableQuotes.find(q => q.id === this.selectedQuoteId);
      if (selectedQuote) {
        this.storageService.setItem('selectedQuote', selectedQuote);
      }
    }
  }

  /**
   * Get company name of selected quote
   */
  getSelectedQuoteCompanyName(): string {
    if (!this.selectedQuoteId) return '';
    
    const quote = this.availableQuotes.find(q => q.id === this.selectedQuoteId);
    return quote ? quote.companyName : '';
  }

  /**
   * Proceed with the selected quote
   */
  proceedWithQuote(): void {
    if (!this.selectedQuoteId) {
      alert('Please select a quote to proceed');
      return;
    }

    // Find the selected quote
    const selectedQuote = this.availableQuotes.find(q => q.id === this.selectedQuoteId);
    
    // Store the selected quote in sessionStorage
    if (selectedQuote) {
      this.storageService.setItem('selectedQuote', selectedQuote);
    }
    
    // Navigate to quote summary with the selected quote
    this.router.navigate(['/quote-summary']);
  }

  /**
   * Compare features between quotes
   */
  compareQuotes(): void {
    // In a real application, this would navigate to a comparison view
    // For now, we'll just create a simple alert
    alert('Compare quotes feature will be implemented soon');
  }
}