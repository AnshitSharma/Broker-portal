import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators, AbstractControl, ValidationErrors } from '@angular/forms';
import { Router, RouterModule } from '@angular/router';
import { AuthService, RegisterRequest } from '../../services/auth.service';

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterModule],
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  registerForm!: FormGroup;
  isLoading: boolean = false;
  errorMessage: string = '';
  registrationSuccess: boolean = false;
 
  constructor(
    private fb: FormBuilder,
    private authService: AuthService,
    private router: Router
  ) {}
 
  ngOnInit(): void {
    // Redirect to home if already logged in
    if (this.authService.isAuthenticated()) {
      this.router.navigate(['/']);
      return;
    }
   
    // Initialize the registration form
    this.registerForm = this.fb.group({
      firstName: ['', [Validators.required, this.nameValidator]],
      lastName: ['', [Validators.required, this.nameValidator]],
      username: ['', [Validators.required, Validators.minLength(3)]],
      email: ['', [Validators.required, Validators.email]],
      company: [''],
      phoneNumber: ['', [this.phoneNumberValidator]],
      password: ['', [Validators.required, Validators.minLength(6)]],
      confirmPassword: ['', [Validators.required]],
      agreeTerms: [false, [Validators.requiredTrue]]
    }, {
      validators: this.passwordMatchValidator
    });
  }
  
  // Custom validator to ensure names don't contain numbers
  nameValidator(control: AbstractControl): ValidationErrors | null {
    const name = control.value;
    
    if (!name) {
      return null;
    }
    
    // Check if the name contains any numbers
    if (/\d/.test(name)) {
      return { containsNumber: true };
    }
    
    return null;
  }
  
  // Custom validator to ensure phone numbers only contain numbers, spaces, and specific symbols
  phoneNumberValidator(control: AbstractControl): ValidationErrors | null {
    const phoneNumber = control.value;
    
    if (!phoneNumber) {
      return null; // Allow empty phone numbers
    }
    
    // Allow digits, spaces, and these symbols: +()-
    if (!/^[0-9\s()+\-]*$/.test(phoneNumber)) {
      return { invalidPhoneNumber: true };
    }
    
    return null;
  }
 
  // Custom validator to check if passwords match
  passwordMatchValidator(form: FormGroup) {
    const password = form.get('password');
    const confirmPassword = form.get('confirmPassword');
   
    if (password && confirmPassword && password.value !== confirmPassword.value) {
      confirmPassword.setErrors({ passwordMismatch: true });
      return { passwordMismatch: true };
    }
    
    // If passwords match but confirmPassword has the passwordMismatch error, clear it
    if (password && confirmPassword && password.value === confirmPassword.value) {
      // Get any other errors that might exist
      const otherErrors = { ...confirmPassword.errors };
      if (otherErrors) {
        delete otherErrors['passwordMismatch'];
        confirmPassword.setErrors(Object.keys(otherErrors).length ? otherErrors : null);
      }
    }
   
    return null;
  }
 
  onSubmit(): void {
    if (this.registerForm.invalid) {
      this.registerForm.markAllAsTouched();
      return;
    }
   
    this.isLoading = true;
    this.errorMessage = '';
    this.registrationSuccess = false;
   
    const registerData: RegisterRequest = {
      firstName: this.registerForm.value.firstName,
      lastName: this.registerForm.value.lastName,
      username: this.registerForm.value.username,
      email: this.registerForm.value.email,
      company: this.registerForm.value.company || '',
      phoneNumber: this.registerForm.value.phoneNumber || '',
      password: this.registerForm.value.password,
      confirmPassword: this.registerForm.value.confirmPassword
    };
   
    this.authService.register(registerData).subscribe({
      next: (response) => {
        console.log('Registration successful:', response);
        this.isLoading = false;
        this.registrationSuccess = true;
        
        // Wait for 2 seconds before redirecting to login
        setTimeout(() => {
          // Registration successful, redirect to login
          this.router.navigate(['/login'], {
            queryParams: { registered: 'true' }
          });
        }, 2000);
      },
      error: (error) => {
        console.error('Registration error:', error);
        this.isLoading = false;
        this.errorMessage = error.message || 'An error occurred during registration';
      }
    });
  }
 
  // Helper methods for form validation
  hasError(controlName: string, errorName: string): boolean {
    const control = this.registerForm.get(controlName);
    return !!control && control.touched && control.hasError(errorName);
  }
 
  hasPasswordMismatch(): boolean {
    const confirmPassword = this.registerForm.get('confirmPassword');
    return !!confirmPassword && confirmPassword.touched && !!confirmPassword.errors?.['passwordMismatch'];
  }
}