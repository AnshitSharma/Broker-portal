import { Component, OnInit, AfterViewInit, ElementRef, ViewChild } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { FooterComponent } from '../shared/footer/footer.component';

interface Policy {
  policyNumber: string;
  clientName: string;
  type: string;
  premium: number;
  commission: number;
  status: string;
  statusClass: string;
  date: Date;
}

@Component({
  selector: 'app-report-dashboard',
  standalone: true,
  imports: [CommonModule, FormsModule, FooterComponent],
  templateUrl: './report-dashboard.component.html',
  styleUrls: ['./report-dashboard.component.css']
})
export class ReportDashboardComponent implements OnInit, AfterViewInit {
  // ViewChild references for canvas elements
  @ViewChild('commissionCanvas') commissionCanvas!: ElementRef<HTMLCanvasElement>;
  @ViewChild('liabilityCanvas') liabilityCanvas!: ElementRef<HTMLCanvasElement>;
  @ViewChild('productCanvas') productCanvas!: ElementRef<HTMLCanvasElement>;
  @ViewChild('clientsCanvas') clientsCanvas!: ElementRef<HTMLCanvasElement>;
  
  // Make Math available in template
  Math = Math;
  
  // Sidebar state
  sidebarCollapsed: boolean = false;
  
  // Period filter
  selectedPeriod: string = '6months';
  
  // Stats
  totalCommission: number = 134750;
  commissionGrowth: number = 7.5;
  totalPolicies: number = 286;
  policiesGrowth: number = 12.4;
  newClients: number = 42;
  clientsGrowth: number = -3.2;
  conversionRate: number = 24.8;
  conversionGrowth: number = 5.3;
  
  // Data for charts
  commissionData = {
    labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
    values: [18500, 22400, 19800, 26700, 22300, 24650]
  };
  
  liabilityData = {
    labels: [
      'Bodily Injury & Property Damage',
      'Products & Operations',
      'Advertising Injury',
      'Reputational Harm',
      'Independent Contractors'
    ],
    values: [35, 25, 15, 12, 13]
  };
  
  productData = {
    labels: ['General Liability', 'Professional Liability', 'Workers Comp', 'Business Property', 'Cyber'],
    values: [45800, 32400, 28500, 19600, 8450]
  };
  
  clientsData = {
    newClients: [8, 12, 7, 15, 9, 11],
    retentionRate: [92, 94, 91, 95, 93, 97],
    labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun']
  };
  
  // Recent policies
  recentPolicies: Policy[] = [
    {
      policyNumber: 'GL-42586',
      clientName: 'Smith Consulting LLC',
      type: 'General Liability',
      premium: 5200,
      commission: 780,
      status: 'Active',
      statusClass: 'success',
      date: new Date(2025, 3, 15)
    },
    {
      policyNumber: 'PL-38721',
      clientName: 'Tech Solutions Inc',
      type: 'Professional Liability',
      premium: 4300,
      commission: 645,
      status: 'Active',
      statusClass: 'success',
      date: new Date(2025, 3, 12)
    },
    {
      policyNumber: 'WC-29384',
      clientName: 'Pacific Construction',
      type: 'Workers Comp',
      premium: 8700,
      commission: 1305,
      status: 'Pending',
      statusClass: 'warning',
      date: new Date(2025, 3, 10)
    },
    {
      policyNumber: 'BP-57294',
      clientName: 'Sunrise Bakery',
      type: 'Business Property',
      premium: 3800,
      commission: 570,
      status: 'Active',
      statusClass: 'success',
      date: new Date(2025, 3, 5)
    },
    {
      policyNumber: 'CL-18463',
      clientName: 'DataSecure Networks',
      type: 'Cyber Liability',
      premium: 2900,
      commission: 435,
      status: 'Expired',
      statusClass: 'danger',
      date: new Date(2025, 3, 1)
    }
  ];

  constructor() {}

  ngOnInit(): void {
    // Check if sidebar state is saved in localStorage
    const savedSidebarState = localStorage.getItem('sidebarCollapsed');
    if (savedSidebarState) {
      this.sidebarCollapsed = JSON.parse(savedSidebarState);
    }
    
    // Initialize data based on the default selected period
    this.updateDataByPeriod(this.selectedPeriod);
  }

  ngAfterViewInit(): void {
    // Initialize charts after the view is ready
    setTimeout(() => {
      this.renderCommissionChart();
      this.renderLiabilityChart();
      this.renderProductChart();
      this.renderClientsChart();
    }, 100);
  }

  renderCommissionChart(): void {
    const canvas = this.commissionCanvas.nativeElement;
    const ctx = canvas.getContext('2d');
    
    if (ctx) {
      const width = canvas.width;
      const height = canvas.height;
      const barCount = this.commissionData.values.length;
      const maxValue = Math.max(...this.commissionData.values);
      const barWidth = (width - 60) / barCount - 20;
      const scale = (height - 60) / maxValue;
      
      // Clear canvas
      ctx.clearRect(0, 0, width, height);
      
      // Draw Y axis
      ctx.beginPath();
      ctx.moveTo(40, 20);
      ctx.lineTo(40, height - 40);
      ctx.stroke();
      
      // Draw X axis
      ctx.beginPath();
      ctx.moveTo(40, height - 40);
      ctx.lineTo(width - 20, height - 40);
      ctx.stroke();
      
      // Draw bars
      for (let i = 0; i < barCount; i++) {
        const x = 50 + i * (barWidth + 20);
        const barHeight = this.commissionData.values[i] * scale;
        const y = height - 40 - barHeight;
        
        ctx.fillStyle = '#010D2D';
        ctx.fillRect(x, y, barWidth, barHeight);
        
        // Draw value on top of the bar
        ctx.fillStyle = '#333';
        ctx.font = '12px Arial';
        ctx.textAlign = 'center';
        ctx.fillText('$' + this.commissionData.values[i], x + barWidth / 2, y - 5);
        
        // Draw label below the bar
        ctx.fillText(this.commissionData.labels[i], x + barWidth / 2, height - 20);
      }
    }
  }

  renderLiabilityChart(): void {
    const canvas = this.liabilityCanvas.nativeElement;
    const ctx = canvas.getContext('2d');
    
    if (ctx) {
      const width = canvas.width;
      const height = canvas.height;
      const centerX = width / 2 - 50; // Offset to leave room for legend
      const centerY = height / 2;
      const radius = Math.min(centerX, centerY) - 20;
      
      // Clear canvas
      ctx.clearRect(0, 0, width, height);
      
      // Colors for pie slices
      const colors = [
        '#010D2D',
        '#1a2a5c',
        '#344789',
        '#4e64b8',
        '#8290cc'
      ];
      
      // Calculate total
      const total = this.liabilityData.values.reduce((sum, value) => sum + value, 0);
      
      // Draw pie slices
      let startAngle = 0;
      
      for (let i = 0; i < this.liabilityData.values.length; i++) {
        const sliceAngle = (this.liabilityData.values[i] / total) * 2 * Math.PI;
        
        ctx.beginPath();
        ctx.moveTo(centerX, centerY);
        ctx.arc(centerX, centerY, radius, startAngle, startAngle + sliceAngle);
        ctx.closePath();
        
        ctx.fillStyle = colors[i % colors.length];
        ctx.fill();
        
        // Store middle angle for placing text
        const midAngle = startAngle + sliceAngle / 2;
        
        startAngle += sliceAngle;
      }
      
      // Draw legend
      const legendX = width - 180;
      const legendY = 50;
      
      for (let i = 0; i < this.liabilityData.labels.length; i++) {
        const y = legendY + i * 25;
        
        // Draw colored square
        ctx.fillStyle = colors[i % colors.length];
        ctx.fillRect(legendX, y, 15, 15);
        
        // Draw label
        ctx.fillStyle = '#333';
        ctx.font = '12px Arial';
        ctx.textAlign = 'left';
        ctx.fillText(`${this.liabilityData.values[i]}%`, legendX + 25, y + 12);
        
        // Truncate label if it's too long
        let label = this.liabilityData.labels[i];
        if (label.length > 15) {
          label = label.substring(0, 12) + '...';
        }
        ctx.fillText(label, legendX + 60, y + 12);
      }
    }
  }

  renderProductChart(): void {
    const canvas = this.productCanvas.nativeElement;
    const ctx = canvas.getContext('2d');
    
    if (ctx) {
      const width = canvas.width;
      const height = canvas.height;
      const barHeight = 30;
      const maxValue = Math.max(...this.productData.values);
      const scale = (width - 200) / maxValue;
      
      // Clear canvas
      ctx.clearRect(0, 0, width, height);
      
      // Draw bars
      for (let i = 0; i < this.productData.labels.length; i++) {
        const y = 50 + i * (barHeight + 20);
        const barWidth = this.productData.values[i] * scale;
        
        ctx.fillStyle = '#010D2D';
        ctx.fillRect(150, y, barWidth, barHeight);
        
        // Draw label
        ctx.fillStyle = '#333';
        ctx.font = '12px Arial';
        ctx.textAlign = 'right';
        ctx.fillText(this.productData.labels[i], 140, y + barHeight / 2 + 4);
        
        // Draw value
        ctx.textAlign = 'left';
        ctx.fillText('$' + this.productData.values[i], barWidth + 160, y + barHeight / 2 + 4);
      }
    }
  }

  renderClientsChart(): void {
    const canvas = this.clientsCanvas.nativeElement;
    const ctx = canvas.getContext('2d');
    
    if (ctx) {
      const width = canvas.width;
      const height = canvas.height;
      const chartWidth = width - 60;
      const chartHeight = height - 60;
      const xStart = 50;
      const yStart = height - 40;
      const xStep = chartWidth / (this.clientsData.labels.length - 1);
      
      // Clear canvas
      ctx.clearRect(0, 0, width, height);
      
      // Draw axes
      ctx.beginPath();
      ctx.moveTo(40, 20);
      ctx.lineTo(40, height - 40);
      ctx.lineTo(width - 20, height - 40);
      ctx.stroke();
      
      // Draw X labels
      for (let i = 0; i < this.clientsData.labels.length; i++) {
        const x = xStart + i * xStep;
        
        ctx.fillStyle = '#333';
        ctx.font = '12px Arial';
        ctx.textAlign = 'center';
        ctx.fillText(this.clientsData.labels[i], x, height - 20);
      }
      
      // Draw new clients line
      const maxNewClients = Math.max(...this.clientsData.newClients);
      const newClientsScale = chartHeight / maxNewClients;
      
      ctx.beginPath();
      ctx.moveTo(xStart, yStart - this.clientsData.newClients[0] * newClientsScale);
      
      for (let i = 1; i < this.clientsData.newClients.length; i++) {
        const x = xStart + i * xStep;
        const y = yStart - this.clientsData.newClients[i] * newClientsScale;
        ctx.lineTo(x, y);
      }
      
      ctx.strokeStyle = '#010D2D';
      ctx.lineWidth = 3;
      ctx.stroke();
      
      // Draw retention rate line
      ctx.beginPath();
      const retentionScale = chartHeight / 15; // Scale between 85-100%
      ctx.moveTo(xStart, yStart - (this.clientsData.retentionRate[0] - 85) * retentionScale);
      
      for (let i = 1; i < this.clientsData.retentionRate.length; i++) {
        const x = xStart + i * xStep;
        const y = yStart - (this.clientsData.retentionRate[i] - 85) * retentionScale;
        ctx.lineTo(x, y);
      }
      
      ctx.strokeStyle = 'rgba(1, 13, 45, 0.5)';
      ctx.lineWidth = 2;
      ctx.stroke();
      
      // Add legend
      ctx.fillStyle = '#010D2D';
      ctx.fillRect(width - 150, 30, 15, 15);
      ctx.fillStyle = '#333';
      ctx.textAlign = 'left';
      ctx.fillText('New Clients', width - 130, 42);
      
      ctx.fillStyle = 'rgba(1, 13, 45, 0.5)';
      ctx.fillRect(width - 150, 55, 15, 15);
      ctx.fillStyle = '#333';
      ctx.textAlign = 'left';
      ctx.fillText('Retention Rate', width - 130, 67);
    }
  }

  onPeriodChange(): void {
    this.updateDataByPeriod(this.selectedPeriod);
    
    // Re-render charts with updated data
    setTimeout(() => {
      this.renderCommissionChart();
      this.renderClientsChart();
    }, 100);
  }

  updateDataByPeriod(period: string): void {
    // In a real app, you would fetch data from a service based on the period
    // For this demo, we'll just simulate different data for different periods
    
    switch (period) {
      case '3months':
        this.commissionData.labels = ['Apr', 'May', 'Jun'];
        this.commissionData.values = [26700, 22300, 24650];
        
        this.clientsData.labels = ['Apr', 'May', 'Jun'];
        this.clientsData.newClients = [15, 9, 11];
        this.clientsData.retentionRate = [95, 93, 97];
        
        this.totalCommission = 73650;
        this.commissionGrowth = 8.2;
        this.totalPolicies = 156;
        this.policiesGrowth = 14.7;
        break;
        
      case '1month':
        this.commissionData.labels = ['Jun W1', 'Jun W2', 'Jun W3', 'Jun W4'];
        this.commissionData.values = [5800, 6500, 5900, 6450];
        
        this.clientsData.labels = ['Jun W1', 'Jun W2', 'Jun W3', 'Jun W4'];
        this.clientsData.newClients = [3, 2, 4, 2];
        this.clientsData.retentionRate = [96, 97, 95, 98];
        
        this.totalCommission = 24650;
        this.commissionGrowth = 10.5;
        this.totalPolicies = 42;
        this.policiesGrowth = 16.8;
        break;
        
      case 'ytd':
        this.commissionData.labels = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'];
        this.commissionData.values = [18500, 22400, 19800, 26700, 22300, 24650];
        
        this.clientsData.labels = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'];
        this.clientsData.newClients = [8, 12, 7, 15, 9, 11];
        this.clientsData.retentionRate = [92, 94, 91, 95, 93, 97];
        
        this.totalCommission = 134350;
        this.commissionGrowth = 7.5;
        this.totalPolicies = 286;
        this.policiesGrowth = 12.4;
        break;
        
      default: // 6months
        this.commissionData.labels = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'];
        this.commissionData.values = [18500, 22400, 19800, 26700, 22300, 24650];
        
        this.clientsData.labels = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'];
        this.clientsData.newClients = [8, 12, 7, 15, 9, 11];
        this.clientsData.retentionRate = [92, 94, 91, 95, 93, 97];
        
        this.totalCommission = 134350;
        this.commissionGrowth = 7.5;
        this.totalPolicies = 286;
        this.policiesGrowth = 12.4;
    }
  }

  downloadChart(chartType: string): void {
    let canvas: HTMLCanvasElement | null = null;
    let filename = '';
    
    switch (chartType) {
      case 'commission':
        canvas = this.commissionCanvas.nativeElement;
        filename = 'commission-performance.png';
        break;
      case 'liability':
        canvas = this.liabilityCanvas.nativeElement;
        filename = 'liability-distribution.png';
        break;
      case 'product':
        canvas = this.productCanvas.nativeElement;
        filename = 'commission-by-product.png';
        break;
      case 'clients':
        canvas = this.clientsCanvas.nativeElement;
        filename = 'client-acquisition.png';
        break;
    }
    
    if (canvas) {
      const link = document.createElement('a');
      link.download = filename;
      link.href = canvas.toDataURL('image/png');
      link.click();
    }
  }
}