// quote-calculation.component.ts
import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { 
  BaseFactor, 
  BusinessInfo, 
  Coverage, 
  PremiumCalculationResult
} from '../models/premium-calculator.model';
import { PremiumCalculatorService } from '../services/premium-calculator.service';

interface BusinessBasicInfo {
  businessStatus: Array<{id: string, label: string, selected: boolean}>;
  businessStructure: string;
  ownerFirstName: string;
  ownerLastName: string;
  businessName: string;
  ownerFullName: string;
}

interface BusinessDetails {
  isNonProfit: string;
  businessDescription: string;
  additionalServices: string;
  businessYear: string;
  executiveOfficers: number;
  employeeCount: number;
}

interface LocationInfo {
  businessLocation: string;
  businessStreetAddress: string;
  zipCode: string;
  ownOrRent: string;
  hasOtherLocations: string;
}

// Interface for the selected coverage from sessionStorage
interface SelectedCoverage {
  title: string;
  description: string;
  image: string;
  price: number;
  selected: boolean;
  limit: string;
}

@Component({
  selector: 'app-quote-calculation',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './quote-calculation.component.html',
  styleUrls: ['./quote-calculation.component.css']
})
export class QuoteCalculationComponent implements OnInit {
  // Data models
  baseFactors: BaseFactor[] = [];
  
  // Coverage information from sessionStorage
  selectedCoverages: SelectedCoverage[] = [];
  totalPrice: number = 0;
  
  // Business information from sessionStorage
  businessInfo: BusinessBasicInfo = {
    businessStatus: [],
    businessStructure: '',
    ownerFirstName: '',
    ownerLastName: '',
    businessName: '',
    ownerFullName: ''
  };
  
  businessDetails: BusinessDetails = {
    isNonProfit: '',
    businessDescription: '',
    additionalServices: '',
    businessYear: '',
    executiveOfficers: 0,
    employeeCount: 0
  };
  
  locationInfo: LocationInfo = {
    businessLocation: '',
    businessStreetAddress: '',
    zipCode: '',
    ownOrRent: '',
    hasOtherLocations: ''
  };
  
  // Auto-populated fields for calculations
  autoPopulatedBusinessInfo: BusinessInfo = {
    annualRevenue: 250000, // Default value
    employeeCount: 0,
    yearsInBusiness: 0,
    industryCode: 'RETAIL001', // Default value
    zipCode: '',
    buildingType: 'Commercial', // Default value
    squareFootage: 2500, // Default value
    hasClaimHistory: false,
    claimCount: 0,
    claimAmount: 0
  };
  
  // Results
  calculationResult: PremiumCalculationResult | null = null;
  showResults = false;
  loading = false;
  
  constructor(private premiumService: PremiumCalculatorService) {}
  
  ngOnInit(): void {
    this.loading = true;
    
    // Load data from sessionStorage and sessionStorage
    this.loadsessionStorageData();
    this.loadSessionStorageData();
    
    // Load base factors for calculation
    this.premiumService.getBaseFactors().subscribe((factors: BaseFactor[]) => {
      this.baseFactors = factors;
      this.loading = false;
    });
    
    // Populate business info with data from sessionStorage
    this.setupBusinessInfoForCalculation();
  }
  
  /**
   * Loads data from sessionStorage
   */
  loadsessionStorageData(): void {
    // Load basic info
    const basicInfoStr = sessionStorage.getItem('quoteBasicInfo');
    if (basicInfoStr) {
      this.businessInfo = JSON.parse(basicInfoStr);
    }
    
    // Load business details
    const businessDetailsStr = sessionStorage.getItem('quoteBusinessDetails');
    if (businessDetailsStr) {
      this.businessDetails = JSON.parse(businessDetailsStr);
    }
    
    // Load location info
    const locationInfoStr = sessionStorage.getItem('quoteLocationInfo');
    if (locationInfoStr) {
      this.locationInfo = JSON.parse(locationInfoStr);
    }
  }
  
  /**
   * Loads coverage data from sessionStorage
   */
  loadSessionStorageData(): void {
    // Load selected coverages
    const selectedCoveragesStr = sessionStorage.getItem('selectedCoverages');
    if (selectedCoveragesStr) {
      this.selectedCoverages = JSON.parse(selectedCoveragesStr);
    }
    
    // Load total price
    const totalPriceStr = sessionStorage.getItem('totalPrice');
    if (totalPriceStr) {
      this.totalPrice = parseFloat(totalPriceStr);
    }
  }
  
  /**
   * Sets up business info for calculation based on sessionStorage data
   */
  setupBusinessInfoForCalculation(): void {
    // Map employee count
    this.autoPopulatedBusinessInfo.employeeCount = 
      this.businessDetails.employeeCount || 0;
    
    // Calculate years in business
    this.autoPopulatedBusinessInfo.yearsInBusiness = 
      this.calculateYearsInBusiness();
    
    // Map ZIP code
    this.autoPopulatedBusinessInfo.zipCode = 
      this.locationInfo.zipCode || '10001';
    
    // Map building type
    this.autoPopulatedBusinessInfo.buildingType = 
      this.locationInfo.businessLocation || 'Commercial';
  }
  
  /**
   * Calculates years in business based on establishment year
   */
  calculateYearsInBusiness(): number {
    if (!this.businessDetails.businessYear) return 0;
    
    const establishmentYear = parseInt(this.businessDetails.businessYear);
    const currentYear = new Date().getFullYear();
    return Math.max(0, currentYear - establishmentYear);
  }
  
  /**
   * Gets the label for the selected business status
   */
  getBusinessStatusLabel(): string {
    const selectedStatus = this.businessInfo.businessStatus.find(status => status.selected);
    return selectedStatus ? selectedStatus.label : 'N/A';
  }
  
  /**
   * Performs the premium calculation
   */
  calculatePremium(): void {
    if (this.selectedCoverages.length === 0) {
      alert('No coverages selected. Please go back to the Liability Selection step.');
      return;
    }
    
    this.loading = true;
    this.showResults = false;
    
    const businessInfo: BusinessInfo = this.autoPopulatedBusinessInfo;
    
    // Set different annual revenue based on employee count for demonstration
    if (this.businessDetails.employeeCount <= 5) {
      businessInfo.annualRevenue = 150000;
    } else if (this.businessDetails.employeeCount <= 15) {
      businessInfo.annualRevenue = 500000;
    } else if (this.businessDetails.employeeCount <= 30) {
      businessInfo.annualRevenue = 1500000;
    } else {
      businessInfo.annualRevenue = 3000000;
    }
    
    // Set square footage based on business location type
    if (this.locationInfo.businessLocation === 'Commercial Building') {
      businessInfo.squareFootage = 5000;
    } else if (this.locationInfo.businessLocation === 'Commercial') {
      businessInfo.squareFootage = 3500;
    } else if (this.locationInfo.businessLocation === 'Personal Residence') {
      businessInfo.squareFootage = 1200;
    }
    
    // Set industry code based on business description
    const description = this.businessDetails.businessDescription.toLowerCase();
    if (description.includes('food') || description.includes('restaurant')) {
      businessInfo.industryCode = 'FOOD001';
    } else if (description.includes('retail') || description.includes('store')) {
      businessInfo.industryCode = 'RETAIL001';
    } else if (description.includes('office') || description.includes('service')) {
      businessInfo.industryCode = 'OFFICE001';
    } else if (description.includes('contractor') || description.includes('construction')) {
      businessInfo.industryCode = 'CONTR001';
    } else if (description.includes('manufactur')) {
      businessInfo.industryCode = 'MANUF001';
    }
    
    // Create a simplified coverage array from the selected coverages
    const coverages: Coverage[] = this.mapSelectedCoveragesToAPIFormat();
    
    // Empty applied factors - we're hiding customization
    const appliedFactors: {[key: string]: number} = {};
    
    this.premiumService.calculatePremium(
      coverages,
      businessInfo,
      appliedFactors
    ).subscribe((result: PremiumCalculationResult) => {
      this.calculationResult = result;
      
      // Modify the calculation result to match the total price from sessionStorage
      // This ensures consistency with the price shown in previous steps
      this.adjustCalculationResult();
      
      this.showResults = true;
      this.loading = false;
    });
  }
  
  /**
   * Maps the selected coverages from session storage to the format expected by the API
   */
  private mapSelectedCoveragesToAPIFormat(): Coverage[] {
    return this.selectedCoverages.map((selectedCoverage, index) => {
      return {
        id: `coverage_${index}`,
        name: selectedCoverage.title,
        description: selectedCoverage.description,
        baseAmount: selectedCoverage.price,
        selected: true,
        requiredFactors: [],
        optionalFactors: [],
        limits: [
          { 
            id: 'limit_default', 
            name: selectedCoverage.limit, 
            amount: this.parseLimitAmount(selectedCoverage.limit), 
            adjustmentFactor: 1.0 
          }
        ],
        selectedLimit: 'limit_default'
      };
    });
  }
  
  /**
   * Parses limit amount from the limit string (e.g., "$2M" -> 2000000)
   */
  private parseLimitAmount(limitString: string): number {
    if (!limitString) return 1000000; // Default to 1M if not specified
    
    try {
      const match = limitString.match(/\$?(\d+(?:\.\d+)?)([KMB])?/i);
      if (!match) return 1000000;
      
      const amount = parseFloat(match[1]);
      const unit = match[2]?.toUpperCase() || '';
      
      switch (unit) {
        case 'K': return amount * 1000;
        case 'M': return amount * 1000000;
        case 'B': return amount * 1000000000;
        default: return amount;
      }
    } catch (error) {
      console.error('Error parsing limit amount:', error);
      return 1000000;
    }
  }
  
  /**
   * Adjusts the calculation result to match the total price from sessionStorage
   */
  private adjustCalculationResult(): void {
    if (!this.calculationResult) return;
    
    // Calculate the difference between the API calculated subtotal and the sessionStorage total
    const apiSubtotal = this.calculationResult.subtotal;
    const difference = this.totalPrice - apiSubtotal;
    
    // Add an adjustment to reconcile the difference if needed
    if (Math.abs(difference) > 0.01) { // Only adjust if difference is significant
      // Add an adjustment entry
      this.calculationResult.adjustments.push({
        name: 'Price Adjustment',
        description: 'Adjustment to match quoted price',
        amount: difference,
        factorId: 'price_adjustment',
        adjustmentType: 'fixed_amount' as any // Using any to avoid importing BaseFactorType enum
      });
      
      // Update subtotal and total price
      this.calculationResult.subtotal = this.totalPrice;
      this.calculationResult.totalAnnualPremium = this.calculationResult.totalAnnualPremium + difference;
      this.calculationResult.monthlyPremium = this.calculationResult.totalAnnualPremium / 12;
    }
  }
  
  /**
   * Formats currency values
   */
  formatCurrency(value: number): string {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2
    }).format(value);
  }
}