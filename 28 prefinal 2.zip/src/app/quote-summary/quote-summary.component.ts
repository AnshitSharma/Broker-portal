import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { catchError, finalize, of } from 'rxjs';

interface Coverage {
  title: string;
  description: string;
  image?: string;
  selected: boolean;
}

interface BusinessCategory {
  code: string;
  name: string;
}

interface SelectedCoverage {
  name: string;
  description: string;
  isBaseCoverage: boolean;
}

interface QuoteRequest {
  quoteId: number;
  businessName: string;
  ownerFirstName: string;
  ownerLastName: string;
  email: string;
  phone: string;
  businessStructure: string;
  industryClass: string;
  annualRevenue: number;
  businessAddress: string;
  zipCode: string;
  hasMultipleLocations: boolean;
  isNonProfit: boolean;
  businessDescription: string;
  yearsInBusiness: number;
  employeeCount: number;
  executiveOfficerCount: number;
  coverageLimit: number;
  createdDate: string;
  status: string;
  selectedCoverages: SelectedCoverage[];
}

// Define interfaces for storage data
interface BasicInfoData {
  businessStatus?: { id: string; label: string; selected: boolean }[];
  businessStructure?: string;
  ownerFirstName?: string;
  ownerLastName?: string;
  businessName?: string;
  ownerFullName?: string;
  emailAddress?: string;
  phoneNumber?: string;
  [key: string]: any;
}

interface LocationInfoData {
  businessLocation?: string;
  businessStreetAddress?: string;
  zipCode?: string;
  ownOrRent?: string;
  hasOtherLocations?: string;
  [key: string]: any;
}

interface BusinessDetailsData {
  businessYear?: string;
  employeeCount?: number;
  executiveOfficers?: number;
  businessDescription?: string;
  isNonProfit?: string;
  additionalServices?: string;
  hasLiabilityClaims?: string;
  claimsCount?: number;
  claimsType?: string;
  hasHazardousOperations?: string;
  businessCategory?: string;
  annualRevenue?: number;
  coverageLimit?: string | number;
  [key: string]: any;
}

@Component({
  selector: 'app-quote-summary',
  standalone: true,
  templateUrl: './quote-summary.component.html',
  styleUrls: ['./quote-summary.component.css'],
  imports: [CommonModule, FormsModule, HttpClientModule]
})
export class QuoteSummaryComponent implements OnInit {
  // Quote information
  quoteId: string = '';
  quoteDate: Date = new Date();
  
  // API and UI state
  isSubmitting: boolean = false;
  apiError: boolean = false;
  errorMessage: string = '';
  showSuccessModal: boolean = false;
  
  // Selected coverages from previous step
  selectedCoverages: Coverage[] = [];
  
  // Business information from step 1 and 3
  businessInfo: any = {
    ownerFirstName: '',
    ownerLastName: '',
    ownerName: '',
    businessName: '',
    businessStructure: '',
    businessYear: '',
    employeeCount: 0,
    executiveOfficers: 0,
    businessDescription: '',
    isNonProfit: 'No',
    additionalServices: 'No',
    hasLiabilityClaims: 'No',
    claimsCount: 0,
    claimsType: '',
    hasHazardousOperations: 'No',
    businessCategory: '',
    annualRevenue: 0,
    coverageLimit: 1000000,
    emailAddress: '',
    phoneNumber: ''
  };
  
  // Location information from step 2
  locationInfo: any = {
    businessLocation: '',
    businessStreetAddress: '',
    zipCode: '',
    ownOrRent: '',
    hasOtherLocations: 'No'
  };
  
  // Business categories for lookup
  businessCategories: BusinessCategory[] = [
    { code: '2382', name: 'Building Equipment Contractors' },
    { code: '2383', name: 'Building Finishing Contractors' },
    { code: '4231', name: 'Motor Vehicle and Parts Dealers (Wholesale)' },
    { code: '4232', name: 'Furniture and Home Furnishings Wholesalers' },
    { code: '4243', name: 'Apparel and Piece Goods Merchants (Wholesale)' },
    { code: '4451', name: 'Grocery Stores' },
    { code: '4452', name: 'Specialty Food Stores' },
    { code: '4461', name: 'Health and Personal Care Stores' },
    { code: '4481', name: 'Clothing Stores' },
    { code: '4511', name: 'Sporting Goods, Hobby, and Musical Instrument Stores' },
    { code: '4529', name: 'Other General Merchandise Stores' },
    { code: '5121', name: 'Motion Picture and Video Industries' },
    { code: '5312', name: 'Offices of Real Estate Agents and Brokers' },
    { code: '5414', name: 'Specialized Design Services' },
    { code: '5416', name: 'Management, Scientific, and Technical Consulting' },
    { code: '5419', name: 'Other Professional, Scientific, and Technical Services' },
    { code: '5617', name: 'Services to Buildings and Dwellings' },
    { code: '7223', name: 'Special Food Services (Catering, Food Trucks)' },
    { code: '7225', name: 'Restaurants and Other Eating Places' },
    { code: '8121', name: 'Personal Care Services (Salons, Barber Shops)' },
    { code: '8129', name: 'Other Personal Services' }
  ];
  
  // Storage key constants
  private readonly STORAGE_KEY = 'insurance_quote_data';
  private readonly BASIC_INFO_KEY = 'quoteBasicInfo';
  private readonly LOCATION_INFO_KEY = 'quoteLocationInfo';
  
  // API URL for submitting quotes
  private readonly API_URL = 'https://localhost:7124/api/Quote/insurance-quotes';
  
  constructor(private router: Router, private http: HttpClient) {}

  ngOnInit(): void {
    this.loadQuoteData();
  }

  /**
   * Load data from previous steps
   */
  loadQuoteData(): void {
    // Generate a random quote ID
    this.quoteId = 'BIZ-' + Math.floor(100000 + Math.random() * 900000);
    
    // Load coverage data from session storage
    const coverageData = sessionStorage.getItem('selectedCoverages');
    if (coverageData) {
      this.selectedCoverages = JSON.parse(coverageData);
    }
    
    // Load basic info data from session storage (step 1)
    let basicInfo: BasicInfoData = {};
    const basicInfoData = sessionStorage.getItem(this.BASIC_INFO_KEY);
    if (basicInfoData) {
      basicInfo = JSON.parse(basicInfoData);
      console.log('Loaded basic info from storage:', basicInfo);
    }
    
    // Load location info from session storage (step 2)
    let locationInfo: LocationInfoData = {};
    const locationInfoData = sessionStorage.getItem(this.LOCATION_INFO_KEY);
    if (locationInfoData) {
      locationInfo = JSON.parse(locationInfoData);
      console.log('Loaded location info from storage:', locationInfo);
    }
    
    // Load business details from session storage (step 3)
    let businessDetails: BusinessDetailsData = {};
    const businessDetailsData = sessionStorage.getItem(this.STORAGE_KEY);
    if (businessDetailsData) {
      businessDetails = JSON.parse(businessDetailsData);
      console.log('Loaded business details from storage:', businessDetails);
    }
    
    // Process business info from all storage sources or use fallback data
    this.businessInfo = {
      // From basic info (step 1)
      ownerFirstName: basicInfo.ownerFirstName || 'John',
      ownerLastName: basicInfo.ownerLastName || 'Smith',
      ownerName: `${basicInfo.ownerFirstName || 'John'} ${basicInfo.ownerLastName || 'Smith'}`,
      businessName: basicInfo.businessName || 'Smith Consulting LLC',
      businessStructure: basicInfo.businessStructure || 'Limited Liability Corporation (LLC)',
      emailAddress: basicInfo.emailAddress || 'contact@example.com',
      phoneNumber: basicInfo.phoneNumber || '(555) 123-4567',
      
      // From business details (step 3)
      businessYear: businessDetails.businessYear || '2018',
      employeeCount: businessDetails.employeeCount !== undefined ? businessDetails.employeeCount : 5,
      executiveOfficers: businessDetails.executiveOfficers !== undefined ? businessDetails.executiveOfficers : 2,
      businessDescription: businessDetails.businessDescription || 'IT Consulting Services',
      isNonProfit: businessDetails.isNonProfit || 'No',
      additionalServices: businessDetails.additionalServices || 'Yes',
      hasLiabilityClaims: businessDetails.hasLiabilityClaims || 'No',
      claimsCount: businessDetails.claimsCount || 0,
      claimsType: businessDetails.claimsType || 'N/A',
      hasHazardousOperations: businessDetails.hasHazardousOperations || 'No',
      businessCategory: this.getBusinessCategoryName(businessDetails.businessCategory) || 'Management, Scientific, and Technical Consulting',
      annualRevenue: businessDetails.annualRevenue || 250000,
      coverageLimit: businessDetails.coverageLimit || 1000000
    };
    
    // Process location info from session storage (step 2)
    this.locationInfo = {
      businessLocation: locationInfo.businessLocation || 'Commercial Building',
      businessStreetAddress: locationInfo.businessStreetAddress || '123 Business Ave, Suite 101',
      zipCode: locationInfo.zipCode || '10001',
      ownOrRent: locationInfo.ownOrRent || 'Rent',
      hasOtherLocations: locationInfo.hasOtherLocations || 'No'
    };
    
    console.log('Processed business info:', this.businessInfo);
    console.log('Processed location info:', this.locationInfo);
  }

  /**
   * Get business category name from code
   */
  getBusinessCategoryName(code: string | undefined): string {
    if (!code) return '';
    
    const category = this.businessCategories.find(cat => cat.code === code);
    return category ? category.name : '';
  }

  /**
   * Get number of years in business based on business year
   */
  getYearsInBusiness(): number {
    const currentYear = new Date().getFullYear();
    const establishedYear = parseInt(this.businessInfo.businessYear) || currentYear;
    return Math.max(0, currentYear - establishedYear);
  }

  /**
   * Navigate back to the coverage selection page
   */
  previousStep(): void {
    this.router.navigate(['/coverage-details']);
  }

  /**
   * Prepare the quote data for API submission according to the API schema
   */
  prepareQuoteData(): QuoteRequest {
    // Convert selected coverages to the format expected by the API
    const apiCoverages: SelectedCoverage[] = this.selectedCoverages.map(coverage => ({
      name: coverage.title,
      description: coverage.description,
      isBaseCoverage: coverage.title.includes('Bodily Injury') || coverage.title.includes('Property Damage')
    }));
    
    // Create a numeric ID from the string ID
    const numericId = parseInt(this.quoteId.replace('BIZ-', '')) || 0;
    
    // Prepare the final request object
    return {
      quoteId: numericId,
      businessName: this.businessInfo.businessName,
      ownerFirstName: this.businessInfo.ownerFirstName,
      ownerLastName: this.businessInfo.ownerLastName,
      email: this.businessInfo.emailAddress,
      phone: this.businessInfo.phoneNumber,
      businessStructure: this.businessInfo.businessStructure,
      industryClass: this.businessInfo.businessCategory,
      annualRevenue: this.businessInfo.annualRevenue || 250000,
      businessAddress: this.locationInfo.businessStreetAddress,
      zipCode: this.locationInfo.zipCode,
      hasMultipleLocations: this.locationInfo.hasOtherLocations === 'Yes',
      isNonProfit: this.businessInfo.isNonProfit === 'Yes',
      businessDescription: this.businessInfo.businessDescription,
      yearsInBusiness: this.getYearsInBusiness(),
      employeeCount: this.businessInfo.employeeCount || 0,
      executiveOfficerCount: this.businessInfo.executiveOfficers || 0,
      coverageLimit: typeof this.businessInfo.coverageLimit === 'string' 
        ? parseInt(this.businessInfo.coverageLimit)
        : this.businessInfo.coverageLimit || 1000000,
      createdDate: new Date().toISOString(),
      status: 'pending',
      selectedCoverages: apiCoverages
    };
  }

  /**
   * Submit the quote data to the API
   */
  submitQuoteToApi(): void {
    this.isSubmitting = true;
    this.apiError = false;
    
    const quoteData = this.prepareQuoteData();
    console.log('Submitting quote data:', quoteData);
    
    this.http.post<any>(this.API_URL, quoteData)
      .pipe(
        catchError(error => {
          console.error('Error submitting quote to API:', error);
          this.apiError = true;
          this.errorMessage = error.message || 'Failed to submit quote. Please try again.';
          return of(null);
        }),
        finalize(() => {
          this.isSubmitting = false;
        })
      )
      .subscribe(response => {
        if (response || !this.apiError) {
          // Navigate to the preview component and pass the response data
          // Store response in session storage to access in the preview component
          sessionStorage.setItem('quoteApiResponse', JSON.stringify(response));
          this.router.navigate(['/quote-preview']);
        }
        // If there was an error, the error message is already displayed
      });
  }

  /**
   * Proceed with the insurance application
   * Now with API integration and success modal
   */
  proceedToApplication(): void {
    try {
      // Submit to the API and navigate to preview
      this.submitQuoteToApi();
    } catch (error) {
      // If unexpected error occurs during API submission, fall back to local processing
      console.error('Unexpected error during API submission:', error);
      this.apiError = true;
      this.errorMessage = 'An unexpected error occurred.';
      
      // Create mock response and navigate to preview
      const mockResponse = {
        message: "Quote created successfully",
        quoteId: parseInt(this.quoteId.replace('BIZ-', '')) || 123456,
        ownerName: this.businessInfo.ownerName,
        businessName: this.businessInfo.businessName,
        email: this.businessInfo.emailAddress,
        phone: this.businessInfo.phoneNumber,
        status: "pending"
      };
      
      sessionStorage.setItem('quoteApiResponse', JSON.stringify(mockResponse));
      this.router.navigate(['/quote-preview']);
    }
  }
}